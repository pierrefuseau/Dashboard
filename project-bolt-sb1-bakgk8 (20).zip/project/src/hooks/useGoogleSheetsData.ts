import { useQuery } from '@tanstack/react-query';
import axios from 'axios';

const API_KEY = 'AIzaSyDKq5BKxXoOFaHjEholKS3OY5pXoT4fiY0';
const SPREADSHEET_ID = '1AyBuqiJbLkXxNhOYnK2C_gT6sn86IknCaaLwLwxAIxI';

export function useGoogleSheetsData(sheetName: string, range: string) {
  return useQuery({
    queryKey: ['sheets', sheetName, range],
    queryFn: async () => {
      try {
        const url = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${sheetName}!${range}?key=${API_KEY}`;
        const response = await axios.get(url);
        return response.data.values || [];
      } catch (error) {
        console.error('Erreur lors de la récupération des données:', error);
        return [];
      }
    },
    staleTime: 5 * 60 * 1000,
    cacheTime: 30 * 60 * 1000,
    retry: 2,
    refetchOnWindowFocus: false
  });
}