import { useSheetData } from '../sheets/useSheetData';
import { parseLogisticsValue } from '../../utils/formatters/logistics';

interface LogisticsMetrics {
  stockValue: number;
  serviceRate: number;
  anomalies: number;
  transportRate: number;
}

export function useLogisticsMetrics(): LogisticsMetrics {
  // Valeur Stock Total (C8)
  const { data: stockData } = useSheetData('LOGISTIQUE', 'C8', {
    transform: (data) => parseLogisticsValue(data?.[0]?.[0])
  });

  // Taux de Service Global (C11)
  const { data: serviceData } = useSheetData('LOGISTIQUE', 'C11', {
    transform: (data) => parseLogisticsValue(data?.[0]?.[0])
  });

  // Anomalies Traçabilité (C12)
  const { data: anomaliesData } = useSheetData('LOGISTIQUE', 'C12', {
    transform: (data) => parseLogisticsValue(data?.[0]?.[0])
  });

  // Taux Service Transport (C13)
  const { data: transportData } = useSheetData('LOGISTIQUE', 'C13', {
    transform: (data) => parseLogisticsValue(data?.[0]?.[0])
  });

  return {
    stockValue: stockData || 0,
    serviceRate: serviceData || 0,
    anomalies: anomaliesData || 0,
    transportRate: transportData || 0
  };
}