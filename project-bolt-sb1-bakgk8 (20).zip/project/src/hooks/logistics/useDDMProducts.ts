import { useSheetData } from '../sheets/useSheetData';
import { DDMProduct } from '../../types/logistics';

export function useDDMProducts() {
  // Retourner directement un état vide puisque les données ne sont plus disponibles
  return {
    data: [],
    isLoading: false,
    freshProducts: [],
    ambientProducts: []
  };
}