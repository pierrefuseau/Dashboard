import { useSheetData } from '../sheets/useSheetData';
import { StorageProduct } from '../../types/logistics';
import { differenceInDays, parse, isValid } from 'date-fns';
import { formatCurrency } from '../../utils/formatters/currency';

export function useStorageProducts() {
  // Récupérer les produits frais (E30:K44)
  const { data: freshProducts, isLoading: freshLoading } = useSheetData<StorageProduct[]>('LOGISTIQUE', 'E30:K44', {
    transform: (data) => transformProducts(data, 'FRESH')
  });

  // Récupérer les produits ambiants (M30:S113)
  const { data: ambientProducts, isLoading: ambientLoading } = useSheetData<StorageProduct[]>('LOGISTIQUE', 'M30:S113', {
    transform: (data) => transformProducts(data, 'AMBIENT')
  });

  return {
    data: [...(freshProducts || []), ...(ambientProducts || [])],
    isLoading: freshLoading || ambientLoading,
    freshProducts: freshProducts || [],
    ambientProducts: ambientProducts || []
  };
}

function getProductStatus(daysUntilDdm: number): DDMStatus {
  if (daysUntilDdm < 0) return 'EXPIRED';
  if (daysUntilDdm <= 7) return 'CRITICAL';
  if (daysUntilDdm <= 30) return 'WARNING';
  return 'OK';
}

function transformProducts(data: any[], type: 'FRESH' | 'AMBIENT') {
  if (!data) return [];

  return data
    .map(row => {
      try {
        if (!row[0] || !row[1]) return null;

        // Pour les produits frais (E30:K44):
        // E: Nom (index 0)
        // F: Lot (index 1)
        // K: DDM (index 6)
        // H: Quantité (index 3)
        // I: Montant stock (index 4)

        // Pour les produits ambiants (M30:S113):
        // M: Nom (index 0)
        // N: Lot (index 1)
        // O: DDM (index 2)
        // P: Quantité (index 3)
        // Q: Montant stock (index 4)

        const ddmStr = type === 'FRESH' ? row[6]?.toString() : row[2]?.toString();
        if (!ddmStr) return null;

        let ddm = null;
        const formats = ['dd/MM/yyyy', 'yyyy-MM-dd', 'dd-MM-yyyy'];
        
        for (const dateFormat of formats) {
          const parsedDate = parse(ddmStr, dateFormat, new Date());
          if (isValid(parsedDate)) {
            ddm = parsedDate;
            break;
          }
        }

        if (!ddm) {
          console.warn(`Date DDM invalide: ${ddmStr} pour ${row[0]}`);
          return null;
        }

        const daysUntilDdm = differenceInDays(ddm, new Date());
        const status = getProductStatus(daysUntilDdm);
        
        // Quantité
        const quantity = Number(row[3]?.toString().replace(/[^0-9.-]/g, '')) || 0;

        // Montant stock
        const stockAmountValue = Number(row[4]?.toString().replace(/[^0-9.-]/g, '')) || 0;
        const formattedStockAmount = formatCurrency(stockAmountValue);

        return {
          name: row[0].toString(),
          lot: row[1].toString(),
          ddm,
          quantity,
          stockAmount: formattedStockAmount,
          daysUntilDdm,
          type,
          status
        };
      } catch (error) {
        console.error('Error parsing storage product:', row, error);
        return null;
      }
    })
    .filter((product): product is StorageProduct => 
      product !== null && 
      product.name !== '' &&
      !isNaN(product.daysUntilDdm)
    )
    .sort((a, b) => a.daysUntilDdm - b.daysUntilDdm);
}