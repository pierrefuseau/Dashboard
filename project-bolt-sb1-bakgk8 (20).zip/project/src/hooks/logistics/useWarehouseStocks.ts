import { useSheetData } from '../sheets/useSheetData';
import { parseLogisticsValue } from '../../utils/formatters/logistics';

export interface WarehouseStock {
  name: string;
  value: number;
  percentage: number;
}

// Hook to get total stock value from C8
export function useTotalStock() {
  return useSheetData('LOGISTIQUE', 'C8', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      return parseLogisticsValue(data[0][0]);
    }
  });
}

// Hook to get warehouse stocks
export function useWarehouseStocks() {
  const { data: totalStock } = useTotalStock();

  return useSheetData('LOGISTIQUE', 'B4:C7', {
    transform: (data) => {
      // Transform raw data into warehouse stocks
      const stocks = data.map(row => ({
        name: row[0]?.toString().replace(/^[0-9]+ - /, '') || '',
        value: parseLogisticsValue(row[1])
      })).filter(stock => stock.name && stock.value > 0);

      // Calculate percentages based on total from C8
      return stocks.map(stock => ({
        ...stock,
        percentage: totalStock ? (stock.value / totalStock) * 100 : 0
      })).sort((a, b) => b.value - a.value);
    }
  });
}