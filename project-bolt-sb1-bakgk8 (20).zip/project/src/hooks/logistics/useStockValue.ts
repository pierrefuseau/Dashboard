import { useSheetData } from '../sheets/useSheetData';

export function useStockValue() {
  return useSheetData('LOGISTIQUE', 'C8', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      return Number(data[0][0].toString().replace(/[^0-9.-]+/g, '')) || 0;
    }
  });
}