import { useState, useCallback } from 'react';
import { TimeRange } from '../components/common/TimeFilter';

export function useTimeFilter(defaultRange: TimeRange = 'month') {
  const [timeRange, setTimeRange] = useState<TimeRange>(defaultRange);

  const handleTimeRangeChange = useCallback((range: TimeRange) => {
    setTimeRange(range);
  }, []);

  return {
    timeRange,
    setTimeRange: handleTimeRangeChange
  };
}