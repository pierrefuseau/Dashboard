import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { AuthService } from '../../services/auth/authService';
import { LoginCredentials } from '../../services/auth/types';

export function useAuth() {
  const { user, setUser } = useAuthStore();
  const navigate = useNavigate();

  const login = useCallback(async (credentials: LoginCredentials) => {
    try {
      const response = await AuthService.login(credentials);
      setUser(response.user);
      // Stocker le token dans un cookie sécurisé
      document.cookie = `auth-token=${response.token}; path=/; secure; samesite=strict; max-age=3600`;
      return response;
    } catch (error: any) {
      console.error('Erreur de connexion:', error);
      throw new Error(error.message || 'Erreur lors de la connexion');
    }
  }, [setUser]);

  const logout = useCallback(() => {
    setUser(null);
    // Supprimer le cookie de token
    document.cookie = 'auth-token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    navigate('/login');
  }, [setUser, navigate]);

  const hasPermission = useCallback((permission: string) => {
    if (!user || !user.permissions) return false;
    
    // Vérifier si l'utilisateur a la permission spécifique
    return user.permissions.includes(permission);
  }, [user]);

  return {
    user,
    login,
    logout,
    hasPermission,
    isAuthenticated: !!user
  };
}