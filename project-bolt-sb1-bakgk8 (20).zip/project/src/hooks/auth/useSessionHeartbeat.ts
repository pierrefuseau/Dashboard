import { useEffect, useRef, useCallback } from 'react';
import { useAuthStore } from '../../store/authStore';

interface UseSessionHeartbeatOptions {
  interval?: number;
  onSessionExpired?: () => void;
}

export function useSessionHeartbeat(options: UseSessionHeartbeatOptions = {}) {
  const { interval = 5 * 60 * 1000, onSessionExpired } = options;
  const { user, setUser } = useAuthStore();
  const heartbeatRef = useRef<NodeJS.Timeout>();

  const sendHeartbeat = useCallback(async () => {
    if (!user) return;

    try {
      const response = await fetch('https://entreprise.fuseau-sas.com/api/heartbeat', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error(`Erreur de heartbeat: ${response.status}`);
      }
    } catch (error) {
      // Ne pas afficher l'erreur dans la console en production
      if (process.env.NODE_ENV === 'development') {
        console.warn('Erreur de heartbeat:', error);
      }
      
      // Si l'erreur est liée à l'authentification, déconnecter l'utilisateur
      if (error instanceof Error && 
         (error.message.includes('401') || error.message.includes('403'))) {
        setUser(null);
        onSessionExpired?.();
      }
    }
  }, [user, setUser, onSessionExpired]);

  useEffect(() => {
    if (!user) {
      if (heartbeatRef.current) {
        clearInterval(heartbeatRef.current);
      }
      return;
    }

    // Envoyer un heartbeat immédiatement
    sendHeartbeat();

    // Configurer l'intervalle
    heartbeatRef.current = setInterval(sendHeartbeat, interval);

    return () => {
      if (heartbeatRef.current) {
        clearInterval(heartbeatRef.current);
      }
    };
  }, [user, interval, sendHeartbeat]);
}