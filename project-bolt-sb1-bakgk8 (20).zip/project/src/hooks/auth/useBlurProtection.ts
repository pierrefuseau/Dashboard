import { useCallback } from 'react';
import { useAuth } from './useAuth';

export function useBlurProtection() {
  const { hasPermission } = useAuth();

  const shouldBlur = useCallback((permission: string) => {
    return !hasPermission(permission);
  }, [hasPermission]);

  const getBlurClasses = useCallback((permission: string) => {
    return shouldBlur(permission) ? 'blur-protection' : '';
  }, [shouldBlur]);

  return {
    shouldBlur,
    getBlurClasses
  };
}