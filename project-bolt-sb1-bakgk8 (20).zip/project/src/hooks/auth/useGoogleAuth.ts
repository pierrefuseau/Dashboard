import { useEffect } from 'react';
import { useAuthStore } from '../../store/authStore';
import { getUserInfo } from '../../services/auth/googleAuthService';

export function useGoogleAuth() {
  const { setUser, logout } = useAuthStore();

  useEffect(() => {
    const handleAuthCallback = async () => {
      const hash = window.location.hash;
      if (!hash) return;

      try {
        const params = new URLSearchParams(hash.substring(1));
        const accessToken = params.get('access_token');
        
        if (accessToken) {
          const user = await getUserInfo(accessToken);
          setUser(user);
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      } catch (error) {
        console.error('Authentication failed:', error);
        logout();
      }
    };

    handleAuthCallback();
  }, [setUser, logout]);

  return useAuthStore();
}