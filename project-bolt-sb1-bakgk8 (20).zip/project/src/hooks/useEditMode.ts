import { useState } from 'react';

export function useEditMode() {
  const [isEditing, setIsEditing] = useState(false);
  const [editingData, setEditingData] = useState<any>(null);

  const startEditing = (initialData?: any) => {
    setIsEditing(true);
    if (initialData) {
      setEditingData(initialData);
    }
  };

  const stopEditing = () => {
    setIsEditing(false);
    setEditingData(null);
  };

  const updateEditingData = (data: any) => {
    setEditingData(data);
  };

  return {
    isEditing,
    editingData,
    startEditing,
    stopEditing,
    updateEditingData
  };
}