import { useSheetData } from '../sheets/useSheetData';
import { Loan, LoanSummary } from '../../components/accounting/loans/types';

export function useLoans() {
  return useSheetData<{ loans: Loan[]; summary: LoanSummary }>('COMPTABILITE', 'G1:S17', {
    transform: (data) => {
      if (!data?.length) return { loans: [], summary: defaultSummary };

      // Transform loan data
      const loans = data.slice(1)
        .map(row => {
          const id = row[0]?.toString() || '';

          // Get the end date from the correct column based on loan ID
          const endDate = row[8]?.toString() || '';

          return {
            id,
            lender: row[1]?.toString() || '',
            subject: row[2]?.toString() || '',
            name: row[2]?.toString() || '',
            amount: Number(row[3]?.toString().replace(/[^0-9.-]/g, '')) || 0,
            monthlyPayment: Number(row[4]?.toString().replace(/[^0-9.-]/g, '')) || 0,
            interestRate: Number(row[5]?.toString().replace(/[^0-9.-]/g, '')) || 0,
            duration: Number(row[6]?.toString().replace(/[^0-9.-]/g, '')) || 0,
            startDate: row[7]?.toString() || '',
            endDate,
            remainingAmount: Number(row[9]?.toString().replace(/[^0-9.-]/g, '')) || 0,
            paidAmount: Number(row[10]?.toString().replace(/[^0-9.-]/g, '')) || 0,
            remainingJan2025: Number(row[11]?.toString().replace(/[^0-9.-]/g, '')) || 0,
            interestPaid: Number(row[12]?.toString().replace(/[^0-9.-]/g, '')) || 0
          };
        })
        .filter((loan): loan is Loan => 
          loan !== null && 
          loan.id !== '' && 
          loan.amount > 0
        )
        .sort((a, b) => new Date(a.endDate).getTime() - new Date(b.endDate).getTime());

      // Calculate summary
      const summary = {
        totalAmount: loans.reduce((sum, loan) => sum + loan.amount, 0),
        totalRemaining: loans.reduce((sum, loan) => sum + loan.remainingJan2025, 0),
        totalInterestPaid: loans.reduce((sum, loan) => sum + loan.interestPaid, 0),
        nextDueDate: '',
        nextDueLoan: ''
      };

      return { loans, summary };
    }
  });
}

const defaultSummary: LoanSummary = {
  totalAmount: 0,
  totalRemaining: 0,
  totalInterestPaid: 0,
  nextDueDate: '',
  nextDueLoan: ''
};