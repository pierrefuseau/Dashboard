import { useSheetData } from '../sheets/useSheetData';
import { Receivable } from '../../components/accounting/receivables/types';

export function useReceivables() {
  // Get total company receivables first
  const { data: totalCompanyReceivables, isLoading: totalLoading } = useSheetData('COMPTABILITE', 'C16', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
    }
  });

  // Get detailed receivables data
  const { data: receivables, isLoading: receivablesLoading } = useSheetData<Receivable[]>('COMPTABILITE', 'A3:C11', {
    transform: (data) => {
      if (!data?.length || !totalCompanyReceivables) return [];
      
      return data
        .map(row => ({
          code: row[0]?.toString() || '',
          name: row[1]?.toString() || '',
          amount: Number(row[2]?.toString().replace(/[^0-9.-]/g, '')) || 0,
          percentage: 0
        }))
        .filter(item => item.code && item.name && item.amount > 0)
        .map(item => ({
          ...item,
          // Calculate percentage based on total company receivables
          percentage: (item.amount / totalCompanyReceivables) * 100
        }))
        .sort((a, b) => b.amount - a.amount);
    }
  });

  return {
    data: receivables,
    totalCompanyReceivables,
    isLoading: receivablesLoading || totalLoading
  };
}