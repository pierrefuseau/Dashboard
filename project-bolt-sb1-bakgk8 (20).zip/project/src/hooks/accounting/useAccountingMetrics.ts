import { useSheetData } from '../sheets/useSheetData';
import { formatShortDate } from '../../utils/formatters/date';

interface AccountingMetrics {
  revenue: number;
  grossMargin: number;
  treasury: number;
  treasuryDate: string;
  totalReceivables: number;
  isLoading: boolean;
}

export function useAccountingMetrics(): AccountingMetrics {
  // CA Bilan (B1)
  const { data: revenue, isLoading: revenueLoading } = useSheetData('COMPTABILITE', 'B1', {
    transform: (data) => Number(data?.[0]?.[0]?.toString().replace(/[^0-9.-]/g, '')) || 0
  });

  // Marge Brute Bilan (E1)
  const { data: grossMargin, isLoading: marginLoading } = useSheetData('COMPTABILITE', 'E1', {
    transform: (data) => Number(data?.[0]?.[0]?.toString().replace(/[^0-9.-]/g, '')) || 0
  });

  // Trésorerie (A16)
  const { data: treasury, isLoading: treasuryLoading } = useSheetData('COMPTABILITE', 'A16', {
    transform: (data) => Number(data?.[0]?.[0]?.toString().replace(/[^0-9.-]/g, '')) || 0
  });

  // Date de trésorerie (A17)
  const { data: treasuryDate, isLoading: dateLoading } = useSheetData('COMPTABILITE', 'A17', {
    transform: (data) => {
      const rawDate = data?.[0]?.[0]?.toString() || '';
      return formatShortDate(rawDate);
    }
  });

  // Encours total Clients (C16)
  const { data: totalReceivables, isLoading: receivablesLoading } = useSheetData('COMPTABILITE', 'C16', {
    transform: (data) => Number(data?.[0]?.[0]?.toString().replace(/[^0-9.-]/g, '')) || 0
  });

  return {
    revenue: revenue || 0,
    grossMargin: grossMargin || 0,
    treasury: treasury || 0,
    treasuryDate: treasuryDate || '',
    totalReceivables: totalReceivables || 0,
    isLoading: revenueLoading || marginLoading || treasuryLoading || dateLoading || receivablesLoading
  };
}