import { useQuery } from '@tanstack/react-query';
import { downloadLatestData } from '../services/googleCloud';

export function useGoogleCloudData(filePrefix: string) {
  return useQuery({
    queryKey: ['cloud-data', filePrefix],
    queryFn: () => downloadLatestData(filePrefix),
    staleTime: 1000 * 60 * 60, // 1 heure
    refetchOnWindowFocus: false
  });
}

export function useSalesData() {
  return useGoogleCloudData('sales');
}

export function usePurchasingData() {
  return useGoogleCloudData('purchasing');
}

export function useHRData() {
  return useGoogleCloudData('hr');
}

export function useLogisticsData() {
  return useGoogleCloudData('logistics');
}