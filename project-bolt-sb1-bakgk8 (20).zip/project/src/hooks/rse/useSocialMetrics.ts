import { useQuery } from '@tanstack/react-query';

interface SocialMetric {
  name: string;
  value: number;
}

// Données simulées
const mockSocialMetrics: SocialMetric[] = [
  { name: 'Égalité H/F', value: 85 },
  { name: 'Formation', value: 92 },
  { name: 'Bien-être', value: 88 },
  { name: 'Diversité', value: 78 },
  { name: 'Engagement', value: 82 }
];

export function useSocialMetrics() {
  return useQuery<SocialMetric[]>({
    queryKey: ['rse', 'social'],
    queryFn: async () => {
      await new Promise(resolve => setTimeout(resolve, 500));
      return mockSocialMetrics;
    },
    staleTime: 5 * 60 * 1000,
    cacheTime: 30 * 60 * 1000
  });
}