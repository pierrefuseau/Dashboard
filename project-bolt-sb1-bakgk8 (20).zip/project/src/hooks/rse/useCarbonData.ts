import { useQuery } from '@tanstack/react-query';

interface CarbonScope {
  name: string;
  value: number;
}

interface CarbonData {
  total: number;
  scopes: CarbonScope[];
}

// Données simulées
const mockCarbonData: CarbonData = {
  total: 1250,
  scopes: [
    { name: 'Scope 1', value: 450 },
    { name: 'Scope 2', value: 350 },
    { name: 'Scope 3', value: 450 }
  ]
};

export function useCarbonData() {
  return useQuery<CarbonData>({
    queryKey: ['rse', 'carbon'],
    queryFn: async () => {
      // Simuler un délai réseau
      await new Promise(resolve => setTimeout(resolve, 500));
      return mockCarbonData;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    cacheTime: 30 * 60 * 1000 // 30 minutes
  });
}