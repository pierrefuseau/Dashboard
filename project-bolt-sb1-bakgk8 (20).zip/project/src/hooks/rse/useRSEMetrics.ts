import { useQuery } from '@tanstack/react-query';

interface RSEMetrics {
  carbonEmissions: number;
  carbonTarget: number;
  genderEquality: number;
  genderTarget: number;
  recyclingRate: number;
  recyclingTarget: number;
  globalScore: number;
  globalTarget: number;
}

// Données simulées pour le développement
const mockData: RSEMetrics = {
  carbonEmissions: 1250,
  carbonTarget: 1000,
  genderEquality: 85,
  genderTarget: 100,
  recyclingRate: 75,
  recyclingTarget: 90,
  globalScore: 82,
  globalTarget: 90
};

export function useRSEMetrics() {
  return useQuery({
    queryKey: ['rse-metrics'],
    queryFn: async () => {
      // Simuler un délai réseau
      await new Promise(resolve => setTimeout(resolve, 1000));
      return mockData;
    }
  });
}