import { useSheetData } from '../sheets/useSheetData';

interface EnvironmentalData {
  timeline: Array<{
    period: string;
    recycling: number;
    energy: number;
    water: number;
  }>;
}

export function useEnvironmentalMetrics() {
  return useSheetData<EnvironmentalData>('RSE', 'B20:E25', {
    transform: (data) => ({
      timeline: data.map(row => ({
        period: row[0] || '',
        recycling: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0,
        energy: Number(row[2]?.replace(/[^0-9.-]/g, '')) || 0,
        water: Number(row[3]?.replace(/[^0-9.-]/g, '')) || 0
      }))
    })
  });
}