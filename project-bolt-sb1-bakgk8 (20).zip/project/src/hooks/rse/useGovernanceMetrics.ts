import { useQuery } from '@tanstack/react-query';

interface GovernanceMetric {
  name: string;
  value: number;
}

// Données simulées
const mockGovernanceMetrics: GovernanceMetric[] = [
  { name: 'Éthique', value: 90 },
  { name: 'Transparence', value: 85 },
  { name: 'Conformité', value: 95 },
  { name: 'Anti-corruption', value: 92 },
  { name: 'Gestion des risques', value: 88 }
];

export function useGovernanceMetrics() {
  return useQuery<GovernanceMetric[]>({
    queryKey: ['rse', 'governance'],
    queryFn: async () => {
      await new Promise(resolve => setTimeout(resolve, 500));
      return mockGovernanceMetrics;
    },
    staleTime: 5 * 60 * 1000,
    cacheTime: 30 * 60 * 1000
  });
}