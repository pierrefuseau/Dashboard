import { useState, useCallback } from 'react';
import axios from 'axios';
import { OPENAI_CONFIG } from '../../config/openai';

export interface Message {
  role: 'user' | 'assistant';
  content: string;
  id: string;
}

const generateId = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;

export function useAIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "Bonjour ! Je suis votre assistant IA. Je peux vous aider à analyser les données et répondre à vos questions sur les KPIs. Comment puis-je vous aider ?",
      id: generateId()
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);

  const sendMessage = useCallback(async (content: string) => {
    if (!content.trim()) return;
    if (!OPENAI_CONFIG.apiKey) {
      console.warn('Aucune clé API OpenAI n\'a été fournie');
      return;
    }

    try {
      // Ajouter le message de l'utilisateur
      const userMessage: Message = {
        role: 'user',
        content,
        id: generateId()
      };

      setMessages(prev => [...prev, userMessage]);
      setIsTyping(true);

      // Créer une copie sérialisable de l'historique des messages
      const conversationHistory = messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      // Envoyer la requête à OpenAI
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: OPENAI_CONFIG.model,
          messages: [
            {
              role: 'system',
              content: OPENAI_CONFIG.systemPrompt
            },
            ...conversationHistory,
            { role: 'user', content }
          ],
          temperature: OPENAI_CONFIG.temperature,
          max_tokens: OPENAI_CONFIG.maxTokens
        },
        {
          headers: {
            'Authorization': `Bearer ${OPENAI_CONFIG.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      // Créer un nouvel objet message pour la réponse
      const assistantMessage: Message = {
        role: 'assistant',
        content: response.data.choices[0].message.content || "Désolé, je n'ai pas pu générer de réponse.",
        id: generateId()
      };

      // Mettre à jour les messages avec une nouvelle référence
      setMessages(prev => [...prev, assistantMessage]);

    } catch (error) {
      console.error('Erreur lors de la génération de la réponse:', error);
      
      // Ajouter un message d'erreur
      const errorMessage: Message = {
        role: 'assistant',
        content: "Désolé, j'ai rencontré une erreur lors de l'analyse de votre demande. Pouvez-vous reformuler ?",
        id: generateId()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  }, [messages]);

  const clearMessages = useCallback(() => {
    setMessages([{
      role: 'assistant',
      content: "Bonjour ! Je suis votre assistant IA. Je peux vous aider à analyser les données et répondre à vos questions sur les KPIs. Comment puis-je vous aider ?",
      id: generateId()
    }]);
  }, []);

  return {
    messages,
    isTyping,
    sendMessage,
    clearMessages
  };
}