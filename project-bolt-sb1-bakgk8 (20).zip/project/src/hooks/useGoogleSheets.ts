import { useQuery } from '@tanstack/react-query';
import { fetchSalesData, type SalesData } from '../services/googleSheets';

export function useSalesData() {
  return useQuery<SalesData>({
    queryKey: ['sales'],
    queryFn: fetchSalesData,
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
    staleTime: 4 * 60 * 1000, // Consider data stale after 4 minutes
  });
}