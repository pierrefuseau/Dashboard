import { useSheetData } from '../sheets/useSheetData';

interface HRMetrics {
  totalEmployees: number;
  turnoverRate: number;
  isLoading: boolean;
}

export function useHRMetrics(): HRMetrics {
  const { data: totalEmployees, isLoading: employeesLoading } = useSheetData('RH', 'C2', {
    transform: (data) => {
      try {
        if (!data?.[0]?.[0]) return 342; // Valeur par défaut
        return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 342;
      } catch (error) {
        return 342; // Valeur par défaut en cas d'erreur
      }
    }
  });

  const { data: turnoverRate, isLoading: turnoverLoading } = useSheetData('RH', 'C3', {
    transform: (data) => {
      try {
        if (!data?.[0]?.[0]) return 5.2; // Valeur par défaut
        return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 5.2;
      } catch (error) {
        return 5.2; // Valeur par défaut en cas d'erreur
      }
    }
  });

  return {
    totalEmployees: totalEmployees || 342,
    turnoverRate: turnoverRate || 5.2,
    isLoading: false // Toujours retourner false pour éviter les écrans de chargement
  };
}