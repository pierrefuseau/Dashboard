import { useSheetData } from '../sheets/useSheetData';

export interface NewsItem {
  date: string;
  strategy: string;
  company: string;
  description: string;
  impact: string;
}

const PROCESS_COLUMNS = {
  'Direction': 'Direction',
  'Produire': 'Produire',
  'Logistique': 'Logistique',
  'Vendre': 'Vendre',
  'Qualite': 'Qualité',
  'Achats': 'Achats',
  'RH': 'RH',
  'Financer': 'Financer'
} as const;

export function useNews() {
  return useSheetData<NewsItem[]>('ACTUALITES', 'A2:I200', {
    transform: (data) => {
      if (!data?.length) return [];
      
      // Get the headers to identify columns
      const headers = data[0] || [];
      const processColumns = Object.fromEntries(
        Object.entries(PROCESS_COLUMNS).map(([key, label]) => [
          key,
          headers.findIndex(h => h?.toString().trim() === key)
        ])
      );

      // Transform the data
      return data.slice(1) // Skip header row
        .flatMap(row => {
          const date = row[0]?.toString().trim() || '';
          if (!date) return [];

          // Create news items for each process that has content
          return Object.entries(processColumns)
            .map(([process, colIndex]) => {
              if (colIndex === -1) return null;
              const content = row[colIndex]?.toString().trim() || '';
              if (!content) return null;

              return {
                date,
                strategy: PROCESS_COLUMNS[process as keyof typeof PROCESS_COLUMNS],
                company: 'ANGPIER',
                description: content,
                impact: ''
              };
            })
            .filter((item): item is NewsItem => item !== null);
        })
        .sort((a, b) => {
          // Parse dates in DD/MM/YYYY format
          const [dayA, monthA, yearA] = a.date.split('/').map(Number);
          const [dayB, monthB, yearB] = b.date.split('/').map(Number);
          const dateA = new Date(yearA, monthA - 1, dayA);
          const dateB = new Date(yearB, monthB - 1, dayB);
          return dateB.getTime() - dateA.getTime(); // Sort descending
        });
    },
    spreadsheetId: '1gPxp1kdmTQ5oOoe1sO3dUsUx4fucRg_FMdobbpESHOU'
  });
}