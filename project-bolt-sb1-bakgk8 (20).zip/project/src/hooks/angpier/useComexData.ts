import { useQuery } from '@tanstack/react-query';
import { fetchComexData } from '../../services/comex/comexService';

export function useComexData() {
  return useQuery({
    queryKey: ['comex'],
    queryFn: fetchComexData,
    staleTime: 5 * 60 * 1000, // 5 minutes
    cacheTime: 30 * 60 * 1000, // 30 minutes
    retry: 5, // Augmenter le nombre de tentatives
    retryDelay: (attemptIndex) => Math.min(1000 * Math.pow(2, attemptIndex), 30000),
    refetchOnWindowFocus: false,
    refetchOnReconnect: true,
    refetchOnMount: true,
    // Retourner des données vides en cas d'erreur
    onError: () => {
      return {
        processes: []
      };
    }
  });
}