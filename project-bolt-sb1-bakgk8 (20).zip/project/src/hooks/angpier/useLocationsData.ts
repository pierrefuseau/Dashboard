import { useSheetData } from '../sheets/useSheetData';

export interface LocationProperty {
  id: string;
  name: string;
  address: string;
  surface: number;
  rent: number | null;
  loanRemaining: number | null;
}

export interface LocationsData {
  properties: LocationProperty[];
  totalProperties: number;
  totalSurface: number;
  totalRent: number;
  totalLoanRemaining: number;
}

export function useLocationsData() {
  // Récupérer les données des bâtiments (B4:G10)
  const { data: buildingsData, isLoading: buildingsLoading } = useSheetData('IMMOBILIER', 'B4:G10', {
    transform: (data) => data.map(row => ({
      id: row[0]?.toString() || '',
      name: row[1]?.toString() || '',
      address: row[2]?.toString() || '',
      surface: Number(row[3]) || 0,
      rent: row[4] ? Number(row[4]) : null,
      loanRemaining: row[5] ? Number(row[5]) : null
    }))
  });

  // Récupérer les totaux (B11:G11)
  const { data: totalsData, isLoading: totalsLoading } = useSheetData('IMMOBILIER', 'B11:G11', {
    transform: (data) => ({
      totalProperties: Number(data[0]?.[0]) || 0,
      totalSurface: Number(data[0]?.[3]) || 0,
      totalRent: Number(data[0]?.[4]) || 0
    })
  });

  // Calculer le total des prêts restants
  const totalLoanRemaining = buildingsData?.reduce((sum, property) => 
    sum + (property.loanRemaining || 0), 0) || 0;

  return {
    properties: buildingsData || [],
    totalProperties: totalsData?.totalProperties || 0,
    totalSurface: totalsData?.totalSurface || 0,
    totalRent: totalsData?.totalRent || 0,
    totalLoanRemaining,
    isLoading: buildingsLoading || totalsLoading
  };
}