import { useQuery } from '@tanstack/react-query';
import { fetchSheetData } from '../services/sheets/sheetsClient';
import { SHEETS_CONFIG } from '../services/sheets/config';

export function useSheetData<T>(key: string, range: string) {
  return useQuery({
    queryKey: ['sheet', key, range],
    queryFn: () => fetchSheetData<T>(range),
    staleTime: 5 * 60 * 1000, // 5 minutes
    cacheTime: 30 * 60 * 1000, // 30 minutes
    retry: 2,
    refetchOnWindowFocus: false
  });
}

export function useSalesMetrics() {
  return useSheetData('sales', SHEETS_CONFIG.ranges.sales.metrics);
}

export function usePurchaseMetrics() {
  return useSheetData('purchases', SHEETS_CONFIG.ranges.purchases.metrics);
}

export function useLogisticsMetrics() {
  return useSheetData('logistics', SHEETS_CONFIG.ranges.logistics.stocks);
}