import { useSheetData } from '../sheets/useSheetData';

interface SalesMetricsData {
  revenue: number;
  margin: number;
  volume: number;
  isLoading: boolean;
  error?: string;
}

export function useSalesMetrics(): SalesMetricsData {
  // Chiffre d'affaires (C3)
  const { data: revenue, isLoading: revenueLoading, error: revenueError } = useSheetData('VENTES', 'C3', {
    transform: (data) => {
      try {
        if (!data?.[0]?.[0]) return 0;
        // Convertir la chaîne en nombre en gardant la valeur exacte
        const value = data[0][0].toString().replace(/[^0-9.-]/g, '');
        return Number(value) || 0;
      } catch (error) {
        console.error('Erreur lors de la transformation du CA:', error);
        throw new Error('Erreur lors du chargement du chiffre d\'affaires');
      }
    }
  });

  // Marge (C5)
  const { data: margin, isLoading: marginLoading, error: marginError } = useSheetData('VENTES', 'C5', {
    transform: (data) => {
      try {
        if (!data?.[0]?.[0]) return 0;
        // Convertir la chaîne en nombre en gardant la valeur exacte
        const value = data[0][0].toString().replace(/[^0-9.-]/g, '');
        return Number(value) || 0;
      } catch (error) {
        console.error('Erreur lors de la transformation de la marge:', error);
        throw new Error('Erreur lors du chargement de la marge');
      }
    }
  });

  // Volume (C7)
  const { data: volume, isLoading: volumeLoading, error: volumeError } = useSheetData('VENTES', 'C7', {
    transform: (data) => {
      try {
        if (!data?.[0]?.[0]) return 0;
        // Convertir la chaîne en nombre en gardant la valeur exacte
        const value = data[0][0].toString().replace(/[^0-9.-]/g, '');
        return Number(value) || 0;
      } catch (error) {
        console.error('Erreur lors de la transformation du volume:', error);
        throw new Error('Erreur lors du chargement du volume');
      }
    }
  });

  // Gérer les erreurs
  const error = revenueError || marginError || volumeError;

  return {
    revenue: revenue || 0,
    margin: margin || 0,
    volume: volume || 0,
    isLoading: revenueLoading || marginLoading || volumeLoading,
    error: error?.message
  };
}