import { useSheetData } from '../sheets/useSheetData';
import { numberParsers } from '../../utils/formatters/numbers';

export interface PurchaseByCountry {
  country: string;
  amount: number;
}

export function usePurchasesByCountry() {
  return useSheetData('ACHATS', 'B10:C19', {
    transform: (data) => data.map(row => ({
      country: row[0] || '',
      amount: numberParsers.fromString(row[1])
    }))
    .filter(item => item.country && item.amount > 0)
    .sort((a, b) => b.amount - a.amount)
  });
}