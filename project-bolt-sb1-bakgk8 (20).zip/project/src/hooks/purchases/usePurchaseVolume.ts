import { useSheetData } from '../sheets/useSheetData';
import { convertKgToTonnes } from '../../utils/formatters/tonnage';

export function usePurchaseVolume() {
  return useSheetData(
    'ACHATS',
    'C3',
    {
      transform: (data) => {
        if (!data?.[0]?.[0]) return 0;
        const valueInKg = Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
        return convertKgToTonnes(valueInKg * 1000); // Multiplier par 1000 avant la conversion
      }
    }
  );
}