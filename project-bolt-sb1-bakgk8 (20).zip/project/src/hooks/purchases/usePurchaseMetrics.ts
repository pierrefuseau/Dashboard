import { useSheetData } from '../sheets/useSheetData';

interface PurchaseMetricsData {
  volume: number;
  amount: number;
  activeSuppliers: number;
  isLoading: boolean;
}

export function usePurchaseMetrics(): PurchaseMetricsData {
  // Volume total (C3)
  const { data: volume, isLoading: volumeLoading } = useSheetData(
    'ACHATS',
    'C3',
    { 
      transform: (data) => {
        if (!data?.[0]?.[0]) return 0;
        // Convertir la valeur de KG en tonnes (diviser par 1000)
        const volumeInKg = Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
        return volumeInKg / 1000;
      }
    }
  );

  // Montant total (C2)
  const { data: amount, isLoading: amountLoading } = useSheetData(
    'ACHATS',
    'C2',
    { 
      transform: (data) => {
        if (!data?.[0]?.[0]) return 0;
        return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
      }
    }
  );

  // Nombre de fournisseurs actifs (C4)
  const { data: activeSuppliers, isLoading: suppliersLoading } = useSheetData(
    'ACHATS',
    'C4',
    {
      transform: (data) => {
        if (!data?.[0]?.[0]) return 0;
        return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
      }
    }
  );

  return {
    volume: volume || 0,
    amount: amount || 0,
    activeSuppliers: activeSuppliers || 0,
    isLoading: volumeLoading || amountLoading || suppliersLoading
  };
}