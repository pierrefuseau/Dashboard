import { useSheetData } from '../sheets/useSheetData';
import { RFAPartner } from '../../types/purchases';

export function useRFAPartners() {
  return useSheetData<RFAPartner[]>('ACHATS', 'E16:G25', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      currentRFA: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0,
      previousRFA: Number(row[2]?.replace(/[^0-9.-]/g, '')) || 0
    }))
    .filter(partner => partner.name && partner.currentRFA > 0)
    .sort((a, b) => b.currentRFA - a.currentRFA)
  });
}