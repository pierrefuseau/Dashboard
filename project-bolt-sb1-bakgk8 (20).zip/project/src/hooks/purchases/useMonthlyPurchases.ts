import { useSheetData } from '../sheets/useSheetData';
import { numberParsers } from '../../utils/formatters/numbers';

export interface MonthlyPurchase {
  month: string;
  amount: number;
}

export function useMonthlyPurchases() {
  return useSheetData('ACHATS', 'B22:C33', {
    transform: (data) => data.map(row => ({
      month: row[0] || '',
      amount: numberParsers.fromString(row[1])
    }))
    .filter(item => item.month && item.amount > 0)
  });
}