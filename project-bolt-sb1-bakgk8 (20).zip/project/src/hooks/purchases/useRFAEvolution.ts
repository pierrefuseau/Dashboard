import { useSheetData } from '../sheets/useSheetData';

export interface RFAEvolution {
  name: string;
  evolution: number;
}

export function useRFAEvolution() {
  return useSheetData<RFAEvolution[]>('ACHATS', 'F28:G37', {
    transform: (data) => data
      .map(row => ({
        name: row[0] || '',
        evolution: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
      }))
      .filter(item => item.name && !isNaN(item.evolution))
      .sort((a, b) => b.evolution - a.evolution)
  });
}