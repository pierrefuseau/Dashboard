import { useSheetData } from '../sheets/useSheetData';

interface QualityMetrics {
  ifsScore: number;
  conformityRate: number;
  isLoading: boolean;
}

export function useQualityMetrics(): QualityMetrics {
  const { data: ifsScore, isLoading: ifsLoading } = useSheetData('QUALITE', 'C2', {
    transform: (data) => Number(data?.[0]?.[0]?.toString().replace(/[^0-9.-]/g, '')) || 0
  });

  const { data: conformityRate, isLoading: conformityLoading } = useSheetData('QUALITE', 'C3', {
    transform: (data) => Number(data?.[0]?.[0]?.toString().replace(/[^0-9.-]/g, '')) || 0
  });

  return {
    ifsScore: ifsScore || 0,
    conformityRate: conformityRate || 0,
    isLoading: ifsLoading || conformityLoading
  };
}