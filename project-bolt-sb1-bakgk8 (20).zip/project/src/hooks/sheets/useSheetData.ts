import { useQuery } from '@tanstack/react-query';
import axios from 'axios';

const API_KEY = 'AIzaSyDKq5BKxXoOFaHjEholKS3OY5pXoT4fiY0';
const SPREADSHEET_ID = '1AyBuqiJbLkXxNhOYnK2C_gT6sn86IknCaaLwLwxAIxI';

interface UseSheetDataOptions<T> {
  transform?: (data: any[][]) => T;
  enabled?: boolean;
  spreadsheetId?: string;
}

export function useSheetData<T = string[][]>(
  sheetName: string, 
  range: string, 
  options: UseSheetDataOptions<T> = {}
) {
  const { 
    transform, 
    enabled = true, 
    spreadsheetId = SPREADSHEET_ID 
  } = options;

  return useQuery({
    queryKey: ['sheet', spreadsheetId, sheetName, range],
    queryFn: async () => {
      if (!range) {
        return transform ? transform([[]]) : [[]];
      }

      try {
        const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${sheetName}!${range}?key=${API_KEY}`;
        const response = await axios.get(url, {
          timeout: 10000,
          headers: {
            'Accept': 'application/json'
          }
        });

        // Ensure we have data
        const rawData = response.data.values || [[]];
        
        // Clean and normalize the data to ensure it's serializable
        const cleanData = rawData.map(row => 
          row.map(cell => {
            if (cell === null || cell === undefined) return '';
            // Convert everything to string to ensure serializability
            return String(cell);
          })
        );

        // Apply transformation if provided
        if (transform) {
          try {
            const transformedData = transform(cleanData);
            // Ensure the transformed data is serializable
            return JSON.parse(JSON.stringify(transformedData));
          } catch (transformError) {
            console.error('Erreur lors de la transformation des données:', transformError);
            // Retourner une valeur par défaut au lieu de propager l'erreur
            return transform([[]]);
          }
        }
        
        return cleanData;
      } catch (error) {
        console.error(`Erreur lors de la récupération des données ${sheetName}!${range}:`, error);
        
        // Retourner des données vides au lieu de propager l'erreur
        return transform ? transform([[]]) : [[]];
      }
    },
    retry: 3, // Augmenter le nombre de tentatives
    retryDelay: (attemptIndex) => Math.min(1000 * Math.pow(2, attemptIndex), 10000),
    staleTime: 60000, // Augmenter le staleTime à 1 minute
    cacheTime: 5 * 60 * 1000,
    enabled: Boolean(range) && enabled,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: true
  });
}