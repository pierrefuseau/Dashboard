import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { z } from 'zod';

const API_KEY = 'AIzaSyDKq5BKxXoOFaHjEholKS3OY5pXoT4fiY0';
const SPREADSHEET_ID = '1AyBuqiJbLkXxNhOYnK2C_gT6sn86IknCaaLwLwxAIxI';

const rangeValuesSchema = z.array(z.array(z.string()));

export function useSheetRange(sheetName: string, range: string) {
  return useQuery({
    queryKey: ['sheet-range', sheetName, range],
    queryFn: async () => {
      const url = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${sheetName}!${range}?key=${API_KEY}`;
      const response = await axios.get(url);
      return rangeValuesSchema.parse(response.data.values);
    },
    staleTime: 5 * 60 * 1000,
    cacheTime: 30 * 60 * 1000,
    retry: 2,
    refetchOnWindowFocus: false
  });
}