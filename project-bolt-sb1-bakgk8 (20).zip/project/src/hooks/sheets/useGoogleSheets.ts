import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { z } from 'zod';
import { SHEETS_CONFIG } from '../../services/sheets/config';

const sheetDataSchema = z.array(z.array(z.string()));

interface UseGoogleSheetsOptions {
  enabled?: boolean;
  refetchInterval?: number;
}

export function useGoogleSheets(sheetName: string, range: string, options: UseGoogleSheetsOptions = {}) {
  return useQuery({
    queryKey: ['sheets', sheetName, range],
    queryFn: async () => {
      const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEETS_CONFIG.spreadsheetId}/values/${sheetName}!${range}?key=${SHEETS_CONFIG.apiKey}`;
      const response = await axios.get(url);
      return sheetDataSchema.parse(response.data.values);
    },
    staleTime: 5 * 60 * 1000,
    cacheTime: 30 * 60 * 1000,
    retry: 2,
    refetchOnWindowFocus: false,
    ...options
  });
}

export function useSalesData() {
  return useGoogleSheets(
    SHEETS_CONFIG.sheets.dashboard,
    SHEETS_CONFIG.ranges.sales.metrics
  );
}

export function usePurchaseData() {
  return useGoogleSheets(
    SHEETS_CONFIG.sheets.achats,
    SHEETS_CONFIG.ranges.purchases.total
  );
}

export function useLogisticsData() {
  return useGoogleSheets(
    SHEETS_CONFIG.sheets.logistique,
    SHEETS_CONFIG.ranges.logistics.stocks
  );
}