import { useQueryClient } from '@tanstack/react-query';

export function useSheetRefresh() {
  const queryClient = useQueryClient();

  const refreshAllSheets = async () => {
    await queryClient.invalidateQueries({ queryKey: ['sheet'] });
  };

  const refreshSheet = async (sheetName: string) => {
    await queryClient.invalidateQueries({ queryKey: ['sheet', sheetName] });
  };

  return {
    refreshAllSheets,
    refreshSheet
  };
}