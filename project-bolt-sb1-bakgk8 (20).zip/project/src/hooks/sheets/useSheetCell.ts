import { useSheetData } from './useSheetData';

interface UseSheetCellOptions {
  transform?: (value: string) => number;
}

export function useSheetCell(sheetName: string, cell: string, options: UseSheetCellOptions = {}) {
  const { data, isLoading, error } = useSheetData(sheetName, `${cell}:${cell}`, {
    transform: (data) => {
      const value = data?.[0]?.[0] || '';
      if (options.transform) {
        return options.transform(value);
      }
      return Number(value.toString().replace(/[^0-9.-]/g, '')) || 0;
    }
  });

  return { data, isLoading, error };
}