import { useCallback, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';

interface ErrorOptions {
  retry?: boolean;
  notify?: boolean;
}

export function useErrorHandler() {
  const queryClient = useQueryClient();
  const [lastError, setLastError] = useState<string | null>(null);

  const handleError = useCallback((error: unknown, options: ErrorOptions = {}) => {
    const { retry = true, notify = true } = options;

    // Log l'erreur
    console.error('Error caught by handler:', error);

    // Formater le message d'erreur
    let errorMessage = 'Une erreur est survenue';
    if (error instanceof Error) {
      errorMessage = error.message;
    } else if (typeof error === 'string') {
      errorMessage = error;
    }

    // Stocker l'erreur
    setLastError(errorMessage);

    // Notification à l'utilisateur si demandé
    if (notify) {
      // Nous utilisons simplement console.warn pour l'instant
      console.warn('User notification:', errorMessage);
    }

    // Réessayer la requête si demandé
    if (retry) {
      queryClient.invalidateQueries();
    }

    return errorMessage;
  }, [queryClient]);

  const clearError = useCallback(() => {
    setLastError(null);
  }, []);

  return { 
    handleError, 
    clearError,
    lastError 
  };
}