import { useSheetData } from '../sheets/useSheetData';

interface TopMargin {
  name: string;
  margin: number;
}

export function useTopMargins() {
  return useSheetData('BOUTIQUE', 'B30:C40', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      // Divide by 100 to convert to proper percentage
      margin: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 100 || 0
    })).filter(product => product.name && product.margin > 0)
  });
}