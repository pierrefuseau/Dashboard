import { useSheetData } from '../sheets/useSheetData';

interface TopProduct {
  name: string;
  revenue: number;
}

export function useTopProducts() {
  return useSheetData('BOUTIQUE', 'B19:C28', {
    transform: (data) => data
      .map(row => ({
        name: row[0] || '',
        revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 100 || 0
      }))
      .filter(product => product.name && product.revenue > 0)
      .sort((a, b) => b.revenue - a.revenue) // Tri par CA décroissant
  });
}