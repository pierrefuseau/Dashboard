import { useSheetData } from '../sheets/useSheetData';

interface BoutiqueMetrics {
  dailyRevenue: number;
  monthlyRevenue: number;
  monthlyMargin: number;
  customerCount: number;
  isLoading: boolean;
}

export function useBoutiqueMetrics(): BoutiqueMetrics {
  // CA du jour (C3)
  const { data: dailyRevenue, isLoading: dailyLoading } = useSheetData('BOUTIQUE', 'C3', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      // Ne pas diviser par 100 pour conserver la valeur exacte
      return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
    }
  });

  // CA début de mois (C13)
  const { data: monthlyRevenue, isLoading: monthlyLoading } = useSheetData('BOUTIQUE', 'C13', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      // Ne pas diviser par 100 pour conserver la valeur exacte
      return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
    }
  });

  // Marge mensuelle (C14)
  const { data: monthlyMargin, isLoading: marginLoading } = useSheetData('BOUTIQUE', 'C14', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      // Diviser par 100 pour convertir en pourcentage
      return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) / 100 || 0;
    }
  });

  // Nombre de clients du jour (C7)
  const { data: customerCount, isLoading: customerLoading } = useSheetData('BOUTIQUE', 'C7', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      // Pas de division car c'est un nombre entier
      return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
    }
  });

  return {
    dailyRevenue: dailyRevenue || 0,
    monthlyRevenue: monthlyRevenue || 0,
    monthlyMargin: monthlyMargin || 0,
    customerCount: customerCount || 0,
    isLoading: dailyLoading || monthlyLoading || marginLoading || customerLoading
  };
}