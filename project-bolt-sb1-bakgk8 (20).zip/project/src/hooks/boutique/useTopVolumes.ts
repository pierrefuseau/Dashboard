import { useSheetData } from '../sheets/useSheetData';

interface TopVolume {
  name: string;
  volume: number;
}

export function useTopVolumes() {
  return useSheetData('BOUTIQUE', 'E19:F28', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      volume: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
    })).filter(product => product.name && product.volume > 0)
  });
}