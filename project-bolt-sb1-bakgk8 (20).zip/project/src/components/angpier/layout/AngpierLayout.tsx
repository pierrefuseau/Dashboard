import React, { useState } from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { AngpierSidebar } from '../navigation/AngpierSidebar';
import { AIAssistant } from '../../ai/AIAssistant';
import { Menu, X } from 'lucide-react';
import { cn } from '../../../utils/cn';
import { useAuthStore } from '../../../store/authStore';
import { UserProfileButton } from '../../user/UserProfileButton';
import { CompanySelector } from '../../dashboard/CompanySelector';

export function AngpierLayout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user } = useAuthStore();

  // Vérifier si l'utilisateur a accès à ANGPIER
  const hasAngpierAccess = user?.permissions?.includes('ADMIN') || 
                         user?.permissions?.includes('VENTES') || 
                         user?.permissions?.includes('BOUTIQUE') || 
                         user?.permissions?.includes('COMEX');

  if (!hasAngpierAccess) {
    return <Navigate to="/403" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-white border-b border-gray-200 px-4 h-16 flex items-center">
        <button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="p-2 rounded-lg text-gray-600 hover:bg-gray-100"
        >
          {isSidebarOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <Menu className="w-6 h-6" />
          )}
        </button>
      </div>

      <div className="flex">
        {/* Overlay pour mobile */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}
        
        {/* Sidebar */}
        <div className={cn(
          "fixed inset-y-0 left-0 z-30 transform transition-transform duration-300 ease-in-out lg:translate-x-0",
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}>
          <div className="flex flex-col h-full">
            {/* Contenu principal de la sidebar */}
            <div className="flex-1 overflow-y-auto">
              <AngpierSidebar onClose={() => setIsSidebarOpen(false)} />
            </div>
            
            {/* Boutons en bas de la sidebar */}
            <div className="p-4 space-y-2">
              <AIAssistant />
              <CompanySelector />
              <UserProfileButton />
            </div>
          </div>
        </div>
        
        {/* Contenu principal */}
        <div className="flex-1 lg:pl-64">
          <main className="flex-1">
            <div className="max-w-[2000px] mx-auto p-4 sm:p-6 lg:p-8 mt-16 lg:mt-0">
              <Outlet />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}