import React from 'react';
import { 
  BarChart2, 
  Factory,
  Truck,
  ShoppingCart,
  ClipboardCheck,
  Users,
  Calculator,
  Building2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '../../../utils/cn';

const processes = [
  { 
    id: 'direction',
    name: 'Direction',
    icon: Building2,
    color: 'from-blue-500/80 to-blue-600/80',
    description: 'Indicateurs stratégiques'
  },
  { 
    id: 'produire',
    name: 'Produire',
    icon: Factory,
    color: 'from-amber-500/80 to-amber-600/80',
    description: 'Performance de production'
  },
  { 
    id: 'logistique',
    name: 'Logistique',
    icon: Truck,
    color: 'from-orange-500/80 to-orange-600/80',
    description: 'Flux et stocks'
  },
  { 
    id: 'vendre',
    name: 'Vendre',
    icon: BarChart2,
    color: 'from-green-500/80 to-green-600/80',
    description: 'Performance commerciale'
  },
  { 
    id: 'qualite',
    name: 'Qualité',
    icon: ClipboardCheck,
    color: 'from-yellow-500/80 to-yellow-600/80',
    description: 'Conformité et audits'
  },
  { 
    id: 'achat',
    name: 'Achat',
    icon: ShoppingCart,
    color: 'from-red-500/80 to-red-600/80',
    description: 'Performance fournisseurs'
  },
  { 
    id: 'rh',
    name: 'RH',
    icon: Users,
    color: 'from-violet-500/80 to-violet-600/80',
    description: 'Indicateurs sociaux'
  },
  { 
    id: 'financer',
    name: 'Financer',
    icon: Calculator,
    color: 'from-indigo-500/80 to-indigo-600/80',
    description: 'Performance financière'
  }
];

interface ComexNavigationProps {
  activeProcess: string;
  onProcessSelect: (processId: string) => void;
}

export function ComexNavigation({ activeProcess, onProcessSelect }: ComexNavigationProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
      {processes.map((process) => {
        const Icon = process.icon;
        const isActive = process.id === activeProcess;
        
        return (
          <motion.button
            key={process.id}
            onClick={() => onProcessSelect(process.id)}
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            className={cn(
              "relative px-4 py-3 rounded-lg border transition-all duration-200",
              "bg-gradient-to-br shadow-sm overflow-hidden group",
              isActive 
                ? `${process.color} text-white border-transparent` 
                : "hover:bg-gray-50/80 border-gray-200/80"
            )}
          >
            {/* Effet de brillance au hover */}
            <div className={cn(
              "absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0",
              "translate-x-[-100%] group-hover:translate-x-[100%]",
              "transition-transform duration-1000"
            )} />

            <div className="relative flex items-center space-x-3">
              <div className={cn(
                "flex-shrink-0 p-2 rounded-md transition-colors",
                isActive ? "bg-white/10" : "bg-gray-100/80"
              )}>
                <Icon className={cn(
                  "w-5 h-5",
                  isActive ? "text-white" : "text-gray-600"
                )} />
              </div>
              <div className="flex-1 min-w-0 text-left">
                <h3 className={cn(
                  "text-sm font-medium truncate",
                  isActive ? "text-white" : "text-gray-900"
                )}>
                  {process.name}
                </h3>
                <p className={cn(
                  "text-xs truncate mt-0.5",
                  isActive ? "text-white/80" : "text-gray-500"
                )}>
                  {process.description}
                </p>
              </div>
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}