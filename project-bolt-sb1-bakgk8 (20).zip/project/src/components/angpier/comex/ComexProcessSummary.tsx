import React from 'react';
import { Card } from '../../common/Card';
import { AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '../../../utils/cn';

interface ComexProcessSummaryProps {
  title: string;
  indicators: any[];
  onShowGraph: (indicator: any) => void;
  variant: 'critical' | 'warning';
}

export function ComexProcessSummary({ 
  title, 
  indicators, 
  onShowGraph,
  variant
}: ComexProcessSummaryProps) {
  const getVariantStyles = () => {
    switch (variant) {
      case 'critical':
        return {
          border: 'border-red-500',
          bg: 'bg-red-50',
          text: 'text-red-600',
          icon: AlertTriangle
        };
      case 'warning':
        return {
          border: 'border-yellow-500',
          bg: 'bg-yellow-50',
          text: 'text-yellow-600',
          icon: AlertTriangle
        };
      default:
        return {
          border: 'border-gray-200',
          bg: 'bg-gray-50',
          text: 'text-gray-600',
          icon: AlertTriangle
        };
    }
  };

  const styles = getVariantStyles();
  const Icon = styles.icon;

  return (
    <Card className={cn("border-l-4", styles.border)}>
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className={cn("p-2 rounded-lg", styles.bg)}>
            <Icon className={cn("w-6 h-6", styles.text)} />
          </div>
          <h3 className="text-xl font-bold text-gray-900">{title}</h3>
        </div>

        <div className="space-y-4">
          {indicators.map((indicator) => {
            const variance = ((indicator.value - indicator.target) / indicator.target) * 100;
            const isPositive = variance > 0;

            return (
              <div
                key={indicator.id}
                onClick={() => onShowGraph(indicator)}
                className={cn(
                  "p-4 rounded-lg transition-all cursor-pointer",
                  "hover:shadow-md hover:scale-[1.01]",
                  styles.bg
                )}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="text-lg font-semibold text-gray-900">
                        {indicator.name}
                      </h4>
                      <span className="text-sm text-gray-500">
                        ({indicator.company})
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      {indicator.id}
                    </p>
                  </div>

                  <div className="flex items-center space-x-6">
                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-500">
                        Valeur actuelle
                      </div>
                      <div className="text-xl font-bold text-gray-900">
                        {indicator.value}{indicator.unit}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-500">
                        Objectif
                      </div>
                      <div className="text-xl font-bold text-gray-900">
                        {indicator.target}{indicator.unit}
                      </div>
                    </div>

                    <div className={cn(
                      "flex items-center space-x-1 px-3 py-1.5 rounded-full",
                      isPositive ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
                    )}>
                      {isPositive ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                      <span className="font-semibold">
                        {Math.abs(variance).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Card>
  );
}