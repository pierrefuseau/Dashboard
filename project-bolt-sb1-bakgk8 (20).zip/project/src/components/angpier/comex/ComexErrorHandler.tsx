import React from 'react';
import { RefreshCw } from 'lucide-react';

interface ComexErrorHandlerProps {
  error: Error | null;
  onRetry: () => void;
  children: React.ReactNode;
}

export function ComexErrorHandler({ error, onRetry, children }: ComexErrorHandlerProps) {
  // Toujours afficher les enfants, même en cas d'erreur
  return <>{children}</>;
}