import React from 'react';
import { cn } from '../../../utils/cn';
import { getProcessTheme } from '../../../config/processThemes';
import { Card } from '../../common/Card';

interface Indicator {
  id: string;
  name: string;
  company: string;
  target: number;
  unit: string;
  frequency: string;
  average: number;
}

interface Process {
  id: string;
  name: string;
  indicators: Indicator[];
}

interface ComexProcessTableProps {
  process: Process;
  onShowGraph: (indicator: Indicator) => void;
}

const formatValue = (value: number, unit: string) => {
  // Ne pas ajouter d'unité si c'est un nombre
  if (unit.toLowerCase() === 'nombre') {
    return value.toLocaleString('fr-FR');
  }
  return `${value}${unit}`;
};

export function ComexProcessTable({ process, onShowGraph }: ComexProcessTableProps) {
  const theme = getProcessTheme(process.id);

  return (
    <Card>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className={cn("bg-opacity-90", theme.light)}>
            <tr>
              <th className={cn(
                "px-6 py-4 text-left text-base font-bold uppercase tracking-wider",
                theme.text
              )}>
                Indicateur
              </th>
              <th className={cn(
                "px-6 py-4 text-left text-base font-bold uppercase tracking-wider",
                theme.text
              )}>
                Entreprise
              </th>
              <th className={cn(
                "px-6 py-4 text-left text-base font-bold uppercase tracking-wider",
                theme.text
              )}>
                Unité
              </th>
              <th className={cn(
                "px-6 py-4 text-left text-base font-bold uppercase tracking-wider",
                theme.text
              )}>
                Fréquence
              </th>
              <th className={cn(
                "px-6 py-4 text-right text-base font-bold uppercase tracking-wider",
                theme.text
              )}>
                Objectif
              </th>
              <th className={cn(
                "px-6 py-4 text-right text-base font-bold uppercase tracking-wider",
                theme.text
              )}>
                Moyenne
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-100">
            {process.indicators.map((indicator) => (
              <tr 
                key={indicator.id}
                onClick={() => onShowGraph(indicator)}
                className={cn(
                  "cursor-pointer transition-colors duration-150",
                  "hover:bg-gray-50 hover:shadow-sm",
                  "group"
                )}
              >
                <td className="px-6 py-5 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="ml-4">
                      <div className={cn(
                        "text-lg font-semibold",
                        theme.text,
                        "group-hover:text-gray-900"
                      )}>
                        {indicator.name}
                      </div>
                      <div className="text-sm text-gray-500 mt-0.5">
                        {indicator.id}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-5 whitespace-nowrap">
                  <div className="text-base font-medium text-gray-900">
                    {indicator.company}
                  </div>
                </td>
                <td className="px-6 py-5 whitespace-nowrap">
                  <span className="inline-flex items-center px-3 py-1.5 rounded-full bg-gray-100 text-gray-800 text-base font-medium">
                    {indicator.unit}
                  </span>
                </td>
                <td className="px-6 py-5 whitespace-nowrap">
                  <div className="text-base font-medium text-gray-900">
                    {indicator.frequency}
                  </div>
                </td>
                <td className="px-6 py-5 whitespace-nowrap text-right">
                  <div className="text-lg font-semibold text-gray-900">
                    {formatValue(indicator.target, indicator.unit)}
                  </div>
                </td>
                <td className="px-6 py-5 whitespace-nowrap text-right">
                  <div className="text-lg font-semibold text-gray-900">
                    {formatValue(indicator.average, indicator.unit)}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}