import React from 'react';
import { ComexProcessTable } from './ComexProcessTable';
import { Card } from '../../common/Card';
import { cn } from '../../../utils/cn';
import { getProcessTheme } from '../../../config/processThemes';
import { Tooltip } from '../../common/Tooltip';
import { Info } from 'lucide-react';

interface ComexProcessContentProps {
  process: {
    id: string;
    name: string;
    indicators: any[];
  };
  onShowGraph: (indicator: any) => void;
}

export function ComexProcessContent({ process, onShowGraph }: ComexProcessContentProps) {
  const theme = getProcessTheme(process.id);

  return (
    <div className="space-y-6">
      {/* Tableau complet des indicateurs */}
      <ComexProcessTable
        process={process}
        onShowGraph={onShowGraph}
      />
    </div>
  );
}