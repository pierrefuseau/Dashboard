import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download, ChevronLeft, ChevronRight } from 'lucide-react';
import { ComexProcessChart } from './ComexProcessChart';
import { getProcessTheme } from '../../../config/processThemes';
import { cn } from '../../../utils/cn';

interface ComexGraphModalProps {
  isOpen: boolean;
  onClose: () => void;
  indicator: any;
  process: any;
  onNextIndicator?: () => void;
  onPreviousIndicator?: () => void;
}

export function ComexGraphModal({ 
  isOpen, 
  onClose, 
  indicator, 
  process,
  onNextIndicator,
  onPreviousIndicator 
}: ComexGraphModalProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      
      switch (e.key) {
        case 'Escape':
          onClose();
          break;
        case 'ArrowLeft':
          onPreviousIndicator?.();
          break;
        case 'ArrowRight':
          onNextIndicator?.();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, onNextIndicator, onPreviousIndicator]);

  if (!indicator || !process) return null;

  const theme = getProcessTheme(process.id);

  const formatValue = (value: number) => {
    if (indicator.unit === '%') return `${value}%`;
    if (indicator.unit === '€') return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0
    }).format(value);
    return value.toLocaleString('fr-FR');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm"
          onClick={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
        >
          <div className="absolute inset-0 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="bg-white w-full max-w-7xl rounded-2xl shadow-2xl overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              {/* En-tête avec le thème du processus */}
              <div className={cn(
                "px-6 py-4 border-b",
                "bg-gradient-to-r",
                theme.gradient,
                "bg-opacity-95"
              )}>
                <div className="flex items-start justify-between">
                  <div className="pr-8">
                    <div className="flex items-center space-x-3">
                      <span className={cn(
                        "px-2.5 py-1 rounded-full text-xs font-medium",
                        "bg-white/30 text-white"
                      )}>
                        {process.name}
                      </span>
                      <span className="px-2.5 py-1 bg-white/20 text-white rounded-full text-xs font-medium">
                        {indicator.frequency}
                      </span>
                      <span className="px-2.5 py-1 bg-white/20 text-white rounded-full text-xs font-medium">
                        Unité : {indicator.unit}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold text-white mt-2 drop-shadow-sm">
                      {indicator.name}
                    </h3>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => {/* Logique d'export */}}
                      className="p-2 text-white hover:bg-white/20 rounded-full transition-colors"
                      title="Exporter les données"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                    <button
                      onClick={onClose}
                      className="p-2 text-white hover:bg-white/20 rounded-full transition-colors"
                      title="Fermer"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {/* Métriques clés */}
                <div className="grid grid-cols-2 gap-6 mt-6">
                  <div className="bg-white/30 backdrop-blur-sm p-4 rounded-xl">
                    <p className="text-sm font-medium text-white">Objectif</p>
                    <p className="mt-1 text-2xl font-bold text-white drop-shadow-sm">
                      {formatValue(indicator.target)}
                    </p>
                  </div>
                  <div className="bg-white/30 backdrop-blur-sm p-4 rounded-xl">
                    <p className="text-sm font-medium text-white">Moyenne</p>
                    <p className="mt-1 text-2xl font-bold text-white drop-shadow-sm">
                      {formatValue(indicator.average)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Contenu du graphique */}
              <div className="p-6 bg-white relative">
                <ComexProcessChart
                  process={process}
                  indicator={indicator}
                  company="Groupe"
                  frequency="monthly"
                />

                {/* Boutons de navigation */}
                {onPreviousIndicator && (
                  <button
                    onClick={onPreviousIndicator}
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/80 shadow-lg hover:bg-white transition-colors"
                    title="Indicateur précédent"
                  >
                    <ChevronLeft className="w-6 h-6 text-gray-700" />
                  </button>
                )}

                {onNextIndicator && (
                  <button
                    onClick={onNextIndicator}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/80 shadow-lg hover:bg-white transition-colors"
                    title="Indicateur suivant"
                  >
                    <ChevronRight className="w-6 h-6 text-gray-700" />
                  </button>
                )}
              </div>

              {/* Pied de page avec informations complémentaires */}
              <div className="px-6 py-4 bg-gradient-to-b from-white to-gray-50 border-t">
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>Dernière mise à jour : {new Date().toLocaleDateString('fr-FR')}</span>
                  <span>Source : Google Sheets COMEX</span>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}