import React from 'react';
import { Building2 } from 'lucide-react';

interface LogoFallbackProps {
  company: string;
}

export function LogoFallback({ company }: LogoFallbackProps) {
  return (
    <div className="flex items-center space-x-3 bg-gray-100 px-4 py-2 rounded-lg">
      <Building2 className="w-6 h-6 text-gray-600" />
      <span className="text-lg font-medium text-gray-900">{company}</span>
    </div>
  );
}