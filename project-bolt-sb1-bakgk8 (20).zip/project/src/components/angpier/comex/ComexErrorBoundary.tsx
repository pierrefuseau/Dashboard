import React from 'react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
  retryCount: number;
}

const MAX_RETRIES = 3;
const RETRY_DELAY = 2000; // 2 secondes

export class ComexErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, retryCount: 0 };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, retryCount: 0 };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Erreur dans ComexErrorBoundary:', error, errorInfo);
  }

  handleRetry = async () => {
    if (this.state.retryCount >= MAX_RETRIES) {
      return;
    }

    this.setState(prev => ({ retryCount: prev.retryCount + 1 }));

    await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
    
    this.setState({ hasError: false });
  };

  render() {
    // Toujours afficher les enfants, même en cas d'erreur
    return this.props.children;
  }
}