import React from 'react';
import { Card } from '../../common/Card';
import { ArrowUpRight, ArrowDownRight, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { cn } from '../../../utils/cn';

interface Indicator {
  id: string;
  name: string;
  value: number;
  target: number;
  unit: string;
  trend: number;
  frequency: string;
  company: string;
  monthlyData: Array<{
    month: string;
    value: number;
    target: number;
  }>;
}

interface ComexKPICardProps {
  indicator: Indicator;
  process: string;
}

export function ComexKPICard({ indicator, process }: ComexKPICardProps) {
  const variance = ((indicator.value - indicator.target) / indicator.target) * 100;
  const isPositive = variance >= 0;

  const formatValue = (value: number) => {
    if (indicator.unit === '%') return `${value}%`;
    if (indicator.unit === '€') return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0
    }).format(value);
    return value.toLocaleString('fr-FR');
  };

  return (
    <Card className="overflow-hidden">
      {/* En-tête avec les informations essentielles */}
      <div className="px-4 pt-4 pb-2">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-medium text-gray-500">{indicator.id}</span>
            <span className="text-xs text-gray-400">•</span>
            <span className="text-xs font-medium text-gray-500">{indicator.frequency}</span>
          </div>
          <div className={cn(
            "flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-medium",
            isPositive ? "text-red-600 bg-red-50" : "text-green-600 bg-green-50"
          )}>
            {isPositive ? (
              <ArrowUpRight className="w-3 h-3" />
            ) : (
              <ArrowDownRight className="w-3 h-3" />
            )}
            <span>{Math.abs(variance).toFixed(1)}%</span>
          </div>
        </div>

        <h4 className="text-sm font-medium text-gray-900 mb-2 truncate">
          {indicator.name}
        </h4>

        <div className="flex items-baseline space-x-2">
          <span className="text-base font-semibold text-gray-900">
            {formatValue(indicator.value)}
          </span>
          <span className="text-xs text-gray-500">
            / {formatValue(indicator.target)}
          </span>
        </div>
      </div>

      {/* Graphique */}
      <div className="h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={indicator.monthlyData} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis 
              dataKey="month" 
              tick={{ fill: '#6B7280', fontSize: 10 }}
              tickLine={false}
            />
            <YAxis
              tickFormatter={formatValue}
              tick={{ fill: '#6B7280', fontSize: 10 }}
              tickLine={false}
              axisLine={false}
            />
            <Tooltip
              formatter={(value: number) => [formatValue(value), indicator.name]}
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #E5E7EB',
                borderRadius: '0.5rem',
                fontSize: '0.875rem'
              }}
            />
            {/* Ligne d'objectif en rouge */}
            <ReferenceLine
              y={indicator.target}
              stroke="#EF4444" // Rouge (red-500)
              strokeWidth={2}
              strokeDasharray="3 3"
            />
            <Line
              type="monotone"
              dataKey="value"
              stroke="#3B82F6"
              strokeWidth={2}
              dot={{ fill: '#3B82F6', r: 2 }}
              activeDot={{ r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}