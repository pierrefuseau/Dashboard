import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { Card } from '../../common/Card';
import { LoadingSpinner } from '../../common/LoadingSpinner';
import { Newspaper } from 'lucide-react';

interface ProcessNews {
  date: string;
  content: string;
}

interface ProcessNewsFeedProps {
  processId: string;
}

export function ProcessNewsFeed({ processId }: ProcessNewsFeedProps) {
  const { data: news, isLoading } = useSheetData<ProcessNews[]>('ACTUALITES', 'A2:I200', {
    transform: (data) => {
      if (!data?.length) return [];

      // Get headers and find process column index
      const headers = data[0];
      const processIndex = headers.findIndex(
        header => header?.toString().toLowerCase() === processId.toLowerCase()
      );

      if (processIndex === -1) return [];

      // Transform data
      return data.slice(1) // Skip header row
        .map(row => ({
          date: row[0]?.toString() || '',
          content: row[processIndex]?.toString() || ''
        }))
        .filter(item => item.date && item.content) // Keep only items with content
        .sort((a, b) => {
          // Parse dates in DD/MM/YYYY format
          const [dayA, monthA, yearA] = a.date.split('/').map(Number);
          const [dayB, monthB, yearB] = b.date.split('/').map(Number);
          const dateA = new Date(yearA, monthA - 1, dayA);
          const dateB = new Date(yearB, monthB - 1, dayB);
          return dateB.getTime() - dateA.getTime(); // Sort descending
        });
    }
  });

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-32">
          <LoadingSpinner />
        </div>
      </Card>
    );
  }

  if (!news?.length) {
    return (
      <Card>
        <div className="flex flex-col items-center justify-center h-32 text-gray-500">
          <Newspaper className="w-8 h-8 mb-2" />
          <p>Aucune actualité disponible</p>
        </div>
      </Card>
    );
  }

  return (
    <Card>
      <div className="mb-4">
        <h3 className="text-lg font-medium text-gray-900">Actualités du processus</h3>
      </div>

      <div className="space-y-4">
        {news.map((item, index) => {
          // Parse date
          const [day, month, year] = item.date.split('/');
          const date = new Date(Number(year), Number(month) - 1, Number(day));

          return (
            <motion.div
              key={`${item.date}-${index}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center border border-gray-200">
                    <span className="text-sm font-medium text-gray-900">
                      {format(date, 'MMM', { locale: fr })}
                    </span>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-sm font-medium text-gray-900">
                      {format(date, 'dd MMMM yyyy', { locale: fr })}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700">{item.content}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </Card>
  );
}