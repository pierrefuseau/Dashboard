import React from 'react';
import { Card } from '../../common/Card';
import { Info } from 'lucide-react';

export function ComexDocumentation() {
  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Info className="w-5 h-5 text-blue-500" />
          <h3 className="text-lg font-medium text-gray-900">Documentation</h3>
        </div>

        <div className="space-y-6">
          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-2">Méthodologie des calculs</h4>
            <div className="bg-gray-50 rounded-lg p-4">
              <ul className="text-sm text-gray-600 space-y-2">
                <li><strong>Moyennes :</strong> Calculées sur les mois disponibles de l'année en cours</li>
                <li><strong>Écarts objectifs :</strong> (Valeur - Objectif) / Objectif * 100</li>
                <li><strong>Tendances :</strong> Comparaison avec le même mois de l'année précédente</li>
              </ul>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-2">Fréquence et origine des données</h4>
            <div className="bg-gray-50 rounded-lg p-4">
              <ul className="text-sm text-gray-600 space-y-2">
                <li><strong>Source :</strong> Google Sheets COMEX</li>
                <li><strong>Mise à jour :</strong> Automatique quotidienne à 6h00</li>
                <li><strong>Historique :</strong> Conservation des données sur 24 mois glissants</li>
              </ul>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-2">Légende des indicateurs</h4>
            <div className="bg-gray-50 rounded-lg p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                <span className="text-sm text-gray-600">Objectif atteint</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
                <span className="text-sm text-gray-600">À surveiller (écart 5-10%)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                <span className="text-sm text-gray-600">Critique (écart &gt;10%)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}