import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Legend } from 'recharts';
import { getProcessTheme } from '../../../config/processThemes';
import { LogoFallback } from './LogoFallback';
import ReactDOM from 'react-dom';

interface Process {
  id: string;
  name: string;
  indicators: Array<{
    id: string;
    name: string;
    monthlyData: Array<{
      month: string;
      value: number;
      target: number;
    }>;
  }>;
}

interface ComexProcessChartProps {
  process: Process;
  indicator: {
    id: string;
    name: string;
    company: string;
    target: number;
    unit: string;
    monthlyData: Array<{
      month: string;
      value: number;
      target: number;
    }>;
  };
  company: string;
  frequency: 'monthly' | 'quarterly' | 'yearly';
}

// Logos avec fallbacks
const COMPANY_LOGOS: Record<string, { primary: string; fallback?: string }> = {
  'FUSEAU': {
    primary: 'https://www.fuseau-sas.com/media/952906/1/0/1/Logo-nouvelle-couleur+%281%29.png',
    fallback: 'https://www.fuseau-sas.com/frontend/images/logo-fuseau.png'
  },
  'DELICES AGRO': {
    primary: 'https://www.delicesagro.com/front/fonts/logo-delices-agro-dark.svg',
    fallback: 'https://www.delicesagro.com/front/fonts/logo-delices-agro-light.svg'
  },
  'GROUPE': {
    primary: 'https://www.fuseau-sas.com/media/971484/1/0/1/php20ucBg'
  },
  'C\'PROPRE': {
    primary: 'https://drive.google.com/uc?export=view&id=1JTM9lPz3LuFi6ip5GOOpMpRPDeYpY7vj'
  }
};

const COMPANY_COLORS = {
  'FUSEAU': '#3B82F6',
  'DELICES AGRO': '#10B981',
  'C\'PROPRE': '#F59E0B',
  'GROUPE': '#6366F1',
  'DEFAULT': '#9CA3AF'
};

export function ComexProcessChart({ process, indicator, company, frequency }: ComexProcessChartProps) {
  if (!indicator) return null;

  const theme = getProcessTheme(process.id);

  // Trouver tous les indicateurs avec le même ID
  const relatedIndicators = process.indicators.filter(ind => ind.id === indicator.id);
  
  // Préparer les données combinées en filtrant les mois sans données ou avec valeur 0
  const combinedData = indicator.monthlyData
    .map(monthData => {
      const monthEntry = { month: monthData.month };
      let hasData = false;

      relatedIndicators.forEach(ind => {
        const matchingData = ind.monthlyData.find(m => m.month === monthData.month);
        // Ne garder que les valeurs strictement supérieures à 0
        if (matchingData && matchingData.value > 0) {
          monthEntry[ind.company] = matchingData.value;
          monthEntry[`${ind.company}_target`] = ind.target;
          hasData = true;
        }
      });

      return hasData ? monthEntry : null;
    })
    .filter((entry): entry is Record<string, any> => entry !== null);

  // Calculer les valeurs min et max pour optimiser l'échelle du graphique
  const allValues = combinedData.flatMap(entry => 
    Object.entries(entry)
      .filter(([key]) => key !== 'month' && !key.endsWith('_target'))
      .map(([_, value]) => value as number)
  );
  
  const allTargets = relatedIndicators.map(ind => ind.target);
  const allDataPoints = [...allValues, ...allTargets];
  
  // Calculer les min et max avec une marge de 10%
  const dataMin = Math.min(...allDataPoints);
  const dataMax = Math.max(...allDataPoints);
  const range = dataMax - dataMin;
  
  // Définir les limites du domaine avec une marge de 10% pour une meilleure lisibilité
  const yAxisMin = Math.max(0, dataMin - (range * 0.1));
  const yAxisMax = dataMax + (range * 0.1);

  // Formater les valeurs selon le type d'unité
  const formatValue = (value: number) => {
    if (value === undefined || value === null) return 'N/A';
    if (indicator.unit.toLowerCase() === 'nombre') {
      return value.toLocaleString('fr-FR');
    }
    return `${value}${indicator.unit}`;
  };

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement>, company: string) => {
    const img = e.currentTarget;
    const companyConfig = COMPANY_LOGOS[company];
    
    if (companyConfig?.fallback && img.src !== companyConfig.fallback) {
      img.src = companyConfig.fallback;
    } else {
      img.style.display = 'none';
      const container = img.parentElement;
      if (container) {
        const fallbackElement = document.createElement('div');
        ReactDOM.render(<LogoFallback company={company} />, fallbackElement);
        container.appendChild(fallbackElement.firstChild!);
      }
    }
  };

  return (
    <div className="p-6">
      {/* En-tête avec logos et informations */}
      <div className="flex flex-col space-y-6 mb-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">
            {indicator.name}
          </h2>
          {indicator.unit.toLowerCase() !== 'nombre' && (
            <div className="px-8 py-4 bg-gray-100 rounded-xl shadow-sm">
              <span className="text-2xl font-bold text-gray-900">
                Unité : {indicator.unit}
              </span>
            </div>
          )}
        </div>

        {/* Logos des entreprises */}
        <div className="flex flex-wrap gap-6">
          {relatedIndicators.map(ind => {
            const companyConfig = COMPANY_LOGOS[ind.company] || {
              primary: '',
              fallback: ''
            };

            return (
              <div key={ind.company} className="flex items-center space-x-4 bg-gray-50 rounded-xl p-4">
                <div className="h-16 relative flex items-center">
                  {companyConfig.primary ? (
                    <img
                      src={companyConfig.primary}
                      alt={ind.company}
                      className="h-full w-auto object-contain"
                      onError={(e) => handleImageError(e, ind.company)}
                      style={{
                        maxWidth: '160px',
                        minWidth: '100px'
                      }}
                    />
                  ) : (
                    <LogoFallback company={ind.company} />
                  )}
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Objectif</div>
                  <div className="text-lg font-bold text-gray-900">
                    {formatValue(ind.target)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Graphique */}
      <div className="h-[500px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart 
            data={combinedData}
            margin={{ top: 60, right: 40, left: 20, bottom: 40 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis 
              dataKey="month" 
              tick={{ fill: '#111827', fontSize: 16, fontWeight: 500 }}
              axisLine={{ stroke: '#9CA3AF' }}
              dy={10}
            />
            <YAxis
              tickFormatter={formatValue}
              tick={{ fill: '#111827', fontSize: 16, fontWeight: 500 }}
              axisLine={{ stroke: '#9CA3AF' }}
              padding={{ top: 20, bottom: 20 }}
              dx={-10}
              domain={[yAxisMin, yAxisMax]} // Utiliser les valeurs calculées pour optimiser l'échelle
              allowDataOverflow={false}
            />
            <Tooltip
              formatter={(value: number) => [formatValue(value), indicator.name]}
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #E5E7EB',
                borderRadius: '0.75rem',
                padding: '1rem',
                boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                fontSize: '16px'
              }}
              labelStyle={{ color: '#111827', fontWeight: '600', fontSize: '18px' }}
            />
            <Legend 
              wrapperStyle={{
                fontSize: '16px',
                paddingTop: '30px'
              }}
            />

            {/* Une ligne par entreprise */}
            {relatedIndicators.map((ind, index) => (
              <React.Fragment key={ind.company}>
                <Line
                  type="monotone"
                  dataKey={ind.company}
                  name={`${ind.company}`}
                  stroke={COMPANY_COLORS[ind.company] || COMPANY_COLORS.DEFAULT}
                  strokeWidth={4}
                  dot={{ 
                    fill: COMPANY_COLORS[ind.company] || COMPANY_COLORS.DEFAULT, 
                    r: 8, 
                    strokeWidth: 2, 
                    stroke: '#FFFFFF' 
                  }}
                  activeDot={{ 
                    r: 10, 
                    stroke: '#FFFFFF', 
                    strokeWidth: 2 
                  }}
                  connectNulls={false}
                />
                <ReferenceLine
                  y={ind.target}
                  stroke={COMPANY_COLORS[ind.company] || COMPANY_COLORS.DEFAULT}
                  strokeWidth={2}
                  strokeDasharray="8 4"
                  label={{
                    value: `Objectif ${ind.company}: ${formatValue(ind.target)}`,
                    position: 'right',
                    fill: COMPANY_COLORS[ind.company] || COMPANY_COLORS.DEFAULT,
                    fontSize: 14,
                    fontWeight: '600'
                  }}
                />
              </React.Fragment>
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}