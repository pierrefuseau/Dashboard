import React from 'react';
import { Filter } from 'lucide-react';
import { ComexFiltersState } from '../../../pages/angpier/AngpierPage';

interface ComexFiltersProps {
  filters: ComexFiltersState;
  onChange: (filters: ComexFiltersState) => void;
}

export function ComexFilters({ filters, onChange }: ComexFiltersProps) {
  return (
    <div className="flex items-center space-x-4">
      <div className="flex items-center space-x-2 bg-white rounded-lg border border-gray-200 p-2">
        <Filter className="w-4 h-4 text-gray-400" />
        <select
          value={filters.company}
          onChange={(e) => onChange({ ...filters, company: e.target.value as ComexFiltersState['company'] })}
          className="text-sm border-0 focus:ring-0"
        >
          <option value="Groupe">Groupe</option>
          <option value="Fuseau">Fuseau</option>
          <option value="Délices Agro">Délices Agro</option>
        </select>
      </div>

      <select
        value={filters.frequency}
        onChange={(e) => onChange({ ...filters, frequency: e.target.value as ComexFiltersState['frequency'] })}
        className="text-sm border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
      >
        <option value="monthly">Mensuel</option>
        <option value="quarterly">Trimestriel</option>
        <option value="yearly">Annuel</option>
      </select>

      <select
        value={filters.process || ''}
        onChange={(e) => onChange({ ...filters, process: e.target.value || null })}
        className="text-sm border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
      >
        <option value="">Tous les processus</option>
        <option value="Direction">Direction</option>
        <option value="Produire">Produire</option>
        <option value="Logistique">Logistique</option>
        <option value="Vendre">Vendre</option>
        <option value="Qualité">Qualité</option>
        <option value="Achat">Achat</option>
        <option value="RH">RH</option>
        <option value="Financer">Financer</option>
      </select>
    </div>
  );
}