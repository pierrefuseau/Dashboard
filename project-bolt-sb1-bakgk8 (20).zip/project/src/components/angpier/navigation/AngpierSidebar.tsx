import React from 'react';
import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Home,
  BarChart2,
  Newspaper,
  Building2
} from 'lucide-react';
import { cn } from '../../../utils/cn';
import { useAuthStore } from '../../../store/authStore';

const navigation = [
  { 
    name: 'Accueil', 
    href: '/angpier', 
    icon: Home,
    color: 'gray'
  },
  { 
    name: 'COMEX', 
    href: '/angpier/comex', 
    icon: BarChart2,
    color: 'blue',
    permission: 'COMEX'
  },
  { 
    name: 'Locations', 
    href: '/angpier/locations', 
    icon: Building2,
    color: 'purple',
    permission: 'ADMIN'  // Restreindre cette page aux administrateurs uniquement
  },
  { 
    name: 'Actualités', 
    href: '/angpier/news', 
    icon: Newspaper,
    color: 'green',
    permission: 'COMEX'
  }
];

interface AngpierSidebarProps {
  onClose?: () => void;
}

export function AngpierSidebar({ onClose }: AngpierSidebarProps) {
  const { user } = useAuthStore();

  // Filtrer les liens de navigation en fonction des permissions de l'utilisateur
  const filteredNavigation = navigation.filter(item => {
    // Si l'utilisateur n'a pas de permissions, ne pas afficher le lien
    if (!user?.permissions) return false;
    
    // Si pas de permission requise, afficher le lien
    if (!item.permission) return true;
    
    // Si l'utilisateur est ADMIN, afficher tous les liens
    if (user.permissions.includes('ADMIN')) return true;
    
    // Pour COMEX, autoriser les utilisateurs avec VENTES, BOUTIQUE ou COMEX
    if (item.permission === 'COMEX') {
      return user.permissions.includes('VENTES') || 
             user.permissions.includes('BOUTIQUE') || 
             user.permissions.includes('COMEX');
    }
    
    // Pour les autres liens, vérifier la permission spécifique
    return user.permissions.includes(item.permission);
  });

  return (
    <aside className="w-64 bg-white border-r border-gray-200 h-full flex flex-col">
      <div className="flex-1 flex flex-col min-h-0">
        {/* Logo et bouton fermer sur mobile */}
        <div className="flex items-center justify-center h-32 px-8 border-b border-gray-100 bg-white">
          <div className="w-full h-full relative flex items-center justify-center p-4">
            <img
              src="https://www.fuseau-sas.com/media/971484/1/0/1/php20ucBg"
              alt="ANGPIER"
              className="max-h-full w-auto object-contain transition-transform hover:scale-105"
              style={{
                maxWidth: '100%',
                objectFit: 'contain'
              }}
            />
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 overflow-y-auto">
          <div className="space-y-2">
            {filteredNavigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.href}
                onClick={onClose}
                className={({ isActive }) => cn(
                  // Base styles
                  "relative flex items-center px-6 py-4",
                  "text-base font-medium",
                  "rounded-xl transition-all duration-200",
                  "group hover:shadow-md",
                  "overflow-hidden",
                  // Active/Inactive states
                  isActive 
                    ? `bg-${item.color}-50 text-${item.color}-700 shadow-sm ring-1 ring-${item.color}-200` 
                    : `text-${item.color}-600 hover:text-${item.color}-900`
                )}
              >
                {({ isActive }) => (
                  <>
                    {/* Effet de gradient au hover */}
                    <div className={cn(
                      "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200",
                      `bg-gradient-to-r from-${item.color}-50/50 via-${item.color}-50/80 to-${item.color}-50/50`
                    )} />

                    {/* Bordure latérale animée */}
                    <div className={cn(
                      "absolute left-0 top-0 bottom-0 w-1 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-200",
                      `bg-${item.color}-500`
                    )} />

                    {/* Contenu */}
                    <motion.div
                      className="relative flex items-center z-10"
                      initial={false}
                      animate={{ 
                        scale: isActive ? 1.05 : 1,
                      }}
                    >
                      <item.icon className={cn(
                        "w-6 h-6 mr-3 flex-shrink-0 transition-all duration-200",
                        isActive ? `text-${item.color}-600` : `text-${item.color}-400 group-hover:text-${item.color}-600`
                      )} />
                      <span className={cn(
                        "font-medium tracking-wide",
                        "transition-colors duration-200",
                        isActive 
                          ? `text-${item.color}-700` 
                          : `text-${item.color}-600 group-hover:text-${item.color}-900`
                      )}>
                        {item.name}
                      </span>
                    </motion.div>

                    {/* Effet de brillance au hover */}
                    <div className={cn(
                      "absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500",
                      "bg-gradient-to-r",
                      `from-${item.color}-400/0 via-${item.color}-400 to-${item.color}-400/0`,
                      "translate-x-[-100%] group-hover:translate-x-[100%]",
                      "transition-transform duration-1000"
                    )} />
                  </>
                )}
              </NavLink>
            ))}
          </div>
        </nav>

        {/* Version */}
        <div className="p-4 text-xs text-gray-400 border-t border-gray-100">
          Version 1.0.0
        </div>
      </div>
    </aside>
  );
}