import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '../../common/Card';
import { Building, ArrowRight, Calendar } from 'lucide-react';
import { format, parse, differenceInDays } from 'date-fns';
import { fr } from 'date-fns/locale';

interface NewsCardProps {
  date: string;
  strategy: string;
  company: string;
  description: string;
  impact: string;
  index: number;
}

export function NewsCard({ 
  date, 
  strategy, 
  company, 
  description, 
  impact,
  index 
}: NewsCardProps) {
  // Parser la date au format JJ/MM/AAAA
  const parsedDate = parse(date, 'dd/MM/yyyy', new Date());
  const formattedDate = format(parsedDate, 'dd MMMM yyyy', { locale: fr });
  
  // Calculer si l'actualité a moins d'un mois
  const daysSinceNews = differenceInDays(new Date(), parsedDate);
  const isRecent = daysSinceNews <= 30;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
    >
      <Card className={`overflow-hidden hover:shadow-lg transition-all duration-200 border-l-4 ${
        isRecent ? 'border-red-500' : 'border-gray-400'
      }`}>
        <div className="p-6">
          {/* En-tête avec date et stratégie */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className={`flex items-center ${isRecent ? 'text-red-500' : 'text-gray-500'}`}>
                <Calendar className="w-4 h-4 mr-1" />
                <span className="text-sm">{formattedDate}</span>
              </div>
              <span className="text-gray-300">|</span>
              <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                isRecent 
                  ? 'text-red-600 bg-red-50' 
                  : 'text-gray-600 bg-gray-100'
              }`}>
                {strategy}
              </span>
            </div>
          </div>

          {/* Entreprise */}
          <div className="flex items-center space-x-2 mb-3">
            <Building className={`w-5 h-5 ${isRecent ? 'text-red-400' : 'text-gray-400'}`} />
            <h4 className={`text-lg font-medium ${isRecent ? 'text-red-700' : 'text-gray-700'}`}>
              {company}
            </h4>
          </div>

          {/* Description */}
          <div className="mb-4">
            <p className={`text-xl font-semibold leading-relaxed ${
              isRecent ? 'text-red-900' : 'text-gray-900'
            }`}>
              {description}
            </p>
          </div>

          {/* Impact */}
          <div className={`rounded-lg p-4 ${isRecent ? 'bg-red-50' : 'bg-gray-50'}`}>
            <div className="flex items-start space-x-3">
              <ArrowRight className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                isRecent ? 'text-red-500' : 'text-gray-500'
              }`} />
              <div>
                <span className={`text-sm font-medium block mb-1 ${
                  isRecent ? 'text-red-700' : 'text-gray-700'
                }`}>
                  Impact sur le Groupe
                </span>
                <p className={`text-sm ${isRecent ? 'text-red-600' : 'text-gray-600'}`}>
                  {impact}
                </p>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}