import React from 'react';
import { NewsCard } from './NewsCard';
import { useNews } from '../../../hooks/angpier/useNews';
import { LoadingSpinner } from '../../common/LoadingSpinner';
import { Newspaper } from 'lucide-react';

export function NewsList() {
  const { data: news, isLoading, error } = useNews();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 rounded-lg p-6 text-center">
        <div className="flex flex-col items-center">
          <div className="p-3 bg-red-100 rounded-full mb-3">
            <Newspaper className="w-6 h-6 text-red-600" />
          </div>
          <h3 className="text-lg font-medium text-red-800 mb-2">
            Erreur de chargement
          </h3>
          <p className="text-red-600">
            Impossible de charger les actualités. Veuillez réessayer plus tard.
          </p>
        </div>
      </div>
    );
  }

  if (!news?.length) {
    return (
      <div className="bg-gray-50 rounded-lg p-6 text-center">
        <div className="flex flex-col items-center">
          <div className="p-3 bg-gray-100 rounded-full mb-3">
            <Newspaper className="w-6 h-6 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Aucune actualité
          </h3>
          <p className="text-gray-500">
            Il n'y a pas d'actualités disponibles pour le moment.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {news.map((item, index) => (
        <NewsCard
          key={`${item.date}-${index}`}
          {...item}
          index={index}
        />
      ))}
    </div>
  );
}