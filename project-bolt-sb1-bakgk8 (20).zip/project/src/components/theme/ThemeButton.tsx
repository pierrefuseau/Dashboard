import React from 'react';
import { Palette } from 'lucide-react';
import { useTheme } from '../../theme/ThemeProvider';

interface ThemeButtonProps {
  onClick: () => void;
}

export function ThemeButton({ onClick }: ThemeButtonProps) {
  const { mode } = useTheme();

  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors
        ${mode === 'dark' 
          ? 'bg-gray-800 text-gray-200 hover:bg-gray-700' 
          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
        }`}
    >
      <Palette className="w-5 h-5 mr-2" />
      Thème
    </button>
  );
}