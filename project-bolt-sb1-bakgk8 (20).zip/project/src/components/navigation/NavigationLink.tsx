import React from 'react';
import { NavLink } from 'react-router-dom';
import type { LucideIcon } from 'lucide-react';
import { cn } from '../../utils/cn';
import { navigationColors } from './NavigationColors';

interface NavigationLinkProps {
  name: string;
  href: string;
  icon: LucideIcon;
  onClick?: () => void;
}

export function NavigationLink({ name, href, icon: Icon, onClick }: NavigationLinkProps) {
  const getNormalizedName = (name: string): string => {
    return name.toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, '')
      .replace('la', '');
  };

  return (
    <NavLink
      to={href}
      onClick={onClick}
      className={({ isActive }) => {
        const normalizedName = getNormalizedName(name);
        const colors = navigationColors[normalizedName as keyof typeof navigationColors] || navigationColors.home;
        
        return cn(
          // Base styles
          "flex items-center px-6 py-4 text-base font-medium rounded-xl",
          "transition-all duration-200 ease-in-out",
          "hover:shadow-sm",
          "focus:outline-none focus:ring-2 focus:ring-offset-2",
          // Active/Inactive states
          isActive 
            ? cn(colors.active.bg, colors.active.text, "shadow-sm") 
            : cn(colors.default, `hover:${colors.hover}`, "hover:bg-gray-50")
        );
      }}
    >
      {({ isActive }) => {
        const normalizedName = getNormalizedName(name);
        const colors = navigationColors[normalizedName as keyof typeof navigationColors] || navigationColors.home;
        
        return (
          <>
            <Icon className={cn(
              "mr-4 h-6 w-6 flex-shrink-0",
              isActive ? colors.active.text : colors.default
            )} />
            <span className="truncate">{name}</span>
          </>
        );
      }}
    </NavLink>
  );
}