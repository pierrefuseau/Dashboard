export const navigationColors = {
  home: {
    default: 'text-gray-600',
    hover: 'text-gray-900',
    active: {
      bg: 'bg-gray-100',
      text: 'text-gray-900'
    }
  },
  ventes: {
    default: 'text-blue-600',
    hover: 'text-blue-700',
    active: {
      bg: 'bg-blue-50',
      text: 'text-blue-700'
    }
  },
  achats: {
    default: 'text-red-600',
    hover: 'text-red-700',
    active: {
      bg: 'bg-red-50',
      text: 'text-red-700'
    }
  },
  comptabilite: {
    default: 'text-indigo-600',
    hover: 'text-indigo-700',
    active: {
      bg: 'bg-indigo-50',
      text: 'text-indigo-700'
    }
  },
  rh: {
    default: 'text-violet-600',
    hover: 'text-violet-700',
    active: {
      bg: 'bg-violet-50',
      text: 'text-violet-700'
    }
  },
  logistique: {
    default: 'text-orange-600',
    hover: 'text-orange-700',
    active: {
      bg: 'bg-orange-50',
      text: 'text-orange-700'
    }
  },
  qualite: {
    default: 'text-yellow-600',
    hover: 'text-yellow-700',
    active: {
      bg: 'bg-yellow-50',
      text: 'text-yellow-700'
    }
  },
  boutique: {
    default: 'text-boutique-600',
    hover: 'text-boutique-700',
    active: {
      bg: 'bg-boutique-50',
      text: 'text-boutique-700'
    }
  },
  rse: {
    default: 'text-green-600',
    hover: 'text-green-700',
    active: {
      bg: 'bg-green-50',
      text: 'text-green-700'
    }
  }
};