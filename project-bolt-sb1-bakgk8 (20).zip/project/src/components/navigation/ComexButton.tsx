import React from 'react';
// Empty file - COMEX button removed