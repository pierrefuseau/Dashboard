import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

interface TileProps {
  title: string;
  icon: LucideIcon;
  color: string;
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}

export function Tile({ 
  title, 
  icon: Icon, 
  color, 
  children, 
  onClick,
  className 
}: TileProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        "bg-white rounded-lg border-l-4 shadow-sm",
        "transition-all duration-200 hover:shadow-md",
        onClick && "cursor-pointer",
        className
      )}
      style={{ borderLeftColor: color }}
    >
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium truncate" style={{ color }}>
          {title}
        </h3>
        <div 
          className="p-1.5 rounded-lg flex-shrink-0" 
          style={{ backgroundColor: `${color}15` }}
        >
          <Icon className="w-4 h-4" style={{ color }} />
        </div>
      </div>

      {children}
    </motion.div>
  );
}