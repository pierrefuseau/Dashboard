import React from 'react';
import { cn } from '../../../utils/cn';

interface DashboardSectionProps {
  title: string;
  description?: string;
  children: React.ReactNode;
  className?: string;
}

export function DashboardSection({
  title,
  description,
  children,
  className
}: DashboardSectionProps) {
  return (
    <section className={cn("space-y-6", className)}>
      <header>
        <h2 className="text-xl font-semibold text-gray-900">{title}</h2>
        {description && (
          <p className="mt-1 text-sm text-gray-500">{description}</p>
        )}
      </header>
      {children}
    </section>
  );
}