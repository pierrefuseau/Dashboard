import React from 'react';
import { BlurredSection } from '../../auth/BlurredSection';
import { SalesMetricCard } from '../../sales/metrics/SalesMetricCard';
import { PurchaseMetricCard } from '../../purchasing/metrics/PurchaseMetricCard';
import { LogisticsMetricCard } from '../../logistics/metrics/LogisticsMetricCard';
import { BarChart3, ShoppingCart, Package } from 'lucide-react';

interface MetricsSectionProps {
  salesData: {
    revenue: number;
    margin: number;
  };
  purchaseData: {
    volume: number;
    amount: number;
  };
  logisticsData: {
    stockValue: number;
    serviceRate: number;
  };
}

export function MetricsSection({ salesData, purchaseData, logisticsData }: MetricsSectionProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <BlurredSection permission="VENTES">
        <SalesMetricCard
          title="Chiffre d'affaires"
          value={salesData.revenue}
          icon={BarChart3}
          format="currency"
        />
      </BlurredSection>

      <BlurredSection permission="ACHATS">
        <PurchaseMetricCard
          title="Volume Acheté"
          value={purchaseData.volume}
          icon={ShoppingCart}
          format="volume"
        />
      </BlurredSection>

      <BlurredSection permission="LOGISTIQUE">
        <LogisticsMetricCard
          title="Valeur Stock"
          value={logisticsData.stockValue}
          icon={Package}
          format="currency"
        />
      </BlurredSection>
    </div>
  );
}