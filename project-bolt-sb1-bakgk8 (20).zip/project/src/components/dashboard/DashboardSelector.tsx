import React from 'react';
import { Building2, BarChart3, Factory, Microscope } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const dashboards = [
  {
    id: 'fuseau',
    name: 'FUSEAU SAS',
    icon: Building2,
    path: '/',
    color: 'blue'
  },
  {
    id: 'ventes',
    name: 'FUSEAU VENTES',
    icon: BarChart3,
    path: '/ventes',
    color: 'green'
  },
  {
    id: 'production',
    name: 'FUSEAU PRODUCTION',
    icon: Factory,
    path: '/production',
    color: 'orange'
  },
  {
    id: 'rd',
    name: 'FUSEAU R&D',
    icon: Microscope,
    path: '/rd',
    color: 'purple'
  }
];

export function DashboardSelector() {
  const navigate = useNavigate();

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="relative group">
        <button className="p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 border border-gray-200">
          <Building2 className="w-6 h-6 text-gray-600" />
        </button>

        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block">
          <div className="bg-white rounded-lg shadow-xl border border-gray-200 p-2 w-64">
            <div className="space-y-1">
              {dashboards.map((dashboard) => {
                const Icon = dashboard.icon;
                return (
                  <motion.button
                    key={dashboard.id}
                    onClick={() => navigate(dashboard.path)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`
                      w-full flex items-center space-x-3 px-4 py-2 rounded-lg
                      hover:bg-gray-50 transition-colors duration-200
                      text-left
                    `}
                  >
                    <Icon className={`w-5 h-5 text-${dashboard.color}-500`} />
                    <span className="text-sm font-medium text-gray-700">
                      {dashboard.name}
                    </span>
                  </motion.button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}