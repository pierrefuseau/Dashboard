import React from 'react';
import { TrendChart } from './TrendChart';
import { cn } from '../../utils/cn';

interface TileContentProps {
  label: string;
  value: string | number;
  trend?: Array<{ value: number; date: string }>;
  trendColor?: string;
  className?: string;
}

export function TileContent({ 
  label, 
  value, 
  trend,
  trendColor,
  className 
}: TileContentProps) {
  return (
    <div className={cn(
      "bg-gray-50 rounded p-2 flex flex-col items-center justify-center",
      className
    )}>
      <span className="text-[10px] text-gray-500 uppercase tracking-wide">
        {label}
      </span>
      <span className="text-xs font-medium text-gray-900 mt-0.5">
        {value}
      </span>
      {trend && trendColor && (
        <div className="w-full mt-2">
          <TrendChart 
            data={trend} 
            color={trendColor}
            height={24}
          />
        </div>
      )}
    </div>
  );
}