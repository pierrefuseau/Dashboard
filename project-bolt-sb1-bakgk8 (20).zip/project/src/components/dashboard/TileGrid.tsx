import React from 'react';
import { cn } from '../../utils/cn';

interface TileGridProps {
  children: React.ReactNode;
  className?: string;
  minWidth?: string;
  gap?: 'sm' | 'md' | 'lg';
}

export function TileGrid({ 
  children, 
  className,
  minWidth = '300px',
  gap = 'md'
}: TileGridProps) {
  const gapClasses = {
    sm: 'gap-4',
    md: 'gap-6',
    lg: 'gap-8'
  };

  return (
    <div className={cn(
      "grid",
      `grid-cols-[repeat(auto-fit,minmax(min(100%,${minWidth}),1fr))]`,
      gapClasses[gap],
      className
    )}>
      {children}
    </div>
  );
}