import React, { useState, useRef, useEffect } from 'react';
import { Building2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const companies = [
  {
    id: 'fuseau',
    name: 'FUSEAU SAS',
    logo: 'https://www.fuseau-sas.com/media/952906/1/0/1/Logo-nouvelle-couleur+%281%29.png',
    fallbackLogo: 'https://www.fuseau-sas.com/frontend/images/logo-fuseau.png',
    path: '/',
    color: 'blue'
  },
  {
    id: 'delices-agro',
    name: 'DELICES AGRO',
    logo: 'https://www.delicesagro.com/front/fonts/logo-delices-agro-dark.svg',
    path: '/delices-agro',
    color: 'green'
  },
  {
    id: 'angpier',
    name: 'ANGPIER',
    logo: 'https://www.fuseau-sas.com/media/970298/1/0/1/php69FBLJ',
    path: '/angpier',
    color: 'purple'
  }
];

export function CompanySelector() {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative w-full" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-center px-4 py-2 bg-orange-500 text-white rounded-lg shadow-sm hover:shadow-md hover:bg-orange-600 transition-colors"
      >
        <Building2 className="w-4 h-4 mr-2" />
        <span className="text-sm font-medium">Entreprises</span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ duration: 0.2 }}
            className="absolute bottom-full left-0 mb-2 w-64"
          >
            <div className="bg-white rounded-lg shadow-xl border border-gray-200 p-2 w-full">
              <div className="space-y-1">
                {companies.map((company) => (
                  <motion.button
                    key={company.id}
                    onClick={() => {
                      navigate(company.path);
                      setIsOpen(false);
                    }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                  >
                    <div className="h-8 w-32 flex items-center">
                      <img 
                        src={company.logo}
                        alt={company.name}
                        className="h-full w-auto object-contain transition-transform hover:scale-105"
                        onError={(e) => {
                          const img = e.currentTarget;
                          if (company.fallbackLogo && img.src !== company.fallbackLogo) {
                            img.src = company.fallbackLogo;
                          } else {
                            img.style.display = 'none';
                          }
                        }}
                        style={{
                          minWidth: '120px',
                          maxWidth: '160px'
                        }}
                      />
                    </div>
                    <span className="text-sm font-medium text-gray-700 flex-shrink-0">
                      {company.name}
                    </span>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}