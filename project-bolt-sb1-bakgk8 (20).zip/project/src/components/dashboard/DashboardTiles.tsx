// Mise à jour de la section Ventes dans DashboardTiles.tsx
// ...
{/* Ventes */}
<Tile
  title="Ventes"
  color="#3B82F6"
  icon={BarChart3}
  onClick={() => navigate('/sales')}
>
  <TileContent 
    label="CA" 
    value={dashboardFormatters.currency(salesRevenue)} 
  />
  <TileContent 
    label="Marge" 
    value={dashboardFormatters.currency(salesMargin)} 
  />
</Tile>
// ...