import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

interface KeyFigure {
  label: string;
  value: string;
}

interface SectorCardProps {
  title: string;
  color: string;
  icon: LucideIcon;
  keyFigures: KeyFigure[];
  onClick: () => void;
}

export function SectorCard({ title, color, icon: Icon, keyFigures, onClick }: SectorCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        "bg-white rounded-xl shadow-sm border-l-4 cursor-pointer",
        "p-4 sm:p-6",
        "transition-all duration-200",
        "hover:shadow-md"
      )}
      style={{ borderLeftColor: color }}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base sm:text-lg font-semibold truncate" style={{ color }}>
          {title}
        </h3>
        <div className="p-2 rounded-lg flex-shrink-0" style={{ backgroundColor: `${color}15` }}>
          <Icon className="w-5 h-5 sm:w-6 sm:h-6" style={{ color }} />
        </div>
      </div>

      <div className="space-y-3 sm:space-y-4">
        {keyFigures.map((figure, index) => (
          <div key={index} className="flex items-center justify-between">
            <span className="text-xs sm:text-sm text-gray-600 truncate mr-2">
              {figure.label}
            </span>
            <span className="text-xs sm:text-sm font-medium text-gray-900 truncate">
              {figure.value}
            </span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}