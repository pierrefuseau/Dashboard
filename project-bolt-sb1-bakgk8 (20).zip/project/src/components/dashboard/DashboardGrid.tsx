import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Widget } from './CustomDashboard';
import { DashboardWidget } from './widgets/DashboardWidget';

interface DashboardGridProps {
  widgets: Widget[];
  cols: number;
  rows: number;
  onMoveWidget: (id: string, x: number, y: number) => void;
  onResizeWidget: (id: string, w: number, h: number) => void;
  onRemoveWidget: (id: string) => void;
}

export function DashboardGrid({
  widgets,
  cols,
  rows,
  onMoveWidget,
  onResizeWidget,
  onRemoveWidget
}: DashboardGridProps) {
  // Calculer la taille d'une cellule de la grille
  const cellSize = 100 / cols;

  return (
    <div 
      className="relative bg-gray-100 rounded-lg border-2 border-dashed border-gray-200"
      style={{ 
        height: `${rows * 80}px`,
        backgroundImage: `
          linear-gradient(to right, #f3f4f6 1px, transparent 1px),
          linear-gradient(to bottom, #f3f4f6 1px, transparent 1px)
        `,
        backgroundSize: `${cellSize}% ${100 / rows}%`
      }}
    >
      <AnimatePresence>
        {widgets.map(widget => (
          <motion.div
            key={widget.id}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            drag
            dragMomentum={false}
            dragConstraints={{
              left: 0,
              top: 0,
              right: (cols - widget.w) * cellSize,
              bottom: (rows - widget.h) * 80
            }}
            dragElastic={0}
            onDragEnd={(_, info) => {
              // Convertir la position en coordonnées de grille
              const x = Math.round(info.point.x / (cellSize * window.innerWidth / 100));
              const y = Math.round(info.point.y / 80);
              onMoveWidget(widget.id, x, y);
            }}
            className="absolute cursor-move"
            style={{
              width: `${widget.w * cellSize}%`,
              height: `${widget.h * 80}px`,
              left: `${widget.x * cellSize}%`,
              top: `${widget.y * 80}px`,
              touchAction: 'none'
            }}
          >
            <div className="absolute inset-1">
              <DashboardWidget
                widget={widget}
                onRemove={() => onRemoveWidget(widget.id)}
                onResize={(w, h) => onResizeWidget(widget.id, w, h)}
              />
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}