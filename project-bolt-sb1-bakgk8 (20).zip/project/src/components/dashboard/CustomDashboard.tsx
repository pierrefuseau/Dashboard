import React from 'react';
import { Container } from '../layout/Container';
import { Grid } from '../layout/Grid';
import { Card } from '../common/Card';
import { motion } from 'framer-motion';

export function CustomDashboard() {
  return (
    <Container maxWidth="2xl">
      <div className="space-y-6">
        {/* En-tête */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <h1 className="text-xl font-semibold text-gray-900">Vue d'ensemble</h1>
          <p className="mt-1 text-sm text-gray-500">
            Tableau de bord des performances
          </p>
        </div>

        {/* Grille des métriques principales */}
        <Grid cols={4} gap="md">
          {/* Métriques */}
          {[1, 2, 3, 4].map((i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.1 }}
            >
              <Card className="h-full">
                <div className="p-4">
                  <h3 className="text-lg font-medium text-gray-900">Métrique {i}</h3>
                  <p className="mt-2 text-2xl font-semibold text-gray-900">0</p>
                </div>
              </Card>
            </motion.div>
          ))}
        </Grid>

        {/* Grille des graphiques */}
        <Grid cols={2} gap="lg">
          {[1, 2].map((i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.1 + 0.4 }}
            >
              <Card className="h-full">
                <div className="p-4">
                  <h3 className="text-lg font-medium text-gray-900">Graphique {i}</h3>
                  <div className="h-[300px] mt-4 bg-gray-50 rounded-lg"></div>
                </div>
              </Card>
            </motion.div>
          ))}
        </Grid>

        {/* Grille des tableaux */}
        <Grid cols={3} gap="md">
          {[1, 2, 3].map((i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.1 + 0.6 }}
            >
              <Card className="h-full">
                <div className="p-4">
                  <h3 className="text-lg font-medium text-gray-900">Tableau {i}</h3>
                  <div className="mt-4 max-h-[400px] overflow-auto">
                    {/* Contenu du tableau */}
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </Grid>
      </div>
    </Container>
  );
}