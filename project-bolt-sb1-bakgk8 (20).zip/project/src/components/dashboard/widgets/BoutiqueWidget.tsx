import React from 'react';
import { ShoppingBag, Users } from 'lucide-react';
import { useBoutiqueMetrics } from '../../../hooks/boutique/useBoutiqueMetrics';
import { formatCurrency } from '../../../utils/formatters/currency';

export function BoutiqueWidget() {
  const { dailyRevenue, customerCount, isLoading } = useBoutiqueMetrics();

  if (isLoading) {
    return <div className="animate-pulse space-y-4">
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
      <div className="h-8 bg-gray-200 rounded"></div>
    </div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <ShoppingBag className="w-5 h-5 text-pink-500" />
        <h3 className="text-lg font-medium text-gray-900">La Boutique</h3>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-pink-50 p-3 rounded-lg">
          <div className="text-sm text-gray-500">CA Jour</div>
          <div className="text-lg font-semibold text-pink-600">
            {formatCurrency(dailyRevenue)}
          </div>
        </div>

        <div className="bg-blue-50 p-3 rounded-lg">
          <div className="flex items-center text-sm text-gray-500">
            <Users className="w-4 h-4 mr-1" />
            Clients
          </div>
          <div className="text-lg font-semibold text-blue-600">
            {customerCount}
          </div>
        </div>
      </div>
    </div>
  );
}