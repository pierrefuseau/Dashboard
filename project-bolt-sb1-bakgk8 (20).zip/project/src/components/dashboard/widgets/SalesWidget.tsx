import React from 'react';
import { BarChart3, TrendingUp } from 'lucide-react';
import { useSalesMetrics } from '../../../hooks/sales/useSalesMetrics';
import { formatCurrency } from '../../../utils/formatters/currency';

export function SalesWidget() {
  const { revenue, margin, isLoading } = useSalesMetrics();

  if (isLoading) {
    return <div className="animate-pulse space-y-4">
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
      <div className="h-8 bg-gray-200 rounded"></div>
    </div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <BarChart3 className="w-5 h-5 text-blue-500" />
        <h3 className="text-lg font-medium text-gray-900">Ventes</h3>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-blue-50 p-3 rounded-lg">
          <div className="text-sm text-gray-500">CA</div>
          <div className="text-lg font-semibold text-blue-600">
            {formatCurrency(revenue)}
          </div>
        </div>

        <div className="bg-green-50 p-3 rounded-lg">
          <div className="flex items-center text-sm text-gray-500">
            <TrendingUp className="w-4 h-4 mr-1" />
            Marge
          </div>
          <div className="text-lg font-semibold text-green-600">
            {formatCurrency(margin)}
          </div>
        </div>
      </div>
    </div>
  );
}