import React from 'react';
import { X, Maximize2, Minimize2, Maximize as ArrowsMaximize, Minimize as ArrowsMinimize } from 'lucide-react';
import { Card } from '../../common/Card';
import { Widget } from '../CustomDashboard';
import { SalesWidget } from './SalesWidget';
import { PurchasesWidget } from './PurchasesWidget';
import { LogisticsWidget } from './LogisticsWidget';
import { HRWidget } from './HRWidget';
import { BoutiqueWidget } from './BoutiqueWidget';
import { RSEWidget } from './RSEWidget';

interface DashboardWidgetProps {
  widget: Widget;
  onRemove: () => void;
  onResize: (w: number, h: number) => void;
}

const widgetComponents = {
  sales: SalesWidget,
  purchases: PurchasesWidget,
  logistics: LogisticsWidget,
  hr: HRWidget,
  boutique: BoutiqueWidget,
  rse: RSEWidget
};

const sizePresets = [
  { w: 3, h: 2 }, // Petit
  { w: 4, h: 3 }, // Moyen
  { w: 6, h: 4 }  // Grand
] as const;

export function DashboardWidget({ widget, onRemove, onResize }: DashboardWidgetProps) {
  const WidgetComponent = widgetComponents[widget.type];
  
  // Trouver le prochain preset de taille
  const currentSizeIndex = sizePresets.findIndex(
    size => size.w === widget.w && size.h === widget.h
  );
  const nextSize = sizePresets[(currentSizeIndex + 1) % sizePresets.length];

  return (
    <Card className="h-full">
      <div className="absolute top-2 right-2 flex items-center space-x-1 z-10">
        <button
          onClick={() => onResize(nextSize.w, nextSize.h)}
          className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
          title="Redimensionner"
        >
          {widget.w === sizePresets[2].w ? (
            <ArrowsMinimize className="w-4 h-4" />
          ) : (
            <ArrowsMaximize className="w-4 h-4" />
          )}
        </button>
        <button
          onClick={onRemove}
          className="p-1.5 text-gray-400 hover:text-red-600 rounded-lg hover:bg-red-50"
          title="Supprimer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4">
        <WidgetComponent />
      </div>
    </Card>
  );
}