import React from 'react';
import { Leaf, Users } from 'lucide-react';
import { useRSEMetrics } from '../../../hooks/rse/useRSEMetrics';

export function RSEWidget() {
  const { data: metrics, isLoading } = useRSEMetrics();

  if (isLoading) {
    return <div className="animate-pulse space-y-4">
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
      <div className="h-8 bg-gray-200 rounded"></div>
    </div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Leaf className="w-5 h-5 text-green-500" />
        <h3 className="text-lg font-medium text-gray-900">RSE</h3>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-green-50 p-3 rounded-lg">
          <div className="text-sm text-gray-500">Score Global</div>
          <div className="text-lg font-semibold text-green-600">
            {metrics?.globalScore || 0}/100
          </div>
        </div>

        <div className="bg-blue-50 p-3 rounded-lg">
          <div className="flex items-center text-sm text-gray-500">
            <Users className="w-4 h-4 mr-1" />
            Égalité H/F
          </div>
          <div className="text-lg font-semibold text-blue-600">
            {metrics?.genderEquality || 0}%
          </div>
        </div>
      </div>
    </div>
  );
}