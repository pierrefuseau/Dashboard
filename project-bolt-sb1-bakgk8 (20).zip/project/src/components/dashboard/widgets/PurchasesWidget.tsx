import React from 'react';
import { ShoppingCart, Package } from 'lucide-react';
import { usePurchaseMetrics } from '../../../hooks/purchases/usePurchaseMetrics';
import { formatCurrency } from '../../../utils/formatters/currency';

export function PurchasesWidget() {
  const { volume, amount, isLoading } = usePurchaseMetrics();

  if (isLoading) {
    return <div className="animate-pulse space-y-4">
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
      <div className="h-8 bg-gray-200 rounded"></div>
    </div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <ShoppingCart className="w-5 h-5 text-red-500" />
        <h3 className="text-lg font-medium text-gray-900">Achats</h3>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-red-50 p-3 rounded-lg">
          <div className="text-sm text-gray-500">Montant</div>
          <div className="text-lg font-semibold text-red-600">
            {formatCurrency(amount)}
          </div>
        </div>

        <div className="bg-orange-50 p-3 rounded-lg">
          <div className="flex items-center text-sm text-gray-500">
            <Package className="w-4 h-4 mr-1" />
            Volume
          </div>
          <div className="text-lg font-semibold text-orange-600">
            {volume.toFixed(2)} T
          </div>
        </div>
      </div>
    </div>
  );
}