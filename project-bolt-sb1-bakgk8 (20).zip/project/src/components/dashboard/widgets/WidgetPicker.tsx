import React from 'react';
import { motion } from 'framer-motion';
import { BarChart3, ShoppingCart, Truck, Users, ShoppingBag, Leaf } from 'lucide-react';
import { WidgetType } from '../CustomDashboard';

interface WidgetPickerProps {
  onSelect: (type: WidgetType) => void;
  onClose: () => void;
}

const widgets = [
  { type: 'sales', name: 'Ventes', icon: BarChart3, color: 'bg-blue-500' },
  { type: 'purchases', name: 'Achats', icon: ShoppingCart, color: 'bg-red-500' },
  { type: 'logistics', name: 'Logistique', icon: Truck, color: 'bg-orange-500' },
  { type: 'hr', name: 'RH', icon: Users, color: 'bg-violet-500' },
  { type: 'boutique', name: 'La Boutique', icon: ShoppingBag, color: 'bg-pink-500' },
  { type: 'rse', name: 'RSE', icon: Leaf, color: 'bg-green-500' }
] as const;

export function WidgetPicker({ onSelect, onClose }: WidgetPickerProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-xl shadow-xl p-6 max-w-2xl w-full mx-4"
      >
        <h3 className="text-lg font-medium text-gray-900 mb-4">
          Ajouter un widget
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {widgets.map(({ type, name, icon: Icon, color }) => (
            <button
              key={type}
              onClick={() => onSelect(type)}
              className="p-4 rounded-lg border-2 border-gray-200 hover:border-blue-500 transition-colors text-left"
            >
              <div className={`w-10 h-10 ${color} rounded-lg flex items-center justify-center mb-3`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <h4 className="font-medium text-gray-900">{name}</h4>
            </button>
          ))}
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-800"
          >
            Annuler
          </button>
        </div>
      </motion.div>
    </div>
  );
}