import React from 'react';
import { Users, BarChart3, ShoppingCart, ClipboardCheck, Leaf } from 'lucide-react';
import { motion } from 'framer-motion';

const strategies = [
  {
    title: 'Croissance ciblée',
    description: 'Développer nos ventes dans tous les segments (artisans, export, industrie, GMS et franchises) pour renforcer notre position sur le marché agroalimentaire.',
    icon: BarChart3,
    color: 'blue'
  },
  {
    title: 'Optimisation opérationnelle',
    description: 'Réduire les coûts grâce à des achats négociés et une logistique modernisée, garantissant une meilleure efficacité et des livraisons plus rapides.',
    icon: ShoppingCart,
    color: 'red'
  },
  {
    title: 'Excellence et innovation',
    description: 'Améliorer la qualité de nos produits et services via des contrôles renforcés, des outils digitaux performants et une comptabilité digitalisée.',
    icon: ClipboardCheck,
    color: 'yellow'
  },
  {
    title: 'Investissement dans nos équipes',
    description: "Attirer, former et fidéliser les talents pour construire une culture d'entreprise basée sur le respect et la coopération.",
    icon: Users,
    color: 'violet'
  },
  {
    title: 'Engagement durable',
    description: 'Continuer à réduire notre impact environnemental et à communiquer sur nos progrès en matière de responsabilité sociétale.',
    icon: Leaf,
    color: 'green'
  }
];

export function StrategySection() {
  return (
    <div className="mb-12">
      <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-6 sm:p-8 shadow-sm border border-blue-200">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Stratégie 2025</h2>
        <p className="text-blue-600 font-medium mb-6 sm:mb-8">
          En quelques mots
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {strategies.map((strategy, index) => (
            <motion.div
              key={strategy.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className={`
                bg-white rounded-lg p-4 sm:p-6 shadow-sm border border-gray-100 
                hover:shadow-md transition-shadow h-full flex flex-col
              `}
            >
              <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center mb-4 ${
                strategy.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                strategy.color === 'red' ? 'bg-red-100 text-red-600' :
                strategy.color === 'yellow' ? 'bg-yellow-100 text-yellow-600' :
                strategy.color === 'violet' ? 'bg-violet-100 text-violet-600' :
                'bg-green-100 text-green-600'
              }`}>
                <strategy.icon className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              
              <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2">
                {strategy.title}
              </h3>
              
              <p className="text-sm text-gray-600 leading-relaxed flex-grow">
                {strategy.description}
              </p>
            </motion.div>
          ))}
        </div>

        <p className="text-center text-gray-600 mt-6 sm:mt-8 font-medium">
          Ensemble, nous faisons de 2025 une année d'innovation, d'efficacité et de croissance responsable.
        </p>
      </div>
    </div>
  );
}