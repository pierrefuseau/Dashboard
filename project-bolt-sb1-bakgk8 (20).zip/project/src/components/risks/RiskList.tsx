import React from 'react';
import { Card } from '../common/Card';
import { AlertTriangle, CheckCircle, Clock, AlertOctagon, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Risk {
  id: string;
  name: string;
  type: 'environmental' | 'social' | 'governance';
  impact: 'low' | 'medium' | 'high';
  status: 'identified' | 'treated' | 'in_progress';
  date: string;
  department: string;
  description: string;
}

interface RiskListProps {
  selectedStatus: string | null;
}

const mockRisks: Risk[] = [
  {
    id: 'R001',
    name: 'Émissions CO2 transport',
    type: 'environmental',
    impact: 'high',
    status: 'in_progress',
    date: '2024-02-15',
    department: 'Logistique',
    description: 'Impact carbone lié au transport des marchandises'
  },
  {
    id: 'R002',
    name: 'Conformité RGPD',
    type: 'governance',
    impact: 'medium',
    status: 'treated',
    date: '2024-01-20',
    department: 'IT',
    description: 'Mise en conformité avec la réglementation sur les données personnelles'
  },
  {
    id: 'R003',
    name: 'Conditions de travail',
    type: 'social',
    impact: 'high',
    status: 'identified',
    date: '2024-03-01',
    department: 'RH',
    description: 'Amélioration des conditions de travail des employés'
  }
];

const getStatusIcon = (status: Risk['status']) => {
  switch (status) {
    case 'identified':
      return <AlertTriangle className="w-5 h-5 text-orange-500" />;
    case 'treated':
      return <CheckCircle className="w-5 h-5 text-green-500" />;
    case 'in_progress':
      return <Clock className="w-5 h-5 text-blue-500" />;
  }
};

const getImpactConfig = (impact: Risk['impact']) => {
  switch (impact) {
    case 'high':
      return {
        icon: AlertOctagon,
        color: 'text-red-500',
        bg: 'bg-red-50',
        border: 'border-red-100',
        text: 'Élevé'
      };
    case 'medium':
      return {
        icon: AlertCircle,
        color: 'text-orange-500',
        bg: 'bg-orange-50',
        border: 'border-orange-100',
        text: 'Moyen'
      };
    case 'low':
      return {
        icon: AlertTriangle,
        color: 'text-yellow-500',
        bg: 'bg-yellow-50',
        border: 'border-yellow-100',
        text: 'Faible'
      };
  }
};

export function RiskList({ selectedStatus }: RiskListProps) {
  const filteredRisks = selectedStatus 
    ? mockRisks.filter(risk => risk.status === selectedStatus)
    : mockRisks;

  return (
    <Card>
      <div className="space-y-6">
        <AnimatePresence mode="wait">
          {filteredRisks.map((risk, index) => {
            const impactConfig = getImpactConfig(risk.impact);
            const ImpactIcon = impactConfig.icon;

            return (
              <motion.div
                key={risk.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className={`p-6 rounded-xl border ${impactConfig.border} ${impactConfig.bg}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(risk.status)}
                      <h3 className="text-lg font-medium text-gray-900">{risk.name}</h3>
                    </div>
                    
                    <div className="mt-2 text-sm text-gray-500">{risk.description}</div>
                    
                    <div className="mt-4 flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <ImpactIcon className={`w-4 h-4 ${impactConfig.color}`} />
                        <span className="text-sm font-medium">{impactConfig.text}</span>
                      </div>
                      
                      <span className="text-sm text-gray-500">{risk.department}</span>
                      <span className="text-sm text-gray-500">
                        {new Date(risk.date).toLocaleDateString('fr-FR')}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </Card>
  );
}