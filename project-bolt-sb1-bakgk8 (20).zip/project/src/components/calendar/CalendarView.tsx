import React from 'react';
import { format, addDays, subDays } from 'date-fns';
import { fr } from 'date-fns/locale';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface Event {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  attendees: Array<{ email: string; name: string; picture?: string }>;
}

export function CalendarView() {
  const [selectedDate, setSelectedDate] = React.useState(new Date());
  const [events, setEvents] = React.useState<Event[]>([]);

  const navigateDate = (direction: 'prev' | 'next') => {
    setSelectedDate(current => 
      direction === 'next' ? addDays(current, 1) : subDays(current, 1)
    );
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-xl font-semibold text-gray-900">Schedule</h2>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigateDate('prev')}
              className="p-2 text-gray-400 hover:text-gray-500"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <span className="text-lg font-medium text-gray-900">
              {format(selectedDate, 'MMMM yyyy', { locale: fr })}
            </span>
            <button
              onClick={() => navigateDate('next')}
              className="p-2 text-gray-400 hover:text-gray-500"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex space-x-4 overflow-x-auto pb-4">
          {Array.from({ length: 5 }).map((_, i) => {
            const date = addDays(selectedDate, i - 2);
            const isToday = format(date, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
            
            return (
              <button
                key={i}
                className={`flex flex-col items-center min-w-[100px] p-4 rounded-lg transition-colors ${
                  isToday
                    ? 'bg-blue-100 text-blue-700'
                    : 'hover:bg-gray-50'
                }`}
                onClick={() => setSelectedDate(date)}
              >
                <span className="text-sm font-medium">
                  {format(date, 'EEE', { locale: fr })}
                </span>
                <span className="mt-1 text-2xl font-semibold">
                  {format(date, 'd')}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-8 space-y-4">
          {events.map(event => (
            <div
              key={event.id}
              className="p-4 bg-white border rounded-lg hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium text-gray-900">{event.title}</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    {format(new Date(event.startTime), 'HH:mm')} - 
                    {format(new Date(event.endTime), 'HH:mm')}
                  </p>
                </div>
                <div className="flex -space-x-2">
                  {event.attendees.map((attendee, i) => (
                    <img
                      key={attendee.email}
                      src={attendee.picture || `https://ui-avatars.com/api/?name=${attendee.name}`}
                      alt={attendee.name}
                      className="w-8 h-8 rounded-full border-2 border-white"
                      title={attendee.name}
                    />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}