import React, { useState } from 'react';
import { testOpenAIConnection } from '../../utils/ai/testConnection';
import { AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';

export function AIConnectionTest() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [result, setResult] = useState<any>(null);

  const handleTest = async () => {
    setStatus('loading');
    try {
      const response = await testOpenAIConnection();
      if (response.success) {
        setStatus('success');
      } else {
        setStatus('error');
      }
      setResult(response);
    } catch (error) {
      setStatus('error');
      setResult({ error: error instanceof Error ? error.message : 'Une erreur est survenue' });
    }
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">Test de connexion OpenAI</h3>
        <button
          onClick={handleTest}
          disabled={status === 'loading'}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {status === 'loading' ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            'Tester la connexion'
          )}
        </button>
      </div>

      {status !== 'idle' && (
        <div className={`mt-4 p-4 rounded-lg ${
          status === 'success' ? 'bg-green-50' :
          status === 'error' ? 'bg-red-50' :
          'bg-gray-50'
        }`}>
          {status === 'success' && (
            <div className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-green-800">Connexion réussie</p>
                <p className="mt-1 text-sm text-green-700">
                  Modèle utilisé : {result.model}
                </p>
                <p className="mt-1 text-sm text-green-700">
                  Réponse : {result.message}
                </p>
              </div>
            </div>
          )}

          {status === 'error' && (
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-red-800">Erreur de connexion</p>
                <p className="mt-1 text-sm text-red-700">
                  {result.error}
                </p>
                {result.status && (
                  <p className="mt-1 text-sm text-red-700">
                    Code d'erreur : {result.status}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}