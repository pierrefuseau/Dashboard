import React from 'react';
import { aiMonitoring } from '../../services/ai/monitoring';
import { Card } from '../common/Card';
import { AlertTriangle, Zap, DollarSign } from 'lucide-react';

export function AIMetrics() {
  const [metrics, setMetrics] = React.useState(aiMonitoring.getMetrics());
  const [errors, setErrors] = React.useState(aiMonitoring.getRecentErrors());

  // Mettre à jour les métriques toutes les 30 secondes
  React.useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(aiMonitoring.getMetrics());
      setErrors(aiMonitoring.getRecentErrors());
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* Métriques d'utilisation */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <div className="flex items-center justify-between p-4">
            <div>
              <p className="text-sm font-medium text-gray-500">Total Tokens</p>
              <p className="mt-1 text-2xl font-semibold text-gray-900">
                {metrics.totalTokens.toLocaleString()}
              </p>
            </div>
            <div className="p-3 bg-blue-50 rounded-full">
              <Zap className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <div className="h-1 bg-gray-100">
            <div 
              className="h-full bg-blue-600 rounded-full transition-all duration-500"
              style={{ width: `${(metrics.totalTokens / 100000) * 100}%` }}
            />
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between p-4">
            <div>
              <p className="text-sm font-medium text-gray-500">Coût Estimé</p>
              <p className="mt-1 text-2xl font-semibold text-gray-900">
                ${metrics.cost.toFixed(2)}
              </p>
            </div>
            <div className="p-3 bg-green-50 rounded-full">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <div className="h-1 bg-gray-100">
            <div 
              className="h-full bg-green-600 rounded-full transition-all duration-500"
              style={{ width: `${(metrics.cost / 100) * 100}%` }}
            />
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between p-4">
            <div>
              <p className="text-sm font-medium text-gray-500">Erreurs (24h)</p>
              <p className="mt-1 text-2xl font-semibold text-gray-900">
                {errors.length}
              </p>
            </div>
            <div className="p-3 bg-red-50 rounded-full">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
          </div>
          <div className="h-1 bg-gray-100">
            <div 
              className="h-full bg-red-600 rounded-full transition-all duration-500"
              style={{ width: `${(errors.length / 10) * 100}%` }}
            />
          </div>
        </Card>
      </div>

      {/* Liste des erreurs récentes */}
      {errors.length > 0 && (
        <Card>
          <div className="p-4">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Erreurs Récentes
            </h3>
            <div className="space-y-4">
              {errors.map((error, index) => (
                <div 
                  key={index}
                  className="flex items-start space-x-3 p-3 bg-red-50 rounded-lg"
                >
                  <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-red-800">
                      {error.code} - {error.endpoint}
                    </p>
                    <p className="mt-1 text-sm text-red-700">
                      {error.message}
                    </p>
                    <p className="mt-1 text-xs text-red-600">
                      {new Date(error.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}