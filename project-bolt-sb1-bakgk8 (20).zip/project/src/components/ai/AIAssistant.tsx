import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, X, Maximize2, Minimize2, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAIChat } from '../../hooks/ai/useAIChat';
import { cn } from '../../utils/cn';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [message, setMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  
  const { 
    messages, 
    isLoading,
    error,
    sendMessage,
    clearMessages,
    deleteMessage
  } = useAIChat();

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus input when chat is opened
  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus();
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || isLoading) return;
    
    sendMessage(message);
    setMessage('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
  };

  return (
    <>
      {/* Bouton pour ouvrir l'assistant */}
      <button
        onClick={() => setIsOpen(true)}
        className="w-full flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg shadow-sm hover:shadow-md hover:bg-blue-700 transition-colors"
      >
        <MessageSquare className="w-4 h-4 mr-2" />
        <span className="text-sm font-medium">Assistant IA</span>
      </button>

      {/* Fenêtre de chat */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className={cn(
              "fixed z-50 bg-white rounded-lg shadow-xl border border-gray-200",
              "flex flex-col",
              isExpanded
                ? "inset-0"
                : "left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[min(90vw,600px)] h-[min(80vh,600px)]"
            )}
          >
            {/* En-tête */}
            <div className="flex justify-between items-center p-4 border-b">
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <MessageSquare className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Assistant IA</h3>
                  <p className="text-sm text-gray-500">Posez vos questions</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={clearMessages}
                  className="p-2 text-gray-400 hover:text-gray-500 rounded-lg hover:bg-gray-100"
                  title="Effacer la conversation"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setIsExpanded(!isExpanded)}
                  className="p-2 text-gray-400 hover:text-gray-500 rounded-lg hover:bg-gray-100"
                >
                  {isExpanded ? (
                    <Minimize2 className="w-5 h-5" />
                  ) : (
                    <Maximize2 className="w-5 h-5" />
                  )}
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 text-gray-400 hover:text-gray-500 rounded-lg hover:bg-gray-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 space-y-4">
                  <MessageSquare className="w-12 h-12 text-blue-200" />
                  <div>
                    <p className="font-medium text-gray-600">Assistant IA FUSEAU</p>
                    <p className="text-sm mt-1">
                      Posez des questions sur les données du dashboard pour obtenir des analyses et des insights.
                    </p>
                  </div>
                  <div className="grid grid-cols-1 gap-2 w-full max-w-xs mt-4">
                    {[
                      "Quel est notre meilleur client ?",
                      "Quelle est la tendance des ventes ?",
                      "Analyse notre performance logistique"
                    ].map((suggestion, i) => (
                      <button
                        key={i}
                        onClick={() => {
                          setMessage(suggestion);
                          if (inputRef.current) {
                            inputRef.current.style.height = 'auto';
                            inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 120)}px`;
                          }
                        }}
                        className="p-2 text-sm text-left text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "group relative flex items-start space-x-3",
                    msg.role === 'assistant' ? "justify-start" : "justify-end"
                  )}
                >
                  {msg.role === 'assistant' && (
                    <div className="flex-shrink-0 p-2 bg-blue-100 rounded-lg">
                      <MessageSquare className="w-5 h-5 text-blue-600" />
                    </div>
                  )}
                  
                  <div className={cn(
                    "relative max-w-[80%] rounded-lg px-4 py-2",
                    msg.role === 'assistant' 
                      ? "bg-gray-100 text-gray-900" 
                      : "bg-blue-600 text-white"
                  )}>
                    <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                    <span className="absolute -bottom-5 text-xs text-gray-400">
                      {format(msg.timestamp, 'HH:mm', { locale: fr })}
                    </span>
                    
                    {/* Bouton de suppression */}
                    <button
                      onClick={() => deleteMessage(msg.id)}
                      className="absolute -right-8 top-1/2 -translate-y-1/2 p-1 rounded-full bg-gray-100 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {msg.role === 'user' && (
                    <div className="flex-shrink-0 p-2 bg-blue-100 rounded-lg">
                      <MessageSquare className="w-5 h-5 text-blue-600" />
                    </div>
                  )}
                </motion.div>
              ))}
              {error && (
                <div className="p-4 bg-red-50 rounded-lg">
                  <p className="text-sm text-red-600">{error}</p>
                </div>
              )}
              {isLoading && (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Zone de saisie */}
            <form onSubmit={handleSubmit} className="p-4 border-t">
              <div className="flex space-x-4">
                <textarea
                  ref={inputRef}
                  value={message}
                  onChange={handleTextareaChange}
                  onKeyDown={handleKeyDown}
                  placeholder="Posez votre question..."
                  className="flex-1 min-h-[44px] max-h-32 p-2 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={1}
                />
                <button
                  type="submit"
                  disabled={!message.trim() || isLoading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}