import React from 'react';
import { Bot, User } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';
import { Message } from '../../hooks/ai/useAIAssistant';

interface AIMessageProps {
  message: Message;
}

export function AIMessage({ message }: AIMessageProps) {
  const isAI = message.role === 'assistant';

  return (
    <motion.div
      key={message.id}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "flex items-start space-x-3",
        isAI ? "justify-start" : "justify-end"
      )}
    >
      {isAI && (
        <div className="flex-shrink-0 p-2 bg-blue-100 rounded-lg">
          <Bot className="w-5 h-5 text-blue-600" />
        </div>
      )}
      
      <div className={cn(
        "max-w-[80%] rounded-lg px-4 py-2",
        isAI 
          ? "bg-gray-100 text-gray-900" 
          : "bg-blue-600 text-white"
      )}>
        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
      </div>

      {!isAI && (
        <div className="flex-shrink-0 p-2 bg-blue-100 rounded-lg">
          <User className="w-5 h-5 text-blue-600" />
        </div>
      )}
    </motion.div>
  );
}