import React from 'react';
import { Card } from '../../common/Card';

interface QualityIndicator {
  name: string;
  frequency: string;
  target: string | number;
  current: number;
  previous: number;
}

const indicators: QualityIndicator[] = [
  {
    name: "Taux de conformité analyses",
    frequency: "Trimestre",
    target: "95%",
    current: 96.87,
    previous: 95
  },
  {
    name: "Temps réponse réclamations",
    frequency: "Trimestre",
    target: "5j",
    current: 6.18,
    previous: 5.45
  },
  {
    name: "Taux de propreté Fuseau",
    frequency: "Mensuel",
    target: "80%",
    current: 78.5,
    previous: 85
  },
  {
    name: "Taux propreté zone stockage",
    frequency: "Mensuel",
    target: "80%",
    current: 96.55,
    previous: 98
  },
  {
    name: "Taux propreté logistique",
    frequency: "Mensuel",
    target: "80%",
    current: 100,
    previous: 90
  }
];

export function QualityIndicatorsTable() {
  return (
    <Card title="Indicateurs Qualité">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Indicateur
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Fréquence
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Objectif
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actuel
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Évolution
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {indicators.map((indicator) => {
              const evolution = ((indicator.current - indicator.previous) / indicator.previous) * 100;
              
              return (
                <tr key={indicator.name}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {indicator.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {indicator.frequency}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {indicator.target}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                    {indicator.current}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      evolution >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {evolution.toFixed(1)}%
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}