import React from 'react';
import { Building2 } from 'lucide-react';

interface SiteFilterProps {
  value: string;
  onChange: (value: string) => void;
}

export function SiteFilter({ value, onChange }: SiteFilterProps) {
  return (
    <div className="flex items-center space-x-2 bg-white rounded-lg border border-gray-200 p-1">
      <Building2 className="w-4 h-4 text-gray-400 ml-2" />
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="text-sm text-gray-600 bg-transparent border-0 focus:ring-0 cursor-pointer pr-8"
      >
        <option value="all">Tous les sites</option>
        <option value="fuseau-sas">FUSEAU SAS</option>
        <option value="fuseau-16">FUSEAU N°16</option>
        <option value="fuseau-logistique">FUSEAU LOGISTIQUE</option>
        <option value="fuseau-st-barthelemy">FUSEAU ST BARTHELEMY</option>
      </select>
    </div>
  );
}