import React from 'react';
import { LucideIcon } from 'lucide-react';
import { Card } from '../../common/Card';

interface QualityMetricCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  format?: 'percentage' | 'days' | 'number';
  target?: number;
}

export function QualityMetricCard({
  title,
  value,
  icon: Icon,
  format = 'percentage',
  target
}: QualityMetricCardProps) {
  const formatValue = (val: number) => {
    if (val === 0) return 'Non disponible';
    
    switch (format) {
      case 'percentage':
        return `${val.toFixed(2)}%`;
      case 'days':
        return `${val.toFixed(1)}j`;
      default:
        return val.toString();
    }
  };

  const getStatusColor = (current: number, target?: number) => {
    if (current === 0) return '';
    if (!target) return '';
    return current >= target ? 'text-green-500' : 'text-red-500';
  };

  return (
    <Card>
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className={`mt-1 text-2xl font-semibold ${getStatusColor(value, target)}`}>
            {formatValue(value)}
          </p>
          {target && (
            <p className="text-xs text-gray-500 mt-1">
              Objectif: {format === 'percentage' ? `${target}%` : format === 'days' ? `${target}j` : target}
            </p>
          )}
        </div>
        <div className="flex-shrink-0 p-3 rounded-full bg-yellow-50">
          <Icon className="w-6 h-6 text-yellow-600" />
        </div>
      </div>
    </Card>
  );
}