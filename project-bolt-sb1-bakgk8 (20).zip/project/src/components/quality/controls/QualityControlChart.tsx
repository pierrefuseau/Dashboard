import React from 'react';
import { Card } from '../../common/Card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const data = [
  { name: 'Conformes', value: 92 },
  { name: 'Non-conformes mineurs', value: 6 },
  { name: 'Non-conformes majeurs', value: 2 }
];

const COLORS = ['#fbbf24', '#fcd34d', '#fde68a'];

export function QualityControlChart() {
  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Contrôles Qualité</h3>
          <p className="text-sm text-gray-500 mt-1">Résultats des contrôles en production</p>
        </div>
        <div className="flex space-x-4">
          <div className="text-center">
            <div className="text-2xl font-semibold text-gray-900">450</div>
            <div className="text-sm text-gray-500">Contrôles</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-semibold text-gray-900">92%</div>
            <div className="text-sm text-gray-500">Conformité</div>
          </div>
        </div>
      </div>

      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={100}
              paddingAngle={2}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value: number) => [`${value}%`, 'Proportion']}
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #E5E7EB',
                borderRadius: '0.5rem'
              }}
            />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-4">
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Lots contrôlés</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">98%</div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Prélèvements</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">1250</div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Analyses</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">850</div>
        </div>
      </div>
    </Card>
  );
}