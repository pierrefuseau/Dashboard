import React from 'react';
import { Card } from '../../common/Card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { month: 'Jan', conformite: 95, proprete: 85.96, reponse: 5.8 },
  { month: 'Fév', conformite: 100, proprete: 93.51, reponse: 5.9 },
  { month: 'Mar', conformite: 97, proprete: 71.82, reponse: 6.1 },
  { month: 'Avr', conformite: 96, proprete: 78.76, reponse: 6.0 },
  { month: 'Mai', conformite: 100, proprete: 78.83, reponse: 5.7 },
  { month: 'Juin', conformite: 99, proprete: 79.79, reponse: 5.9 },
  { month: 'Juil', conformite: 99, proprete: 75.69, reponse: 6.2 },
  { month: 'Août', conformite: 99, proprete: 79.81, reponse: 6.0 },
  { month: 'Sep', conformite: 98, proprete: 76, reponse: 6.18 }
];

export function QualityTrendsChart() {
  return (
    <Card title="Évolution des Indicateurs">
      <div className="h-[250px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" />
            <Tooltip />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="conformite"
              name="Conformité"
              stroke="#f97316"
              strokeWidth={2}
            />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="proprete"
              name="Propreté"
              stroke="#fb923c"
              strokeWidth={2}
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="reponse"
              name="Délai Réponse"
              stroke="#fdba74"
              strokeWidth={2}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}