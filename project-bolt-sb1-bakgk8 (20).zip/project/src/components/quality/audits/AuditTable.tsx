import React from 'react';
import { Card } from '../../common/Card';
import { CheckCircle, AlertCircle, Clock } from 'lucide-react';

interface Audit {
  id: string;
  date: string;
  type: 'internal' | 'external';
  score: number;
  status: 'completed' | 'pending' | 'in_progress';
}

const audits: Audit[] = [
  {
    id: "A-2024-001",
    date: "2024-03-15",
    type: "external",
    score: 95,
    status: "completed"
  },
  {
    id: "A-2024-002",
    date: "2024-03-01",
    type: "internal",
    score: 92,
    status: "completed"
  },
  {
    id: "A-2024-003",
    date: "2024-02-15",
    type: "internal",
    score: 88,
    status: "completed"
  },
  {
    id: "A-2024-004",
    date: "2024-04-01",
    type: "internal",
    score: 0,
    status: "pending"
  }
];

const getStatusConfig = (status: string) => {
  switch (status) {
    case 'completed':
      return { icon: CheckCircle, className: 'text-green-600 bg-green-50' };
    case 'pending':
      return { icon: Clock, className: 'text-yellow-600 bg-yellow-50' };
    case 'in_progress':
      return { icon: AlertCircle, className: 'text-blue-600 bg-blue-50' };
    default:
      return { icon: Clock, className: 'text-gray-600 bg-gray-50' };
  }
};

export function AuditTable() {
  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Audits</h3>
          <p className="text-sm text-gray-500 mt-1">Historique des audits internes et externes</p>
        </div>
        <div className="flex space-x-4">
          <div className="text-center">
            <div className="text-2xl font-semibold text-gray-900">8</div>
            <div className="text-sm text-gray-500">Audits réalisés</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-semibold text-gray-900">92</div>
            <div className="text-sm text-gray-500">Score moyen</div>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Référence
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Date
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Type
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Score
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Statut
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {audits.map((audit) => {
              const StatusIcon = getStatusConfig(audit.status).icon;
              
              return (
                <tr key={audit.id} className="hover:bg-gray-50">
                  <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {audit.id}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(audit.date).toLocaleDateString('fr-FR')}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                    {audit.type === 'external' ? 'Externe' : 'Interne'}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm font-medium">
                    {audit.status === 'completed' ? (
                      <span className="text-gray-900">{audit.score}/100</span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full ${getStatusConfig(audit.status).className}`}>
                      <StatusIcon className="w-4 h-4 mr-1" />
                      {audit.status === 'completed' ? 'Terminé' : 
                       audit.status === 'pending' ? 'Planifié' : 'En cours'}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}