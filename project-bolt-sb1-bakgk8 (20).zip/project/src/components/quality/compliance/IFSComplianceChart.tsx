import React from 'react';
import { Card } from '../../common/Card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TimeRange } from '../../common/TimeFilter';

interface IFSComplianceChartProps {
  timeRange: TimeRange;
}

const data = [
  { month: 'Jan', score: 94.5, target: 98 },
  { month: 'Fév', score: 95.2, target: 98 },
  { month: 'Mar', score: 96.1, target: 98 },
  { month: 'Avr', score: 95.8, target: 98 },
  { month: 'Mai', score: 96.5, target: 98 },
  { month: 'Juin', score: 95.0, target: 98 }
];

export function IFSComplianceChart({ timeRange }: IFSComplianceChartProps) {
  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Score IFS Food</h3>
          <p className="text-sm text-gray-500 mt-1">Évolution du score de certification</p>
        </div>
        <div className="bg-yellow-50 text-yellow-600 px-3 py-1 rounded-full text-sm font-medium">
          {data[data.length - 1].score}/100
        </div>
      </div>

      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis dataKey="month" />
            <YAxis domain={[90, 100]} />
            <Tooltip
              formatter={(value: number) => [`${value}/100`, 'Score']}
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #E5E7EB',
                borderRadius: '0.5rem'
              }}
            />
            <Line
              type="monotone"
              dataKey="score"
              stroke="#eab308"
              strokeWidth={2}
              dot={{ fill: '#eab308' }}
            />
            <Line
              type="monotone"
              dataKey="target"
              stroke="#fef08a"
              strokeWidth={2}
              strokeDasharray="5 5"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-4">
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Niveau</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">Higher Level</div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Dernière Certification</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">15/03/2024</div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Prochaine Échéance</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">14/03/2025</div>
        </div>
      </div>
    </Card>
  );
}