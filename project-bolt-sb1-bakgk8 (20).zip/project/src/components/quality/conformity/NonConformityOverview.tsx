import React from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { category: 'Hygiène', value: 5 },
  { category: 'Étiquetage', value: 3 },
  { category: 'Traçabilité', value: 2 },
  { category: 'Process', value: 4 },
  { category: 'Documentation', value: 3 }
];

export function NonConformityOverview() {
  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Non-Conformités</h3>
          <p className="text-sm text-gray-500 mt-1">Répartition par catégorie</p>
        </div>
        <div className="flex space-x-4">
          <div className="text-center">
            <div className="text-2xl font-semibold text-gray-900">17</div>
            <div className="text-sm text-gray-500">Total</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-semibold text-gray-900">85%</div>
            <div className="text-sm text-gray-500">Taux clôture</div>
          </div>
        </div>
      </div>

      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis dataKey="category" />
            <YAxis />
            <Tooltip
              formatter={(value: number) => [value, 'Non-conformités']}
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #E5E7EB',
                borderRadius: '0.5rem'
              }}
            />
            <Bar dataKey="value" fill="#fcd34d" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}