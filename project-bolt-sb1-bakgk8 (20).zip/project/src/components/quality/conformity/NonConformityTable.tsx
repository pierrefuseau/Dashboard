import React from 'react';
import { Card } from '../../common/Card';

interface NonConformity {
  id: string;
  type: string;
  date: string;
  status: 'open' | 'in_progress' | 'closed';
  severity: 'low' | 'medium' | 'high';
}

const nonConformities: NonConformity[] = [
  {
    id: "NC-001",
    type: "Contamination produit",
    date: "2024-03-10",
    status: "closed",
    severity: "high"
  },
  {
    id: "NC-002",
    type: "Erreur étiquetage",
    date: "2024-03-12",
    status: "in_progress",
    severity: "medium"
  },
  {
    id: "NC-003",
    type: "Température non conforme",
    date: "2024-03-14",
    status: "open",
    severity: "high"
  }
];

const getStatusConfig = (status: string) => {
  switch (status) {
    case 'open':
      return { text: 'Ouvert', class: 'bg-red-100 text-red-800' };
    case 'in_progress':
      return { text: 'En cours', class: 'bg-yellow-100 text-yellow-800' };
    case 'closed':
      return { text: 'Clôturé', class: 'bg-green-100 text-green-800' };
    default:
      return { text: status, class: 'bg-gray-100 text-gray-800' };
  }
};

const getSeverityConfig = (severity: string) => {
  switch (severity) {
    case 'high':
      return { text: 'Haute', class: 'text-red-600' };
    case 'medium':
      return { text: 'Moyenne', class: 'text-yellow-600' };
    case 'low':
      return { text: 'Basse', class: 'text-green-600' };
    default:
      return { text: severity, class: 'text-gray-600' };
  }
};

export function NonConformityTable() {
  return (
    <Card title="Non-Conformités">
      <div className="max-h-[250px] overflow-y-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-white sticky top-0">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Référence
              </th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Statut
              </th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Gravité
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {nonConformities.map((nc) => {
              const statusConfig = getStatusConfig(nc.status);
              const severityConfig = getSeverityConfig(nc.severity);
              
              return (
                <tr key={nc.id} className="hover:bg-gray-50">
                  <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900">
                    {nc.id}
                  </td>
                  <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                    {nc.type}
                  </td>
                  <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                    {new Date(nc.date).toLocaleDateString('fr-FR')}
                  </td>
                  <td className="px-4 py-2 whitespace-nowrap text-sm">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${statusConfig.class}`}>
                      {statusConfig.text}
                    </span>
                  </td>
                  <td className="px-4 py-2 whitespace-nowrap text-sm font-medium">
                    <span className={severityConfig.class}>
                      {severityConfig.text}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}