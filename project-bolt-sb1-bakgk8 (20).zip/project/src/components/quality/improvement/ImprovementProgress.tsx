import React from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Process', completed: 85, total: 100 },
  { name: 'Documentation', completed: 92, total: 100 },
  { name: 'Formation', completed: 78, total: 100 },
  { name: 'Équipement', completed: 95, total: 100 },
  { name: 'Traçabilité', completed: 88, total: 100 }
];

export function ImprovementProgress() {
  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Plans d'Amélioration</h3>
          <p className="text-sm text-gray-500 mt-1">Suivi des actions correctives</p>
        </div>
        <div className="flex space-x-4">
          <div className="text-center">
            <div className="text-2xl font-semibold text-gray-900">24</div>
            <div className="text-sm text-gray-500">Actions en cours</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-semibold text-gray-900">87%</div>
            <div className="text-sm text-gray-500">Taux réalisation</div>
          </div>
        </div>
      </div>

      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" horizontal={false} />
            <XAxis type="number" domain={[0, 100]} />
            <YAxis dataKey="name" type="category" width={100} />
            <Tooltip
              formatter={(value: number) => [`${value}%`, 'Avancement']}
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #E5E7EB',
                borderRadius: '0.5rem'
              }}
            />
            <Bar
              dataKey="completed"
              fill="#fbbf24"
              radius={[0, 4, 4, 0]}
              label={{ position: 'right', formatter: (value: number) => `${value}%` }}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Temps moyen clôture</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">12 jours</div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Actions critiques</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">5 en cours</div>
        </div>
      </div>
    </Card>
  );
}