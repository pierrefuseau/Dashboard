import React from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const performanceData = [
  { name: 'Entretiens annuels', completed: 85, target: 100 },
  { name: 'Budget formation', completed: 950, target: 1200 },
  { name: 'Heures formation/employé', completed: 12, target: 15 },
  { name: 'Mobilité interne', completed: 8, target: 10 }
];

export function PerformanceIndicators() {
  return (
    <Card title="Performance et Développement">
      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={performanceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="completed" name="Réalisé" fill="#22c55e" />
            <Bar dataKey="target" name="Objectif" fill="#86efac" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}