import React from 'react';
import { Card } from '../../common/Card';

const movements = [
  { type: 'Nouveaux arrêts maladie', current: 6, previous: 4 },
  { type: 'Total arrêts maladie/maternité', current: 9, previous: 13 },
  { type: 'Nouveaux accidents de travail', current: 0, previous: 2 },
  { type: 'Total accidents de travail', current: 2, previous: 5 },
  { type: 'Nouveaux contrats', current: 7, previous: 5 }
];

export function EmployeeMovementsTable() {
  return (
    <Card title="Mouvements du Personnel">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Mois en cours
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Mois précédent
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Évolution
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {movements.map((item) => {
              const evolution = ((item.current - item.previous) / item.previous) * 100;
              
              return (
                <tr key={item.type}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {item.type}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.current}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.previous}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      evolution > 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {evolution === Infinity ? 'N/A' : `${evolution.toFixed(1)}%`}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}