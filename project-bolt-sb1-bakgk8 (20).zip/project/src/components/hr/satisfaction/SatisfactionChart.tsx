import React from 'react';
import { Card } from '../../common/Card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { month: 'Jan', satisfaction: 7.8, retention: 95 },
  { month: 'Fév', satisfaction: 7.9, retention: 94 },
  { month: 'Mar', satisfaction: 8.1, retention: 96 },
  { month: 'Avr', satisfaction: 8.0, retention: 95 },
  { month: 'Mai', satisfaction: 8.2, retention: 97 },
  { month: 'Juin', satisfaction: 8.3, retention: 96 }
];

export function SatisfactionChart() {
  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Satisfaction & Engagement</h3>
          <p className="text-sm text-gray-500 mt-1">Score sur 10 et taux de rétention</p>
        </div>
        <div className="bg-violet-50 text-violet-600 px-3 py-1 rounded-full text-sm font-medium">
          {data[data.length - 1].satisfaction}/10
        </div>
      </div>

      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis dataKey="month" />
            <YAxis yAxisId="left" domain={[0, 10]} />
            <YAxis yAxisId="right" orientation="right" domain={[80, 100]} />
            <Tooltip
              formatter={(value: number, name: string) => [
                name === 'satisfaction' ? `${value}/10` : `${value}%`,
                name === 'satisfaction' ? 'Satisfaction' : 'Rétention'
              ]}
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #E5E7EB',
                borderRadius: '0.5rem'
              }}
            />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="satisfaction"
              stroke="#8b5cf6"
              strokeWidth={2}
              dot={{ fill: '#8b5cf6' }}
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="retention"
              stroke="#c4b5fd"
              strokeWidth={2}
              dot={{ fill: '#c4b5fd' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-4">
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">NPS Interne</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">+45</div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Taux de Rétention</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">96%</div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Participation</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">89%</div>
        </div>
      </div>
    </Card>
  );
}