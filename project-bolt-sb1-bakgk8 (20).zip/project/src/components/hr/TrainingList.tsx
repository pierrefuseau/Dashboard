import React from 'react';
import { Calendar, Users, Clock } from 'lucide-react';

const trainings = [
  {
    id: 1,
    title: 'Sécurité Alimentaire',
    participants: 15,
    progress: 75,
    endDate: '2024-03-25',
    status: 'en_cours'
  },
  {
    id: 2,
    title: 'Management d\'Équipe',
    participants: 8,
    progress: 45,
    endDate: '2024-04-10',
    status: 'en_cours'
  },
  {
    id: 3,
    title: 'Normes HACCP',
    participants: 25,
    progress: 90,
    endDate: '2024-03-20',
    status: 'en_cours'
  }
];

export function TrainingList() {
  return (
    <div className="space-y-4">
      {trainings.map((training) => (
        <div
          key={training.id}
          className="bg-gray-50 rounded-lg p-4"
        >
          <div className="flex justify-between items-start">
            <div>
              <h4 className="font-medium text-gray-900">{training.title}</h4>
              <div className="mt-1 flex items-center space-x-4 text-sm text-gray-500">
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-1" />
                  {training.participants} participants
                </div>
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-1" />
                  {new Date(training.endDate).toLocaleDateString('fr-FR')}
                </div>
              </div>
            </div>
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-1 text-blue-500" />
              <span className="text-sm font-medium text-blue-500">
                {training.progress}%
              </span>
            </div>
          </div>
          
          <div className="mt-3">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-500 rounded-full h-2"
                style={{ width: `${training.progress}%` }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}