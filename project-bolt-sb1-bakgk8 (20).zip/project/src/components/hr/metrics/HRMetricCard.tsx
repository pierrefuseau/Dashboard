import React from 'react';
import { LucideIcon } from 'lucide-react';
import { Card } from '../../common/Card';

interface HRMetricCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  format?: 'percentage' | 'number';
  color?: 'violet' | 'red' | 'green' | 'blue';
}

export function HRMetricCard({
  title,
  value,
  icon: Icon,
  format = 'number',
  color = 'violet'
}: HRMetricCardProps) {
  const formatValue = (val: number) => {
    if (isNaN(val)) return 'N/A';
    
    switch (format) {
      case 'percentage':
        return `${val}%`;
      case 'number':
        return new Intl.NumberFormat('fr-FR').format(val);
      default:
        return val.toString();
    }
  };

  const getColorClasses = (colorName: string) => {
    switch (colorName) {
      case 'violet':
        return { bg: 'bg-violet-50', text: 'text-violet-600' };
      case 'red':
        return { bg: 'bg-red-50', text: 'text-red-600' };
      case 'green':
        return { bg: 'bg-green-50', text: 'text-green-600' };
      default:
        return { bg: 'bg-blue-50', text: 'text-blue-600' };
    }
  };

  const colorClasses = getColorClasses(color);

  return (
    <Card className="relative">
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1 pr-4">
          <p className="text-sm font-medium text-gray-500 truncate">{title}</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900 truncate">
            {formatValue(value)}
          </p>
        </div>
        <div className={`flex-shrink-0 p-3 rounded-full ${colorClasses.bg}`}>
          <Icon className={`w-6 h-6 ${colorClasses.text}`} />
        </div>
      </div>
    </Card>
  );
}