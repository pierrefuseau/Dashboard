import React from 'react';
import { Users, TrendingDown, Clock } from 'lucide-react';
import { HRMetricCard } from './HRMetricCard';

export function HROverview() {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
      <HRMetricCard
        title="Effectif Total"
        value={342}
        icon={Users}
        format="number"
        color="violet"
      />
      <HRMetricCard
        title="Turn-over"
        value={5.2}
        icon={TrendingDown}
        format="percentage"
        color="violet"
      />
      <HRMetricCard
        title="Taux d'Absentéisme"
        value={3.8}
        icon={Clock}
        format="percentage"
        color="violet"
      />
    </div>
  );
}