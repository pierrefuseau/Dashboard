import React from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { month: 'Jan', rate: 3.2, medical: 2.1, other: 1.1 },
  { month: 'Fév', rate: 3.8, medical: 2.5, other: 1.3 },
  { month: 'Mar', rate: 4.1, medical: 2.8, other: 1.3 },
  { month: 'Avr', rate: 3.5, medical: 2.2, other: 1.3 },
  { month: 'Mai', rate: 3.9, medical: 2.6, other: 1.3 },
  { month: 'Juin', rate: 3.6, medical: 2.3, other: 1.3 }
];

export function AbsenteeismChart() {
  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Taux d'Absentéisme</h3>
          <p className="text-sm text-gray-500 mt-1">Évolution sur les 6 derniers mois</p>
        </div>
        <div className="bg-violet-50 text-violet-600 px-3 py-1 rounded-full text-sm font-medium">
          {data[data.length - 1].rate}%
        </div>
      </div>

      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis dataKey="month" />
            <YAxis tickFormatter={(value) => `${value}%`} />
            <Tooltip
              formatter={(value: number) => [`${value}%`, 'Taux']}
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #E5E7EB',
                borderRadius: '0.5rem'
              }}
            />
            <Bar dataKey="medical" name="Maladie" fill="#8b5cf6" stackId="a" />
            <Bar dataKey="other" name="Autres" fill="#c4b5fd" stackId="a" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Principale cause</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">Maladie</div>
          <div className="text-sm text-gray-500">65% des absences</div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Durée moyenne</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">3.2 jours</div>
          <div className="text-sm text-gray-500">par absence</div>
        </div>
      </div>
    </Card>
  );
}