import React from 'react';
import { Users } from 'lucide-react';

interface DepartmentFilterProps {
  value: string;
  onChange: (value: string) => void;
}

export function DepartmentFilter({ value, onChange }: DepartmentFilterProps) {
  return (
    <div className="flex items-center space-x-2 bg-white rounded-lg border border-gray-200 p-1">
      <Users className="w-4 h-4 text-gray-400 ml-2" />
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="text-sm text-gray-600 bg-transparent border-0 focus:ring-0 cursor-pointer pr-8"
      >
        <option value="all">Tous les services</option>
        <option value="commercial">Commercial</option>
        <option value="production">Production</option>
        <option value="rnd">R&D</option>
        <option value="admin">Administration</option>
        <option value="logistics">Logistique</option>
      </select>
    </div>
  );
}