import React from 'react';
import { Truck, MapPin, Calendar, Package } from 'lucide-react';

const shipments = [
  {
    id: 'SHP-001',
    destination: 'Carrefour Paris',
    status: 'en_route',
    estimatedDelivery: '2024-03-15',
    items: 45
  },
  {
    id: 'SHP-002',
    destination: 'Auchan Lyon',
    status: 'en_preparation',
    estimatedDelivery: '2024-03-16',
    items: 32
  },
  {
    id: 'SHP-003',
    destination: 'Leclerc Bordeaux',
    status: 'en_route',
    estimatedDelivery: '2024-03-15',
    items: 28
  },
  {
    id: 'SHP-004',
    destination: 'Casino Marseille',
    status: 'en_preparation',
    estimatedDelivery: '2024-03-17',
    items: 53
  }
];

const statusConfig = {
  en_route: { className: 'bg-green-100 text-green-800', text: 'En route' },
  en_preparation: { className: 'bg-yellow-100 text-yellow-800', text: 'En préparation' }
};

export function ShipmentsList() {
  return (
    <div className="space-y-4">
      {shipments.map((shipment) => (
        <div
          key={shipment.id}
          className="bg-gray-50 rounded-lg p-4"
        >
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-medium text-gray-900">{shipment.id}</span>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  statusConfig[shipment.status].className
                }`}>
                  {statusConfig[shipment.status].text}
                </span>
              </div>
              
              <div className="mt-2 space-y-1">
                <div className="flex items-center text-sm text-gray-500">
                  <MapPin className="w-4 h-4 mr-1" />
                  {shipment.destination}
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Calendar className="w-4 h-4 mr-1" />
                  Livraison prévue : {new Date(shipment.estimatedDelivery).toLocaleDateString('fr-FR')}
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 text-gray-500">
              <Package className="w-4 h-4" />
              <span className="text-sm font-medium">{shipment.items} articles</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}