import React from 'react';
import { Package } from 'lucide-react';
import { Card } from '../common/Card';
import { useSheetData } from '../../hooks/sheets/useSheetData';

export function StockValue() {
  const { data: stockValue, isLoading } = useSheetData('LOGISTIQUE', '', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      return Number(data[0][0].toString().replace(/[^0-9.-]+/g, '')) || 0;
    }
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
      useGrouping: false
    }).format(value);
  };

  return (
    <Card>
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-gray-500">Valeur Stock Total</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900">
            {isLoading ? 'Chargement...' : formatCurrency(stockValue || 0)}
          </p>
        </div>
        <div className="flex-shrink-0 p-3 rounded-full bg-orange-50">
          <Package className="w-6 h-6 text-orange-600" />
        </div>
      </div>
    </Card>
  );
}