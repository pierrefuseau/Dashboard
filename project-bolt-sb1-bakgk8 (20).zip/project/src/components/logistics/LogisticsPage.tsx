import React from 'react';
import { Package, Truck, AlertCircle, Clock, TrendingUp } from 'lucide-react';
import { LogisticsMetricCard } from '../../components/logistics/metrics/LogisticsMetricCard';
import { useLogisticsMetrics } from '../../hooks/logistics/useLogisticsMetrics';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../../components/ui/Tabs';
import { WarehouseStockChart } from '../../components/logistics/stock/WarehouseStockChart';
import { TopProductsStockTable } from '../../components/logistics/stock/TopProductsStockTable';
import { SlowMovingProductsTable } from '../../components/logistics/stock/SlowMovingProductsTable';
import { DDMProductsSection } from '../../components/logistics/ddm/DDMProductsSection';

export function LogisticsPage() {
  const metrics = useLogisticsMetrics();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Logistique</h2>
        <p className="mt-1 text-sm text-gray-500">
          Suivi des opérations logistiques et stocks
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <LogisticsMetricCard
          title="Taux de Service Global"
          value={metrics.serviceRate}
          icon={TrendingUp}
          format="percentage"
          target={97}
        />
        <LogisticsMetricCard
          title="Valeur Stock Total"
          value={metrics.stockValue}
          icon={Package}
          format="millions"
        />
        <LogisticsMetricCard
          title="Anomalies Traçabilité"
          value={metrics.anomalies}
          icon={AlertCircle}
          format="percentage"
          target={5}
        />
        <LogisticsMetricCard
          title="Taux Service Transport"
          value={metrics.transportRate}
          icon={Truck}
          format="percentage"
          target={98}
        />
      </div>

      <Tabs defaultValue="stocks" variant="logistics">
        <TabsList>
          <TabsTrigger value="stocks" className="flex items-center space-x-2">
            <Package className="h-4 w-4" />
            <span>Stocks Entrepôts</span>
          </TabsTrigger>
          <TabsTrigger value="products" className="flex items-center space-x-2">
            <Package className="h-4 w-4" />
            <span>Stock Produits</span>
          </TabsTrigger>
          <TabsTrigger value="slow" className="flex items-center space-x-2">
            <AlertCircle className="h-4 w-4" />
            <span>Non tournant</span>
          </TabsTrigger>
          <TabsTrigger value="ddm" className="flex items-center space-x-2">
            <Clock className="h-4 w-4" />
            <span>DDM</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="stocks">
          <WarehouseStockChart />
        </TabsContent>

        <TabsContent value="products">
          <TopProductsStockTable />
        </TabsContent>

        <TabsContent value="slow">
          <SlowMovingProductsTable />
        </TabsContent>

        <TabsContent value="ddm">
          <DDMProductsSection />
        </TabsContent>
      </Tabs>
    </div>
  );
}