import React from 'react';
import { StorageProduct } from '../../../types/logistics';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface StorageProductsTableProps {
  products: StorageProduct[];
  type: 'AMBIENT' | 'FROZEN';
}

export function StorageProductsTable({ products, type }: StorageProductsTableProps) {
  const filteredProducts = products.filter(p => p.type === type);
  
  const getRowStyle = (daysUntilDdm: number) => {
    if (daysUntilDdm <= 7) return 'bg-blue-50';
    if (daysUntilDdm <= 14) return 'bg-sky-50';
    return '';
  };

  const getBgColor = () => {
    return type === 'AMBIENT' ? 'bg-amber-50' : 'bg-blue-50';
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className={`p-4 ${getBgColor()}`}>
        <h3 className="text-lg font-medium text-gray-900">
          {type === 'AMBIENT' ? 'Produits Ambiants' : 'Produits Surgelés'}
        </h3>
        <p className="text-sm text-gray-500">
          Total: {filteredProducts.length} produits
        </p>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Lot
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                DDM
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Quantité
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Montant de stock
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Délai d'alerte
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredProducts.map((product, index) => (
              <tr 
                key={`${product.name}-${product.lot}-${index}`}
                className={`${getRowStyle(product.daysUntilDdm)} hover:bg-opacity-80 transition-colors`}
              >
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {product.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {product.lot}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {format(product.ddm, 'dd MMM yyyy', { locale: fr })}
                  <span className="ml-2 text-xs text-gray-400">
                    ({product.daysUntilDdm} jours)
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                  {product.quantity.toLocaleString('fr-FR')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {product.stockAmount}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {product.alertDelay}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}