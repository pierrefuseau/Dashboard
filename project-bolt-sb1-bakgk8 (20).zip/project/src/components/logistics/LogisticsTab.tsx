import React from 'react';
import { StockValue } from './StockValue';
import { WarehouseStockChart } from './stock/WarehouseStockChart';
import { ServiceRateTable } from './service/ServiceRateTable';
import { StockIndicatorsTable } from './stock/StockIndicatorsTable';

export function LogisticsTab() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Logistique</h2>
        <p className="mt-1 text-sm text-gray-500">
          Suivi des opérations logistiques et stocks
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StockValue />
      </div>

      <div className="grid grid-cols-1 gap-6">
        <WarehouseStockChart />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <StockIndicatorsTable />
          <ServiceRateTable />
        </div>
      </div>
    </div>
  );
}