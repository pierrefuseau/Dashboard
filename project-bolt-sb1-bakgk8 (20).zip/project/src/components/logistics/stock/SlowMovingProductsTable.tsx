import React from 'react';
import { Card } from '../../common/Card';
import { Package, AlertCircle } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { formatCurrency } from '../../../utils/formatters/currency';

interface SlowMovingProduct {
  code: string;
  name: string;
  quantity: number;
  value: number;
}

export function SlowMovingProductsTable() {
  const { data: products } = useSheetData('LOGISTIQUE', 'E3:G23', {
    transform: (data) => data
      .map(row => {
        // Extraire le code et le nom
        const [code, ...nameParts] = (row[0] || '').toString().split(' - ');
        const name = nameParts.join(' - ');

        return {
          code,
          name,
          // Maintenant row[1] pour la quantité et row[2] pour la valeur
          quantity: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0,
          value: Number(row[2]?.replace(/[^0-9.-]/g, '')) || 0
        };
      })
      .filter(product => product.code && product.value > 0)
      .sort((a, b) => b.value - a.value)
  });

  if (!products?.length) return null;

  const totalValue = products.reduce((sum, product) => sum + product.value, 0);

  const getStatus = (value: number) => {
    if (value > 3000) {
      return {
        label: 'Grave',
        className: 'bg-red-100 text-red-800'
      };
    }
    return {
      label: 'À surveiller',
      className: 'bg-orange-100 text-orange-800'
    };
  };

  return (
    <Card>
      <div className="mb-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-medium text-gray-900">Produits Non Tournants</h3>
            <p className="text-sm text-gray-500 mt-1">
              Produits avec une faible rotation et une valeur importante en stock
            </p>
          </div>
          <div className="bg-orange-50 text-orange-600 px-4 py-2 rounded-lg">
            <div className="text-sm font-medium">Valeur totale</div>
            <div className="text-lg font-semibold">{formatCurrency(totalValue)}</div>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Quantité
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Valeur
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                Statut
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {products.map((product, index) => {
              const status = getStatus(product.value);
              const isHighValue = product.value > 3000;
              
              return (
                <tr 
                  key={product.code}
                  className={`hover:bg-orange-50 transition-colors duration-150 ${
                    isHighValue ? 'bg-orange-50' : ''
                  }`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`
                        flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                        ${isHighValue ? 'bg-red-100' : 'bg-orange-100'}
                      `}>
                        {isHighValue ? (
                          <AlertCircle className="h-5 w-5 text-red-600" />
                        ) : (
                          <Package className="h-5 w-5 text-orange-600" />
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {product.code} - {product.name}
                        </div>
                        {isHighValue && (
                          <div className="text-xs text-red-600 flex items-center">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Valeur élevée en stock
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {product.quantity.toLocaleString('fr-FR')}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(product.value)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`
                      inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium
                      ${status.className}
                    `}>
                      {status.label}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}