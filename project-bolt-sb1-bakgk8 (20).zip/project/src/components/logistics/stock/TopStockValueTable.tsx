import React from 'react';
import { Card } from '../../common/Card';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { Package } from 'lucide-react';
import { formatCurrency } from '../../../utils/formatters/currency';

export function TopStockValueTable() {
  const { data: products, isLoading } = useSheetData('LOGISTIQUE', 'B16:C25', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      value: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
    }))
  });

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  const totalValue = products?.reduce((sum, product) => sum + product.value, 0) || 0;

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Top Produits - Valeur Stock</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Rang
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Valeur
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                % du Total
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {products?.map((product, index) => {
              const percentage = (product.value / totalValue) * 100;
              const isTopPerformer = index === 0;
              
              return (
                <tr 
                  key={product.name}
                  className={`hover:bg-orange-50 transition-colors duration-150 ${
                    isTopPerformer ? 'bg-orange-50' : ''
                  }`}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {index + 1}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`
                        flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                        ${isTopPerformer ? 'bg-orange-100' : 'bg-gray-100'}
                      `}>
                        <Package className={`h-5 w-5 ${isTopPerformer ? 'text-orange-600' : 'text-gray-400'}`} />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {product.name}
                        </div>
                        {isTopPerformer && (
                          <div className="text-xs text-orange-600">
                            Plus grande valeur en stock
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(product.value)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-grow">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-orange-600 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">
                        {percentage.toFixed(1)}%
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}