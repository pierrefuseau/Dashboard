import React from 'react';
import { Card } from '../../common/Card';
import { Package, AlertCircle, Clock } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { formatCurrency } from '../../../utils/formatters/currency';
import { format, differenceInDays, isValid, parse } from 'date-fns';
import { fr } from 'date-fns/locale';

interface FreshProduct {
  code: string;
  name: string;
  lot: string;
  ddm: Date;
  quantity: number;
  value: number;
  daysUntilDdm: number;
}

export function FreshProductsTable() {
  const { data: products } = useSheetData('LOGISTIQUE', 'E30:K43', {
    transform: (data) => data
      .map(row => {
        // Parsing de la date avec validation
        const rawDate = row[3]?.toString() || '';
        let ddm: Date | null = null;

        // Essayer différents formats de date
        const formats = ['dd/MM/yyyy', 'yyyy-MM-dd', 'dd-MM-yyyy'];
        for (const dateFormat of formats) {
          const parsedDate = parse(rawDate, dateFormat, new Date());
          if (isValid(parsedDate)) {
            ddm = parsedDate;
            break;
          }
        }

        if (!ddm) return null;

        return {
          code: row[0] || '',
          name: row[1] || '',
          lot: row[2] || '',
          ddm,
          quantity: Number(row[4]?.replace(/[^0-9.-]/g, '')) || 0,
          value: Number(row[5]?.replace(/[^0-9.-]/g, '')) || 0,
          daysUntilDdm: differenceInDays(ddm, new Date())
        };
      })
      .filter((product): product is FreshProduct => 
        product !== null && 
        Boolean(product.code) && 
        Boolean(product.ddm)
      )
      .sort((a, b) => a.daysUntilDdm - b.daysUntilDdm)
  });

  if (!products?.length) return null;

  const totalValue = products.reduce((sum, product) => sum + product.value, 0);

  const getStatus = (daysUntilDdm: number) => {
    if (daysUntilDdm <= 7) {
      return {
        label: 'Critique',
        className: 'bg-red-100 text-red-800'
      };
    }
    if (daysUntilDdm <= 30) {
      return {
        label: 'Urgent',
        className: 'bg-orange-100 text-orange-800'
      };
    }
    return {
      label: 'À surveiller',
      className: 'bg-yellow-100 text-yellow-800'
    };
  };

  return (
    <Card>
      <div className="mb-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-medium text-gray-900">Produits Frais - DDM Courtes</h3>
            <p className="text-sm text-gray-500 mt-1">
              Produits avec des dates de durabilité minimale proches
            </p>
          </div>
          <div className="bg-orange-50 text-orange-600 px-4 py-2 rounded-lg">
            <div className="text-sm font-medium">Valeur concernée</div>
            <div className="text-lg font-semibold">{formatCurrency(totalValue)}</div>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                Lot
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                DDM
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Quantité
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Valeur
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                Statut
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {products.map((product) => {
              const status = getStatus(product.daysUntilDdm);
              const isCritical = product.daysUntilDdm <= 7;
              
              return (
                <tr 
                  key={`${product.code}-${product.lot}`}
                  className={`hover:bg-orange-50 transition-colors duration-150 ${
                    isCritical ? 'bg-red-50' : ''
                  }`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`
                        flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                        ${isCritical ? 'bg-red-100' : 'bg-orange-100'}
                      `}>
                        <Package className={`h-5 w-5 ${isCritical ? 'text-red-600' : 'text-orange-600'}`} />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {product.code} - {product.name}
                        </div>
                        {isCritical && (
                          <div className="text-xs text-red-600 flex items-center">
                            <Clock className="w-3 h-3 mr-1" />
                            DDM dans {product.daysUntilDdm} jours
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <div className="text-sm text-gray-900">{product.lot}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <div className="text-sm text-gray-900">
                      {format(product.ddm, 'dd MMM yyyy', { locale: fr })}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {product.quantity.toLocaleString('fr-FR')}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(product.value)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`
                      inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium
                      ${status.className}
                    `}>
                      {status.label}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}