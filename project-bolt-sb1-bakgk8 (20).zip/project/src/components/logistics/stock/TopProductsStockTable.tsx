import React from 'react';
import { Card } from '../../common/Card';
import { Package } from 'lucide-react';
import { formatCurrency } from '../../../utils/formatters/currency';
import { calculateStockPercentage, formatStockValue } from '../../../utils/calculations/stockPercentages';

interface StockProduct {
  code: string;
  name: string;
  value: number;
}

const mockProducts: StockProduct[] = [
  { code: '18465', name: 'CREME DE FRANCE UHT 35% 1L TDCP', value: 307513 },
  { code: '36676', name: 'COUVERTURE NOIRE 50% 52/48/28 10KG', value: 297714 },
  { code: '24256', name: 'DROPS CHOCOLAT 44 % 25 KGS CHOCOVIC', value: 228593 },
  { code: '5216', name: 'COUVERTURE LACTEE 34% VM35 10KG SCHOKIN', value: 199071 },
  { code: '111800', name: 'AMANDES POUDRE BLANCHE CTON 10 KG TDCP', value: 162615 },
  { code: '32811', name: 'BEURRE DE CACAO PALETS 10KG', value: 145000 },
  { code: '29575A', name: 'CREME UHT BLEUE 35 % 1L TDCP', value: 132495 },
  { code: '261010', name: 'BEURRE 82% MOTTE 25KG MILCOBEL', value: 128175 },
  { code: '24256B', name: 'DROPS NOIR 44% 7500 TOUR 25KGS', value: 123048 },
  { code: '35359', name: 'AMANDES POUDRE BLANCHE CTON 10 KG TDCP', value: 110967 }
];

const TOTAL_STOCK = 12560000; // 12.56 M€

export function TopProductsStockTable() {
  return (
    <Card>
      <div className="mb-6">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-900">Top Produits - Valeur Stock</h3>
          <div className="text-sm text-gray-500">
            Stock total : {formatStockValue(TOTAL_STOCK)}
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Valeur
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                % du Total
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {mockProducts.map((product, index) => {
              const percentage = calculateStockPercentage(product.value, TOTAL_STOCK);
              const isTopPerformer = index === 0;
              
              return (
                <tr 
                  key={product.code}
                  className={`hover:bg-orange-50 transition-colors duration-150 ${
                    isTopPerformer ? 'bg-orange-50' : ''
                  }`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`
                        flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                        ${isTopPerformer ? 'bg-orange-100' : 'bg-gray-100'}
                      `}>
                        <Package className={`h-5 w-5 ${isTopPerformer ? 'text-orange-600' : 'text-gray-400'}`} />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {product.code} - {product.name}
                        </div>
                        {isTopPerformer && (
                          <div className="text-xs text-orange-600">
                            Plus grande valeur en stock
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(product.value)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-grow">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-orange-600 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">
                        {percentage.toFixed(1)}%
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}