import React from 'react';
import { Card } from '../../common/Card';
import { useSheetData } from '../../../hooks/sheets/useSheetData';

export function StockIndicatorsTable() {
  const { data: stockData, isLoading } = useSheetData('LOGISTIQUE', 'B13:E15', {
    transform: (data) => data.map(row => ({
      indicator: row[0] || '',
      target: row[1]?.replace(/[^0-9.-]+/g, '') || '0',
      current: row[2]?.replace(/[^0-9.-]+/g, '') || '0',
      previous: row[3]?.replace(/[^0-9.-]+/g, '') || '0'
    }))
  });

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <Card title="Indicateurs Stock">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Indicateur
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Objectif
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actuel
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Évolution
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {stockData?.map((item) => {
              const current = parseFloat(item.current);
              const previous = parseFloat(item.previous);
              const evolution = ((current - previous) / previous) * 100;
              
              return (
                <tr key={item.indicator}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {item.indicator}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.target}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.current}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      evolution >= 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {evolution.toFixed(1)}%
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}