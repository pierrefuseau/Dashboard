import React, { useState } from 'react';
import { Card } from '../../common/Card';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { useWarehouseStocks, useTotalStock } from '../../../hooks/logistics/useWarehouseStocks';
import { formatMillionsEuros } from '../../../utils/formatters/currency';
import { Warehouse, Building, Building2, Factory } from 'lucide-react';

// Configuration des icônes et couleurs par entrepôt
const WAREHOUSE_CONFIG = {
  'FUSEAU SAS': {
    colors: ['#f97316', '#ea580c'], // orange-500, orange-600
    icon: Factory
  },
  'FUSEAU LOGISTIQUE LA CLAIE': {
    colors: ['#fb923c', '#f97316'], // orange-400, orange-500
    icon: Warehouse
  },
  'FUSEAU - ST BARTHELEMY': {
    colors: ['#fdba74', '#fb923c'], // orange-300, orange-400
    icon: Building
  },
  'FUSEAU N°16 LACRETELLE': {
    colors: ['#fed7aa', '#fdba74'], // orange-200, orange-300
    icon: Building2
  }
};

export function WarehouseStockChart() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const { data: warehouseData, isLoading } = useWarehouseStocks();

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600"></div>
        </div>
      </Card>
    );
  }

  if (!warehouseData?.length) return null;

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Répartition des Stocks par Entrepôt</h3>
        <p className="mt-1 text-sm text-gray-500">
          Stock total : <span className="text-orange-600 font-medium">10.68 M€</span>
        </p>
      </div>

      <div className="relative h-[500px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <defs>
              {warehouseData.map((_, index) => {
                const config = WAREHOUSE_CONFIG[warehouseData[index].name];
                return (
                  <linearGradient
                    key={`gradient-${index}`}
                    id={`gradient-${index}`}
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1"
                  >
                    <stop offset="0%" stopColor={config.colors[0]} stopOpacity={0.8} />
                    <stop offset="100%" stopColor={config.colors[1]} stopOpacity={0.9} />
                  </linearGradient>
                );
              })}
            </defs>

            <Pie
              data={warehouseData}
              cx="50%"
              cy="50%"
              innerRadius="60%"
              outerRadius="80%"
              paddingAngle={2}
              dataKey="value"
              onMouseEnter={(_, index) => setActiveIndex(index)}
              onMouseLeave={() => setActiveIndex(null)}
            >
              {warehouseData.map((_, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={`url(#gradient-${index})`}
                  stroke="white"
                  strokeWidth={2}
                  style={{
                    filter: activeIndex === index ? 'drop-shadow(0 0 8px rgba(0,0,0,0.2))' : 'none',
                    transform: activeIndex === index ? 'scale(1.05)' : 'scale(1)',
                    transformOrigin: 'center',
                    transition: 'all 0.3s ease-in-out'
                  }}
                />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>

        <AnimatePresence>
          {activeIndex !== null && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute inset-0 flex items-center justify-center pointer-events-none"
            >
              <div className="bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-orange-100">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="p-2 rounded-full bg-orange-50">
                    {React.createElement(WAREHOUSE_CONFIG[warehouseData[activeIndex].name].icon, {
                      className: "w-6 h-6 text-orange-600"
                    })}
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900">
                    {warehouseData[activeIndex].name}
                  </h4>
                </div>
                <p className="text-2xl font-bold text-orange-600">
                  {formatMillionsEuros(warehouseData[activeIndex].value)}
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  {warehouseData[activeIndex].percentage.toFixed(1)}% du total
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
        {warehouseData.map((warehouse, index) => {
          const config = WAREHOUSE_CONFIG[warehouse.name];
          const Icon = config.icon;
          
          return (
            <motion.div
              key={warehouse.name}
              className={`p-4 rounded-lg transition-colors cursor-pointer ${
                activeIndex === index ? 'bg-orange-50' : 'hover:bg-orange-50/50'
              }`}
              onMouseEnter={() => setActiveIndex(index)}
              onMouseLeave={() => setActiveIndex(null)}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-full bg-orange-50">
                  <Icon className="w-5 h-5 text-orange-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {warehouse.name}
                  </p>
                  <p className="text-sm text-orange-600">
                    {formatMillionsEuros(warehouse.value)}
                  </p>
                  <div className="mt-2 w-full bg-orange-100 rounded-full h-1.5">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-orange-500 to-orange-600"
                      style={{ width: `${warehouse.percentage}%` }}
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </Card>
  );
}