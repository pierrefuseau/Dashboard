import React from 'react';
import { Package, Truck, AlertCircle } from 'lucide-react';
import { LogisticsMetricCard } from './LogisticsMetricCard';
import { useLogisticsMetrics } from '../../../hooks/logistics/useLogisticsMetrics';

export function LogisticsOverview() {
  const metrics = useLogisticsMetrics();

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
      <LogisticsMetricCard
        title="Taux de Service"
        value={metrics.serviceRate}
        icon={Truck}
        format="percentage"
        target={97}
      />
      <LogisticsMetricCard
        title="Valeur Stock"
        value={metrics.stockValue}
        icon={Package}
        format="currency"
      />
      <LogisticsMetricCard
        title="Anomalies"
        value={metrics.anomalies}
        icon={AlertCircle}
        format="number"
        target={5}
      />
    </div>
  );
}