import React from 'react';
import { Package } from 'lucide-react';
import { Card } from '../../common/Card';

interface StockValueCardProps {
  value: number;
}

export function StockValueCard({ value }: StockValueCardProps) {
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
      useGrouping: true
    }).format(val);
  };

  return (
    <Card>
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-gray-500">Valeur Stock Total</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900">
            {formatCurrency(value)}
          </p>
        </div>
        <div className="flex-shrink-0 p-3 rounded-full bg-orange-50">
          <Package className="w-6 h-6 text-orange-600" />
        </div>
      </div>
    </Card>
  );
}