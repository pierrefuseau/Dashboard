import React from 'react';
import { LucideIcon } from 'lucide-react';
import { Card } from '../../common/Card';
import { formatMillionsEuros } from '../../../utils/formatters/currency';

interface LogisticsMetricCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  format?: 'percentage' | 'millions' | 'number';
  target?: number;
}

export function LogisticsMetricCard({
  title,
  value,
  icon: Icon,
  format = 'number',
  target
}: LogisticsMetricCardProps) {
  const formatValue = (val: number) => {
    if (val === 0) return 'Non disponible';
    
    switch (format) {
      case 'percentage':
        return `${val.toFixed(2)}%`;
      case 'millions':
        return formatMillionsEuros(val);
      default:
        return val.toString();
    }
  };

  return (
    <Card>
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900">
            {formatValue(value)}
          </p>
          {target && (
            <p className="text-xs text-gray-500 mt-1">
              Objectif: {format === 'percentage' ? `${target}%` : formatValue(target)}
            </p>
          )}
        </div>
        <div className="flex-shrink-0 p-3 rounded-full bg-orange-50">
          <Icon className="w-6 h-6 text-orange-600" />
        </div>
      </div>
    </Card>
  );
}