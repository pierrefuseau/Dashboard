import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Entrepôt Paris', utilisation: 85 },
  { name: 'Entrepôt Lyon', utilisation: 72 },
  { name: 'Entrepôt Bordeaux', utilisation: 65 },
  { name: 'Entrepôt Marseille', utilisation: 90 },
  { name: 'Entrepôt Lille', utilisation: 78 }
];

export function WarehouseUtilizationChart() {
  return (
    <div className="h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis unit="%" />
          <Tooltip />
          <Bar
            dataKey="utilisation"
            fill="#3b82f6"
            radius={[4, 4, 0, 0]}
            label={{ position: 'top', formatter: (value) => `${value}%` }}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}