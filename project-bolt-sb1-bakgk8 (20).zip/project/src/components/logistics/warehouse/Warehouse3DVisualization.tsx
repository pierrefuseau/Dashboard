import React, { Suspense, useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Html } from '@react-three/drei';
import { Card } from '../../common/Card';
import { LoadingSpinner } from '../../common/LoadingSpinner';
import { Warehouse3DModel } from './models/Warehouse3DModel';
import { StockLevels } from './components/StockLevels';
import { ViewControls } from './components/ViewControls';
import { useWarehouseStocks } from '../../../hooks/logistics/useWarehouseStocks';

export function Warehouse3DVisualization() {
  const { data: warehouseData, isLoading } = useWarehouseStocks();
  const [selectedZone, setSelectedZone] = useState<string | null>(null);
  const [view, setView] = useState<'3d' | 'top'>('3d');
  const controlsRef = useRef(null);

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-[600px]">
          <LoadingSpinner />
        </div>
      </Card>
    );
  }

  return (
    <Card className="relative">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Visualisation 3D des Stocks</h3>
          <p className="text-sm text-gray-500">Vue interactive des niveaux de stock par entrepôt</p>
        </div>
        <ViewControls currentView={view} onViewChange={setView} />
      </div>

      <div className="relative h-[600px] rounded-lg overflow-hidden bg-gray-900">
        <Canvas shadows>
          <PerspectiveCamera 
            makeDefault 
            position={view === '3d' ? [20, 15, 20] : [0, 20, 0]} 
            fov={50}
          />
          
          <ambientLight intensity={0.5} />
          <directionalLight
            position={[10, 10, 10]}
            intensity={1}
            castShadow
            shadow-mapSize-width={2048}
            shadow-mapSize-height={2048}
          />

          <Suspense fallback={null}>
            <Warehouse3DModel 
              data={warehouseData || []}
              selectedZone={selectedZone}
              onZoneSelect={setSelectedZone}
              view={view}
            />
          </Suspense>

          <OrbitControls 
            ref={controlsRef}
            enablePan={true}
            enableZoom={true}
            enableRotate={view === '3d'}
            maxPolarAngle={view === '3d' ? Math.PI / 2 : Math.PI / 2.5}
          />

          {/* Légende et informations */}
          <Html position={[-10, 0, 0]}>
            <div className="bg-white/90 backdrop-blur-sm p-4 rounded-lg shadow-lg border border-gray-200">
              <StockLevels data={warehouseData || []} selectedZone={selectedZone} />
            </div>
          </Html>
        </Canvas>
      </div>

      {/* Contrôles et légende en dehors du Canvas */}
      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Instructions</h4>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Cliquez et faites glisser pour pivoter la vue</li>
            <li>• Utilisez la molette pour zoomer</li>
            <li>• Cliquez sur une zone pour voir les détails</li>
          </ul>
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Légende</h4>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-green-500 rounded" />
              <span className="text-sm text-gray-600">Stock optimal</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-red-500 rounded" />
              <span className="text-sm text-gray-600">Stock critique</span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}