import React from 'react';
import { useLoader } from '@react-three/fiber';
import { TextureLoader } from 'three/src/loaders/TextureLoader';
import { WarehouseStock } from '../../../../hooks/logistics/useWarehouseStocks';

interface Warehouse3DModelProps {
  data: WarehouseStock[];
  selectedZone: string | null;
  onZoneSelect: (zone: string | null) => void;
  view: '3d' | 'top';
}

export function Warehouse3DModel({ 
  data, 
  selectedZone, 
  onZoneSelect,
  view 
}: Warehouse3DModelProps) {
  // Charger les textures
  const concreteTexture = useLoader(TextureLoader, 'https://cdn.jsdelivr.net/gh/pmndrs/drei-assets@master/matcap-porcelain-white.jpg');
  const metalTexture = useLoader(TextureLoader, 'https://cdn.jsdelivr.net/gh/pmndrs/drei-assets@master/matcap-silver.jpg');

  // Calculer les positions et tailles relatives des zones
  const totalValue = data.reduce((sum, zone) => sum + zone.value, 0);
  const maxHeight = 10;

  return (
    <group>
      {/* Sol */}
      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, -0.5, 0]}
        receiveShadow
      >
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial 
          map={concreteTexture}
          roughness={0.8}
          metalness={0.2}
          color="#f3f4f6"
        />
      </mesh>

      {/* Zones de stockage */}
      {data.map((zone, index) => {
        const width = 8;
        const depth = 8;
        const height = (zone.value / totalValue) * maxHeight;
        const spacing = 12;
        const row = Math.floor(index / 2);
        const col = index % 2;
        const x = (col - 0.5) * spacing;
        const z = (row - 0.5) * spacing;

        const isSelected = selectedZone === zone.name;
        const color = isSelected ? '#3b82f6' : '#60a5fa';
        const opacity = isSelected ? 1 : 0.8;

        return (
          <group key={zone.name} position={[x, height / 2, z]}>
            {/* Zone de stockage */}
            <mesh
              castShadow
              receiveShadow
              onClick={() => onZoneSelect(isSelected ? null : zone.name)}
              onPointerOver={(e) => {
                e.stopPropagation();
                document.body.style.cursor = 'pointer';
              }}
              onPointerOut={() => {
                document.body.style.cursor = 'default';
              }}
            >
              <boxGeometry args={[width, height, depth]} />
              <meshStandardMaterial
                color={color}
                transparent
                opacity={opacity}
                metalness={0.5}
                roughness={0.3}
              />
            </mesh>

            {/* Étiquette de la zone */}
            <Html
              position={[0, height + 0.5, 0]}
              center
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.9)',
                padding: '0.5rem 1rem',
                borderRadius: '0.5rem',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                border: '1px solid rgba(0,0,0,0.1)'
              }}
            >
              <div className="text-sm font-medium text-gray-900">{zone.name}</div>
              <div className="text-xs text-gray-600">
                {new Intl.NumberFormat('fr-FR', {
                  style: 'currency',
                  currency: 'EUR',
                  maximumFractionDigits: 0
                }).format(zone.value)}
              </div>
            </Html>
          </group>
        );
      })}
    </group>
  );
}