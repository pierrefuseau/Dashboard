import React from 'react';
import { View, Grid3X3 } from 'lucide-react';

interface ViewControlsProps {
  currentView: '3d' | 'top';
  onViewChange: (view: '3d' | 'top') => void;
}

export function ViewControls({ currentView, onViewChange }: ViewControlsProps) {
  return (
    <div className="flex space-x-2">
      <button
        onClick={() => onViewChange('3d')}
        className={`p-2 rounded-lg transition-colors ${
          currentView === '3d'
            ? 'bg-orange-100 text-orange-600'
            : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'
        }`}
        title="Vue 3D"
      >
        <Grid3X3 className="w-5 h-5" />
      </button>
      <button
        onClick={() => onViewChange('top')}
        className={`p-2 rounded-lg transition-colors ${
          currentView === 'top'
            ? 'bg-orange-100 text-orange-600'
            : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'
        }`}
        title="Vue de dessus"
      >
        <View className="w-5 h-5" />
      </button>
    </div>
  );
}