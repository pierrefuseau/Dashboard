import React from 'react';
import { WarehouseStock } from '../../../../hooks/logistics/useWarehouseStocks';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface StockLevelsProps {
  data: WarehouseStock[];
  selectedZone: string | null;
}

export function StockLevels({ data, selectedZone }: StockLevelsProps) {
  const totalValue = data.reduce((sum, zone) => sum + zone.value, 0);

  return (
    <div className="space-y-4">
      <div>
        <h4 className="text-sm font-medium text-gray-900">Niveaux de Stock</h4>
        <p className="text-xs text-gray-500">Total : {formatCurrency(totalValue)}</p>
      </div>

      <div className="space-y-2">
        {data.map(zone => {
          const percentage = (zone.value / totalValue) * 100;
          const isSelected = selectedZone === zone.name;

          return (
            <div 
              key={zone.name}
              className={`p-2 rounded-lg transition-colors ${
                isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'
              }`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium text-gray-900">{zone.name}</span>
                <span className="text-sm text-gray-600">{formatCurrency(zone.value)}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div
                  className="bg-blue-600 h-1.5 rounded-full transition-all duration-300"
                  style={{ width: `${percentage}%` }}
                />
              </div>
              <div className="mt-1 text-xs text-gray-500 text-right">
                {percentage.toFixed(1)}%
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}