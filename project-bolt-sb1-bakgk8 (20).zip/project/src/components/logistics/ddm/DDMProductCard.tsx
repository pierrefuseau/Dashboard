import React from 'react';
import { DDMProduct } from '../../../types/logistics';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Package, AlertTriangle, Clock, XCircle } from 'lucide-react';
import { motion } from 'framer-motion';

interface DDMProductCardProps {
  product: DDMProduct;
}

export function DDMProductCard({ product }: DDMProductCardProps) {
  const getStatusConfig = (status: DDMProduct['status']) => {
    switch (status) {
      case 'EXPIRED':
        return {
          borderColor: 'border-red-500',
          bgColor: 'bg-red-50',
          icon: XCircle,
          iconColor: 'text-red-500',
          label: 'Périmé',
          labelColor: 'text-red-700 bg-red-100'
        };
      case 'CRITICAL':
        return {
          borderColor: 'border-orange-500',
          bgColor: 'bg-orange-50',
          icon: AlertTriangle,
          iconColor: 'text-orange-500',
          label: 'Critique',
          labelColor: 'text-orange-700 bg-orange-100'
        };
      case 'WARNING':
        return {
          borderColor: 'border-yellow-500',
          bgColor: 'bg-yellow-50',
          icon: Clock,
          iconColor: 'text-yellow-500',
          label: 'À surveiller',
          labelColor: 'text-yellow-700 bg-yellow-100'
        };
      default:
        return {
          borderColor: 'border-gray-200',
          bgColor: 'bg-white',
          icon: Package,
          iconColor: 'text-gray-400',
          label: 'OK',
          labelColor: 'text-green-700 bg-green-100'
        };
    }
  };

  const config = getStatusConfig(product.status);
  const StatusIcon = config.icon;

  // Extraire le code et la description du nom du produit
  const [code, ...descriptionParts] = product.name.split(' - ');
  const description = descriptionParts.join(' - ');

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className={`rounded-lg shadow-sm overflow-hidden transition-all duration-200 
        ${config.borderColor} border-2 ${config.bgColor}`}
    >
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            {/* Code produit */}
            <div className="flex items-center space-x-2 mb-1">
              <StatusIcon className={`w-5 h-5 ${config.iconColor} flex-shrink-0`} />
              <span className="font-medium text-gray-900">{code}</span>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${config.labelColor}`}>
                {config.label}
              </span>
            </div>
            {/* Description complète */}
            <p className="text-sm text-gray-700 font-medium leading-snug">
              {description}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-3">
          <div>
            <span className="text-xs text-gray-500">Lot</span>
            <p className="text-sm font-medium text-gray-900">{product.lot}</p>
          </div>
          <div>
            <span className="text-xs text-gray-500">Quantité</span>
            <p className="text-sm font-medium text-gray-900">
              {product.quantity.toLocaleString('fr-FR')}
            </p>
          </div>
        </div>

        <div className="space-y-2">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-500">DDM</span>
              <span className={`font-medium ${product.status === 'EXPIRED' ? 'text-red-600' : 'text-gray-900'}`}>
                {format(product.ddm, 'dd MMM yyyy', { locale: fr })}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                {product.status !== 'EXPIRED' && (
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      product.status === 'CRITICAL' ? 'bg-orange-500' :
                      product.status === 'WARNING' ? 'bg-yellow-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${Math.max((product.daysUntilDdm / 60) * 100, 0)}%` }}
                  />
                )}
              </div>
              <span className={`text-xs font-medium whitespace-nowrap ${
                product.status === 'EXPIRED' ? 'text-red-600' : 'text-gray-600'
              }`}>
                {product.status === 'EXPIRED' 
                  ? `Périmé depuis ${Math.abs(product.daysUntilDdm)}j`
                  : `${product.daysUntilDdm}j restants`
                }
              </span>
            </div>
          </div>

          <div className="pt-2 border-t border-gray-100">
            <div className="flex justify-between items-center">
              <span className="text-xs text-gray-500">Valeur stock</span>
              <span className="text-sm font-semibold text-gray-900">{product.stockAmount}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}