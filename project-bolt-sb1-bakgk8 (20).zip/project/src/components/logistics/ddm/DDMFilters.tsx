import React from 'react';
import { Search, Filter, Package, Clock } from 'lucide-react';

interface DDMFiltersProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  selectedStatus: 'all' | 'critical' | 'warning' | 'normal';
  onStatusChange: (status: 'all' | 'critical' | 'warning' | 'normal') => void;
  selectedType: 'all' | 'fresh' | 'ambient';
  onTypeChange: (type: 'all' | 'fresh' | 'ambient') => void;
  totalCount: number;
}

export function DDMFilters({
  searchTerm,
  onSearchChange,
  selectedStatus,
  onStatusChange,
  selectedType,
  onTypeChange,
  totalCount
}: DDMFiltersProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
        {/* Recherche */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Rechercher par nom ou lot..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
          />
        </div>

        {/* Filtres */}
        <div className="flex flex-wrap gap-4">
          <select
            value={selectedStatus}
            onChange={(e) => onStatusChange(e.target.value as any)}
            className="pl-3 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 bg-white"
          >
            <option value="all">Tous les statuts</option>
            <option value="critical">Critique (&lt; 7j)</option>
            <option value="warning">À surveiller (7-30j)</option>
            <option value="normal">Normal (&gt; 30j)</option>
          </select>

          <select
            value={selectedType}
            onChange={(e) => onTypeChange(e.target.value as any)}
            className="pl-3 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 bg-white"
          >
            <option value="all">Tous les types</option>
            <option value="fresh">Produits frais</option>
            <option value="ambient">Ambiants & Surgelés</option>
          </select>
        </div>

        {/* Compteur de résultats */}
        <div className="text-sm text-gray-500">
          {totalCount} résultat{totalCount > 1 ? 's' : ''}
        </div>
      </div>
    </div>
  );
}