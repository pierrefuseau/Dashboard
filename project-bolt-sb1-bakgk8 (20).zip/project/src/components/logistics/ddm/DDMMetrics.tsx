import React from 'react';
import { Card } from '../../common/Card';
import { DDMProduct } from '../../../types/logistics';
import { formatCurrency } from '../../../utils/formatters/currency';

interface DDMMetricsProps {
  products: DDMProduct[];
  criticalCount: number;
  warningCount: number;
  normalCount: number;
}

export function DDMMetrics({ 
  products,
  criticalCount,
  warningCount,
  normalCount 
}: DDMMetricsProps) {
  const totalValue = products.reduce((sum, product) => {
    const value = Number(product.stockAmount.replace(/[^0-9.-]/g, ''));
    return sum + (isNaN(value) ? 0 : value);
  }, 0);

  return (
    <div className="grid grid-cols-3 gap-4">
      <Card className="bg-red-50">
        <div className="text-sm font-medium text-red-700">Critique</div>
        <div className="mt-1 text-2xl font-bold text-red-600">{criticalCount}</div>
        <div className="text-sm text-red-500">produits</div>
      </Card>

      <Card className="bg-orange-50">
        <div className="text-sm font-medium text-orange-700">À surveiller</div>
        <div className="mt-1 text-2xl font-bold text-orange-600">{warningCount}</div>
        <div className="text-sm text-orange-500">produits</div>
      </Card>

      <Card className="bg-green-50">
        <div className="text-sm font-medium text-green-700">Normal</div>
        <div className="mt-1 text-2xl font-bold text-green-600">{normalCount}</div>
        <div className="text-sm text-green-500">produits</div>
      </Card>
    </div>
  );
}