import React from 'react';
import { AlertTriangle, Clock, CheckCircle } from 'lucide-react';

interface DDMHeaderProps {
  totalProducts: number;
  criticalCount: number;
  warningCount: number;
  normalCount: number;
}

export function DDMHeader({ 
  totalProducts,
  criticalCount,
  warningCount,
  normalCount 
}: DDMHeaderProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">Gestion des DDM</h2>
          <p className="mt-1 text-sm text-gray-500">
            {totalProducts} produits à surveiller
          </p>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-red-50 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 text-red-500 mr-2" />
            <span className="text-sm font-medium text-red-700">Critique (&lt; 7 jours)</span>
          </div>
          <p className="mt-2 text-2xl font-bold text-red-600">{criticalCount}</p>
          <p className="mt-1 text-sm text-red-500">produits</p>
        </div>

        <div className="bg-orange-50 rounded-lg p-4">
          <div className="flex items-center">
            <Clock className="w-5 h-5 text-orange-500 mr-2" />
            <span className="text-sm font-medium text-orange-700">À surveiller (7-30 jours)</span>
          </div>
          <p className="mt-2 text-2xl font-bold text-orange-600">{warningCount}</p>
          <p className="mt-1 text-sm text-orange-500">produits</p>
        </div>

        <div className="bg-green-50 rounded-lg p-4">
          <div className="flex items-center">
            <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
            <span className="text-sm font-medium text-green-700">Normal (&gt; 30 jours)</span>
          </div>
          <p className="mt-2 text-2xl font-bold text-green-600">{normalCount}</p>
          <p className="mt-1 text-sm text-green-500">produits</p>
        </div>
      </div>
    </div>
  );
}