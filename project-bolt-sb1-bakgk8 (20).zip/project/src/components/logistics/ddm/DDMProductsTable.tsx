import React from 'react';
import { DDMProduct } from '../../../types/logistics';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { cn } from '../../../utils/cn';

interface DDMProductsTableProps {
  products: DDMProduct[];
  className?: string;
}

export function DDMProductsTable({ products, className }: DDMProductsTableProps) {
  const getRowStyle = (daysUntilDdm: number) => {
    if (daysUntilDdm <= 7) return 'bg-red-50';
    if (daysUntilDdm <= 14) return 'bg-orange-50';
    return '';
  };

  return (
    <div className={cn(
      "bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden",
      className
    )}>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Lot
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                DDM
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Quantité
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Montant de stock
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Délai d'alerte
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {products.map((product, index) => (
              <tr 
                key={`${product.name}-${product.lot}-${index}`}
                className={`${getRowStyle(product.daysUntilDdm)} hover:bg-opacity-80 transition-colors`}
              >
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {product.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {product.lot}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {format(product.ddm, 'dd MMM yyyy', { locale: fr })}
                  <span className="ml-2 text-xs text-gray-400">
                    ({product.daysUntilDdm} jours)
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                  {product.quantity.toLocaleString('fr-FR')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {product.stockAmount}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {product.alertDelay}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}