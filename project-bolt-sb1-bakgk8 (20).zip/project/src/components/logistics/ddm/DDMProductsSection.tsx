import React, { useState } from 'react';
import { useStorageProducts } from '../../../hooks/logistics/useStorageProducts';
import { DDMHeader } from './DDMHeader';
import { DDMMetrics } from './DDMMetrics';
import { DDMFilters } from './DDMFilters';
import { DDMProductGrid } from './DDMProductGrid';
import { LoadingSpinner } from '../../common/LoadingSpinner';
import { DDMProduct } from '../../../types/logistics';

export function DDMProductsSection() {
  const { freshProducts, ambientProducts, isLoading } = useStorageProducts();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'critical' | 'warning' | 'normal'>('all');
  const [selectedType, setSelectedType] = useState<'all' | 'fresh' | 'ambient'>('all');

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  const allProducts = [...(freshProducts || []), ...(ambientProducts || [])];

  // Calculate metrics
  const criticalCount = allProducts.filter(p => p.status === 'CRITICAL' || p.status === 'EXPIRED').length;
  const warningCount = allProducts.filter(p => p.status === 'WARNING').length;
  const normalCount = allProducts.filter(p => p.status === 'OK').length;

  // Filter products based on search and filters
  const filteredProducts = allProducts.filter(product => {
    const matchesSearch = searchTerm === '' || 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.lot.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = selectedStatus === 'all' ||
      (selectedStatus === 'critical' && (product.status === 'CRITICAL' || product.status === 'EXPIRED')) ||
      (selectedStatus === 'warning' && product.status === 'WARNING') ||
      (selectedStatus === 'normal' && product.status === 'OK');

    const matchesType = selectedType === 'all' ||
      (selectedType === 'fresh' && product.type === 'FRESH') ||
      (selectedType === 'ambient' && product.type === 'AMBIENT');

    return matchesSearch && matchesStatus && matchesType;
  });

  return (
    <div className="space-y-6">
      <DDMMetrics 
        products={allProducts}
        criticalCount={criticalCount}
        warningCount={warningCount}
        normalCount={normalCount}
      />

      <DDMFilters
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        selectedStatus={selectedStatus}
        onStatusChange={setSelectedStatus}
        selectedType={selectedType}
        onTypeChange={setSelectedType}
        totalCount={filteredProducts.length}
      />

      {filteredProducts.length > 0 ? (
        <DDMProductGrid products={filteredProducts} />
      ) : (
        <div className="text-center text-gray-500 py-8 bg-white rounded-lg shadow-sm border border-gray-200">
          Aucun produit ne correspond aux critères de recherche
        </div>
      )}
    </div>
  );
}