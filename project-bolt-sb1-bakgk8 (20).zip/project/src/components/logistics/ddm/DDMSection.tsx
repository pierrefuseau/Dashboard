import React, { useState } from 'react';
import { DDMHeader } from './DDMHeader';
import { DDMProductsTable } from './DDMProductsTable';
import { DDMProductGrid } from './DDMProductGrid';
import { DDMProduct } from '../../../types/logistics';
import { LayoutGrid, List } from 'lucide-react';

interface DDMSectionProps {
  title: string;
  description?: string;
  products: DDMProduct[];
  tableClassName?: string;
}

export function DDMSection({ title, description, products, tableClassName }: DDMSectionProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-start">
        <DDMHeader 
          title={title}
          description={description}
          totalProducts={products.length} 
          products={products}
        />
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-lg transition-colors ${
              viewMode === 'grid' 
                ? 'bg-blue-100 text-blue-600' 
                : 'hover:bg-gray-100 text-gray-600'
            }`}
          >
            <LayoutGrid className="w-5 h-5" />
          </button>
          <button
            onClick={() => setViewMode('table')}
            className={`p-2 rounded-lg transition-colors ${
              viewMode === 'table' 
                ? 'bg-blue-100 text-blue-600' 
                : 'hover:bg-gray-100 text-gray-600'
            }`}
          >
            <List className="w-5 h-5" />
          </button>
        </div>
      </div>

      {viewMode === 'grid' ? (
        <DDMProductGrid products={products} />
      ) : (
        <DDMProductsTable 
          products={products} 
          className={tableClassName}
        />
      )}
    </div>
  );
}