export function getCountryFlag(countryName: string): string {
  const flags: Record<string, string> = {
    // French Territories
    'REUNION': '🇷🇪',
    'MARTINIQUE': '🇲🇶',
    'GUADELOUPE': '🇬🇵',
    'GUYANE': '🇬🇫',
    'MAYOTTE': '🇾🇹',
    'NOUVELLE CALEDONIE': '🇳🇨',
    'POLYNESIE FRANCAISE': '🇵🇫',
    'SAINT MARTIN': '🇲🇫',
    'SAINT BARTHELEMY': '🇧🇱',
    'WALLIS ET FUTUNA': '🇼🇫',
    'SAINT PIERRE ET MIQUELON': '🇵🇲',

    // Countries
    'MAROC': '🇲🇦',
    'MOROCCO': '🇲🇦', // Added alternative spelling
    'Maroc': '🇲🇦', // Added alternative spelling
    'MAURICE': '🇲🇺',
    'ISRAEL': '🇮🇱',
    'CANADA': '🇨🇦',
    'MEXIQUE': '🇲🇽',
    'COTE IVOIRE': '🇨🇮',
    'FRANCE': '🇫🇷',
    'BELGIQUE': '🇧🇪',
    'SUISSE': '🇨🇭',
    'LUXEMBOURG': '🇱🇺',
    'ESPAGNE': '🇪🇸',
    'ITALIE': '🇮🇹',
    'ALLEMAGNE': '🇩🇪',
    'ROYAUME UNI': '🇬🇧',
    'PAYS BAS': '🇳🇱',
    'PORTUGAL': '🇵🇹',
    'IRLANDE': '🇮🇪',
    'GRECE': '🇬🇷',
    'AUTRICHE': '🇦🇹',
    'POLOGNE': '🇵🇱',
    'REPUBLIQUE TCHEQUE': '🇨🇿',
    'HONGRIE': '🇭🇺',
    'SLOVAQUIE': '🇸🇰',
    'ROUMANIE': '🇷🇴',
    'BULGARIE': '🇧🇬',
    'CROATIE': '🇭🇷',
    'SLOVENIE': '🇸🇮',
    'ESTONIE': '🇪🇪',
    'LETTONIE': '🇱🇻',
    'LITUANIE': '🇱🇹',
    'MALTE': '🇲🇹',
    'CHYPRE': '🇨🇾',
    'FINLANDE': '🇫🇮',
    'SUEDE': '🇸🇪',
    'DANEMARK': '🇩🇰',
    'NORVEGE': '🇳🇴',
    'ISLANDE': '🇮🇸'
  };

  // Normalize country name to handle case variations
  const normalizedCountry = countryName.toUpperCase().trim();
  return flags[normalizedCountry] || '🌍';
}