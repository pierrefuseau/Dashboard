import React, { useRef, useState } from 'react';
import { Card } from '../../common/Card';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { useExportData } from './hooks/useExportData';
import { SearchBar } from './SearchBar';
import { formatCurrency } from '../../../utils/formatters/currency';
import { getCountryFlag } from './utils/countryFlags';
import { Maximize2, Minimize2 } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface ExportMapProps {
  onCountryHover?: (country: string | null) => void;
  highlightedCountry?: string | null;
}

export function ExportMap({ onCountryHover, highlightedCountry }: ExportMapProps) {
  const { data, isLoading } = useExportData();
  const mapRef = useRef<L.Map>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  if (isLoading) {
    return (
      <Card>
        <div className="h-[600px] flex items-center justify-center">
          <div className="text-gray-500">Chargement de la carte...</div>
        </div>
      </Card>
    );
  }

  const clients = data?.clients || [];
  const totalClients = clients.length;

  const handleClientSelect = (client: typeof clients[0]) => {
    if (client.coordinates && mapRef.current) {
      mapRef.current.setView(client.coordinates, 8);
    }
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
    // Permettre à la carte de s'adapter à sa nouvelle taille
    setTimeout(() => {
      if (mapRef.current) {
        mapRef.current.invalidateSize();
      }
    }, 100);
  };

  const mapContent = (
    <div className="relative">
      <SearchBar clients={clients} onClientSelect={handleClientSelect} />
      <div className={`relative ${isFullscreen ? 'h-screen' : 'h-[600px]'} rounded-lg overflow-hidden`}>
        {/* Bouton plein écran permanent */}
        <button
          onClick={toggleFullscreen}
          className="absolute top-4 right-4 z-[999] bg-white p-2 rounded-lg shadow-lg hover:bg-gray-50 transition-colors duration-200 border border-gray-200"
          title={isFullscreen ? 'Quitter le plein écran' : 'Passer en plein écran'}
        >
          {isFullscreen ? (
            <Minimize2 className="h-5 w-5 text-gray-600" />
          ) : (
            <Maximize2 className="h-5 w-5 text-gray-600" />
          )}
        </button>

        <MapContainer
          ref={mapRef}
          center={[20, 0]}
          zoom={2}
          style={{ height: '100%', width: '100%' }}
          scrollWheelZoom={true}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {clients.map((client, index) => (
            client.coordinates && (
              <Marker 
                key={`${client.name}-${index}`}
                position={client.coordinates}
                opacity={highlightedCountry === client.country ? 1 : 0.7}
              >
                <Popup>
                  <div className="p-2">
                    <h3 className="font-medium text-gray-900">{client.name}</h3>
                    <p className="text-sm text-gray-500">
                      {client.city}, {client.country} {getCountryFlag(client.country)}
                    </p>
                    <div className="mt-2 space-y-1">
                      <p className="text-sm">
                        <span className="font-medium">CA:</span> {formatCurrency(client.revenue)}
                      </p>
                      <p className="text-sm">
                        <span className="font-medium">Marge:</span> {client.margin.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                </Popup>
              </Marker>
            )
          ))}
        </MapContainer>
      </div>
    </div>
  );

  if (isFullscreen) {
    return (
      <div className="fixed inset-0 z-50 bg-white">
        <div className="h-full p-4">
          <div className="mb-4">
            <h3 className="text-lg font-medium text-gray-900">Carte des clients Export</h3>
            <p className="mt-1 text-sm text-gray-500">
              {totalClients} clients actifs
            </p>
          </div>
          {mapContent}
        </div>
      </div>
    );
  }

  return (
    <Card>
      <div className="mb-4">
        <h3 className="text-lg font-medium text-gray-900">Carte des clients Export</h3>
        <p className="mt-1 text-sm text-gray-500">
          {totalClients} clients actifs
        </p>
      </div>
      {mapContent}
    </Card>
  );
}