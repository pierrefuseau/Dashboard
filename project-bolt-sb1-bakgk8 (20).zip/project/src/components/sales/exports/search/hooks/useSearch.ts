import { useState, useMemo } from 'react';
import { SearchClient, SearchResult } from '../types';

export function useSearch(clients: SearchClient[]) {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const filteredResults = useMemo(() => {
    if (!query) return [];

    const searchStr = query.toLowerCase();
    return clients
      .map(client => {
        if (client.name.toLowerCase().includes(searchStr)) {
          return { client, matchType: 'name' as const };
        }
        if (client.city.toLowerCase().includes(searchStr)) {
          return { client, matchType: 'city' as const };
        }
        if (client.country.toLowerCase().includes(searchStr)) {
          return { client, matchType: 'country' as const };
        }
        return null;
      })
      .filter((result): result is SearchResult => result !== null)
      .slice(0, 5);
  }, [clients, query]);

  return {
    query,
    setQuery,
    isOpen,
    setIsOpen,
    filteredResults
  };
}