export interface SearchClient {
  name: string;
  city: string;
  country: string;
  coordinates: [number, number];
  revenue: number;
  margin: number;
}

export interface SearchResult {
  client: SearchClient;
  matchType: 'name' | 'city' | 'country';
}