import React from 'react';
import { SearchResult } from '../types';
import { getCountryFlag } from '../../utils/countryFlags';
import { formatCurrency } from '../../../../../utils/formatters/currency';

interface SearchResultsProps {
  results: SearchResult[];
  onSelect: (result: SearchResult) => void;
  maxHeight?: number;
}

export function SearchResults({ results, onSelect, maxHeight = 400 }: SearchResultsProps) {
  if (results.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-xl border border-gray-200 p-4 text-center text-gray-500">
        Aucun résultat trouvé
      </div>
    );
  }

  return (
    <div 
      className="bg-white rounded-lg shadow-xl border border-gray-200 overflow-hidden"
      style={{ maxHeight: `${maxHeight}px` }}
    >
      {results.map((result, index) => (
        <button
          key={`${result.client.name}-${index}`}
          className="w-full px-6 py-4 text-left hover:bg-gray-50 flex items-center space-x-4 border-b last:border-b-0 border-gray-100"
          onClick={() => onSelect(result)}
        >
          <span className="text-2xl flex-shrink-0">{getCountryFlag(result.client.country)}</span>
          <div className="flex-1 min-w-0">
            <div className="font-medium text-gray-900 text-lg">{result.client.name}</div>
            <div className="text-sm text-gray-600 mt-1">
              {result.client.city}, {result.client.country}
            </div>
            <div className="mt-2 flex items-center space-x-4 text-sm">
              <span className="text-gray-700">
                <span className="font-medium">CA:</span> {formatCurrency(result.client.revenue)}
              </span>
              <span className="text-gray-700">
                <span className="font-medium">Marge:</span> {result.client.margin.toFixed(1)}%
              </span>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}