import React, { useRef, useEffect } from 'react';
import { SearchClient } from './types';
import { useSearch } from './hooks/useSearch';
import { SearchInput } from './components/SearchInput';
import { SearchResults } from './components/SearchResults';

interface SearchBarProps {
  clients: SearchClient[];
  onClientSelect: (client: SearchClient) => void;
}

export function SearchBar({ clients, onClientSelect }: SearchBarProps) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const { query, setQuery, isOpen, setIsOpen, filteredResults } = useSearch(clients);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [setIsOpen]);

  const handleClear = () => {
    setQuery('');
    setIsOpen(false);
  };

  const handleSelect = (result: { client: SearchClient }) => {
    onClientSelect(result.client);
    setIsOpen(false);
    setQuery('');
  };

  return (
    <div ref={wrapperRef} className="relative w-full mb-4">
      {/* Barre de recherche */}
      <div className="relative z-40">
        <SearchInput
          value={query}
          onChange={(value) => {
            setQuery(value);
            setIsOpen(true);
          }}
          onClear={handleClear}
        />
      </div>

      {/* Suggestions */}
      {isOpen && (
        <div className="fixed left-0 right-0 top-[120px] mx-auto max-w-3xl px-4 z-50">
          <SearchResults 
            results={filteredResults} 
            onSelect={handleSelect}
            maxHeight={400}
          />
        </div>
      )}
    </div>
  );
}