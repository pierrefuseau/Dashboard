import { useSheetData } from '../../../../hooks/sheets/useSheetData';
import { cityCoordinates } from '../data/cityCoordinates';

export interface ExportClient {
  name: string;
  country: string;
  city: string;
  revenue: number;
  margin: number;
  coordinates?: [number, number];
}

export function useExportData() {
  return useSheetData('VENTES', 'K4:O74', {
    transform: (data) => {
      // Transformer toutes les lignes en clients
      const clients = data
        .filter(row => row[0] && row[1] && row[2]) // Garder uniquement les lignes avec nom, pays et ville
        .map((row) => {
          const name = row[0]?.toString().trim() || '';
          const country = row[1]?.toString().trim() || '';
          const city = row[2]?.toString().trim() || '';
          const revenue = Number(row[3]?.toString().replace(/[^0-9.-]/g, '')) || 0;
          const margin = Number(row[4]?.toString().replace(/[^0-9.-]/g, '')) || 0;

          // Obtenir les coordonnées pour la ville/pays
          let coordinates: [number, number] | undefined;
          
          // Essayer d'abord les coordonnées exactes de la ville
          if (cityCoordinates[country]?.[city]) {
            coordinates = cityCoordinates[country][city];
          } 
          // Si pas de coordonnées exactes, utiliser les coordonnées par défaut du pays avec un offset
          else if (cityCoordinates[country]?.['DEFAULT']) {
            const baseCoords = cityCoordinates[country]['DEFAULT'];
            // Ajouter un offset aléatoire mais stable (basé sur le nom du client)
            const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
            const latOffset = (hash % 100) / 1000 - 0.05; // -0.05 à +0.05
            const lngOffset = ((hash * 31) % 100) / 1000 - 0.05; // -0.05 à +0.05
            coordinates = [
              baseCoords[0] + latOffset,
              baseCoords[1] + lngOffset
            ];
          }

          return {
            name,
            country,
            city,
            revenue,
            margin,
            coordinates
          };
        });

      // Calculer les statistiques par pays
      const countryStats = clients.reduce((acc, client) => {
        const existing = acc.get(client.country) || { revenue: 0, count: 0 };
        existing.revenue += client.revenue;
        existing.count += 1;
        acc.set(client.country, existing);
        return acc;
      }, new Map<string, { revenue: number; count: number }>());

      const totalRevenue = clients.reduce((sum, client) => sum + client.revenue, 0);

      // Préparer les données des pays
      const topCountries = Array.from(countryStats.entries())
        .map(([name, stats]) => ({
          name,
          revenue: stats.revenue,
          percentage: (stats.revenue / totalRevenue) * 100,
          clientCount: stats.count
        }))
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 10);

      return {
        clients,
        topCountries,
        totalRevenue,
        totalClients: clients.length
      };
    }
  });
}