import React, { useState } from 'react';
import { ExportMap } from './ExportMap';
import { TopCountriesPanel } from './TopCountriesPanel';
import { ExportRevenue } from './ExportRevenue';
import { TopFlopClients } from './evolution/TopFlopClients';

export function ExportOverview() {
  const [highlightedCountry, setHighlightedCountry] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <ExportRevenue />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
        <div className="lg:col-span-2">
          <ExportMap 
            onCountryHover={setHighlightedCountry}
            highlightedCountry={highlightedCountry}
          />
        </div>
        <div className="h-full">
          <TopCountriesPanel 
            onCountryHover={setHighlightedCountry}
            highlightedCountry={highlightedCountry}
          />
        </div>
      </div>
      <TopFlopClients />
    </div>
  );
}