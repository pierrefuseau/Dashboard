import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { Card } from '../../common/Card';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { formatCurrency } from '../../../utils/formatters/currency';

export function ExportRevenue() {
  const { data: revenueData, isLoading } = useSheetData('VENTES', 'L1:L2', {
    transform: (data) => ({
      current: Number(data?.[0]?.[0]?.replace(/[^0-9.-]/g, '')) || 0,
      previous: Number(data?.[1]?.[0]?.replace(/[^0-9.-]/g, '')) || 0
    })
  });

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  const evolution = revenueData ? 
    ((revenueData.current - revenueData.previous) / revenueData.previous) * 100 
    : 0;

  return (
    <Card>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* CA Année en cours */}
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500">CA Export {new Date().getFullYear()}</p>
              <p className="mt-2 text-2xl font-semibold text-gray-900">
                {formatCurrency(revenueData?.current || 0)}
              </p>
            </div>
            <div className="p-3 bg-blue-50 rounded-full">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        {/* CA Année précédente */}
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500">CA Export {new Date().getFullYear() - 1}</p>
              <p className="mt-2 text-2xl font-semibold text-gray-900">
                {formatCurrency(revenueData?.previous || 0)}
              </p>
            </div>
            <div className="p-3 bg-blue-50 rounded-full">
              <TrendingDown className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Évolution */}
      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-gray-600">Évolution</span>
          <span className={`text-sm font-medium ${evolution >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {evolution >= 0 ? '+' : ''}{evolution.toFixed(1)}%
          </span>
        </div>
      </div>
    </Card>
  );
}