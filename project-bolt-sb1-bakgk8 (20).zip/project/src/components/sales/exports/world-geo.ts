// Import world GeoJSON data
export const worldGeoData = {
  "type": "FeatureCollection",
  "features": [
    // Add simplified world GeoJSON data here
    // For brevity, I'm not including the full data
    // You should add the complete GeoJSON data from a reliable source
  ]
};