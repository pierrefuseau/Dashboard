import React, { useState, useRef, useEffect } from 'react';
import { Search } from 'lucide-react';
import { ExportClient } from './hooks/useExportData';
import { getCountryFlag } from './utils/countryFlags';
import { formatCurrency } from '../../../utils/formatters/currency';

interface SearchBarProps {
  clients: ExportClient[];
  onClientSelect: (client: ExportClient) => void;
}

export function SearchBar({ clients, onClientSelect }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredClients = query === '' ? [] : clients.filter(client => {
    const searchStr = query.toLowerCase();
    return (
      client.name.toLowerCase().includes(searchStr) ||
      client.city.toLowerCase().includes(searchStr) ||
      client.country.toLowerCase().includes(searchStr)
    );
  });

  return (
    <div ref={wrapperRef} className="relative w-full mb-4">
      {/* Barre de recherche */}
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          placeholder="Rechercher un client par nom, ville ou pays..."
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        {query && (
          <button
            onClick={() => {
              setQuery('');
              setIsOpen(false);
            }}
            className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600"
          >
            ×
          </button>
        )}
      </div>

      {/* Suggestions - Maintenant positionnées au-dessus de la carte */}
      {isOpen && filteredClients.length > 0 && (
        <div className="absolute left-0 right-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 z-[1000]">
          <div className="max-h-[400px] overflow-y-auto">
            {filteredClients.map((client, index) => (
              <button
                key={`${client.name}-${index}`}
                className="w-full px-4 py-3 text-left hover:bg-gray-50 flex items-center space-x-3 border-b last:border-b-0 border-gray-100"
                onClick={() => {
                  onClientSelect(client);
                  setIsOpen(false);
                  setQuery('');
                }}
              >
                <span className="text-xl flex-shrink-0">{getCountryFlag(client.country)}</span>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-gray-900 truncate">{client.name}</div>
                  <div className="text-sm text-gray-500">
                    {client.city}, {client.country}
                  </div>
                  <div className="mt-1 text-sm text-gray-600">
                    CA: {formatCurrency(client.revenue)} | Marge: {client.margin.toFixed(1)}%
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Message si aucun résultat */}
      {isOpen && query && filteredClients.length === 0 && (
        <div className="absolute left-0 right-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 p-4 text-center text-gray-500 z-[1000]">
          Aucun résultat trouvé
        </div>
      )}
    </div>
  );
}