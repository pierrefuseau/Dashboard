import React from 'react';
import { Card } from '../../common/Card';
import { useExportData } from './hooks/useExportData';
import { formatCurrency } from '../../../utils/formatters/currency';
import { getCountryFlag } from './utils/countryFlags';

interface TopCountriesPanelProps {
  onCountryHover?: (country: string | null) => void;
  highlightedCountry?: string | null;
}

export function TopCountriesPanel({ onCountryHover, highlightedCountry }: TopCountriesPanelProps) {
  const { data, isLoading } = useExportData();

  if (isLoading) {
    return (
      <Card className="h-full">
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">Chargement des données...</div>
        </div>
      </Card>
    );
  }

  const countries = data?.topCountries || [];

  return (
    <Card className="h-full">
      <div className="flex flex-col h-full">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Meilleurs Pays</h3>
        
        <div className="flex-1 space-y-3">
          {countries.map((country) => (
            <div 
              key={country.name}
              className={`flex flex-col transition-colors duration-200 py-1 ${
                highlightedCountry === country.name ? 'bg-blue-50 rounded-lg px-2 -mx-2' : ''
              }`}
              onMouseEnter={() => onCountryHover?.(country.name)}
              onMouseLeave={() => onCountryHover?.(null)}
            >
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center space-x-2">
                  <span className="text-xl">{getCountryFlag(country.name)}</span>
                  <span className="text-sm font-medium text-gray-900">
                    {country.name}
                  </span>
                </div>
                <span className="text-sm font-medium text-gray-900 whitespace-nowrap">
                  {formatCurrency(country.revenue)}
                </span>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className="flex-1">
                  <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-blue-500 rounded-full transition-all duration-300"
                      style={{ width: `${country.percentage}%` }}
                    />
                  </div>
                </div>
                <div className="text-xs text-gray-500 min-w-[3rem] text-right">
                  {country.percentage.toFixed(1)}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}