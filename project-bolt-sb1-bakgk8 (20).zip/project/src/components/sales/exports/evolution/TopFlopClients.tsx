import React from 'react';
import { Card } from '../../../common/Card';
import { ClientEvolutionList } from './ClientEvolutionList';
import { useClientEvolutions } from './hooks/useClientEvolutions';
import { TrendingUp, TrendingDown } from 'lucide-react';

export function TopFlopClients() {
  const { data: clients, isLoading } = useClientEvolutions();

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  // Trier les clients par évolution
  const sortedClients = [...(clients || [])].sort((a, b) => b.evolution - a.evolution);
  const topClients = sortedClients.slice(0, 5);
  const flopClients = sortedClients.slice(-5).reverse();

  return (
    <Card className="overflow-hidden">
      <div className="mb-8">
        <h3 className="text-xl font-semibold text-gray-900">
          Évolution Clients (Top & Flop)
        </h3>
        <p className="mt-2 text-sm text-gray-500">
          Analyse des meilleures et moins bonnes performances
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Top 5 */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-green-50">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <h4 className="text-lg font-semibold text-gray-900">
              Top 5 Clients
            </h4>
          </div>
          <ClientEvolutionList clients={topClients} type="top" />
        </div>

        {/* Flop 5 */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-red-50">
              <TrendingDown className="w-5 h-5 text-red-600" />
            </div>
            <h4 className="text-lg font-semibold text-gray-900">
              Flop 5 Clients
            </h4>
          </div>
          <ClientEvolutionList clients={flopClients} type="flop" />
        </div>
      </div>
    </Card>
  );
}