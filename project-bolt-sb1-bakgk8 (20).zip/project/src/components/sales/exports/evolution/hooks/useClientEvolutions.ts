import { useSheetData } from '../../../../../hooks/sheets/useSheetData';
import { ClientEvolution } from '../types';

export function useClientEvolutions() {
  return useSheetData<ClientEvolution[]>('VENTES', 'H22:I31', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      evolution: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
    }))
    .filter(client => client.name && !isNaN(client.evolution))
  });
}