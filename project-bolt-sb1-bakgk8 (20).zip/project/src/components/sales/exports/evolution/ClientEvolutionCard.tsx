import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { ClientEvolution } from './types';
import { Tooltip } from '../../../common/Tooltip';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface ClientEvolutionCardProps {
  client: ClientEvolution;
  rank: number;
  type: 'top' | 'flop';
}

export function ClientEvolutionCard({ client, rank, type }: ClientEvolutionCardProps) {
  const isPositive = client.evolution >= 0;
  
  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
      className={`
        relative p-5 rounded-xl border shadow-sm transition-all duration-200
        hover:shadow-md backdrop-blur-sm
        ${type === 'top' 
          ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-100' 
          : 'bg-gradient-to-br from-red-50 to-rose-50 border-red-100'
        }
      `}
    >
      <Tooltip
        content={
          <div className="text-sm">
            <p className="font-semibold">{client.name}</p>
            <p className="text-gray-200 mt-1">
              Évolution: {isPositive ? '+' : ''}{formatCurrency(client.evolution)}
            </p>
          </div>
        }
      >
        <div className="flex items-center justify-between space-x-4">
          {/* Rang et Nom */}
          <div className="flex items-center space-x-4 flex-1 min-w-0">
            <div className={`
              w-8 h-8 flex items-center justify-center rounded-full 
              font-semibold text-sm transition-colors
              ${type === 'top' 
                ? 'bg-green-100 text-green-700' 
                : 'bg-red-100 text-red-700'
              }
            `}>
              {rank}
            </div>
            <div className="min-w-0">
              <h4 className="text-base font-semibold text-gray-900 truncate">
                {client.name}
              </h4>
            </div>
          </div>

          {/* Évolution et Icône */}
          <div className={`
            flex items-center space-x-2 px-3 py-1.5 rounded-full
            ${type === 'top'
              ? 'bg-green-100/50 text-green-700'
              : 'bg-red-100/50 text-red-700'
            }
          `}>
            <span className="text-sm font-medium whitespace-nowrap">
              {isPositive ? '+' : ''}{formatCurrency(client.evolution)}
            </span>
            <motion.div
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              {isPositive ? (
                <ArrowUpRight className="w-4 h-4 flex-shrink-0" />
              ) : (
                <ArrowDownRight className="w-4 h-4 flex-shrink-0" />
              )}
            </motion.div>
          </div>
        </div>
      </Tooltip>
    </motion.div>
  );
}