export interface ClientEvolution {
  name: string;
  evolution: number;
}