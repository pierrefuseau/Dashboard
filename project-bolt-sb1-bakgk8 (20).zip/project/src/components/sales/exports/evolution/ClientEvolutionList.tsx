import React from 'react';
import { motion } from 'framer-motion';
import { ClientEvolutionCard } from './ClientEvolutionCard';
import { ClientEvolution } from './types';

interface ClientEvolutionListProps {
  clients: ClientEvolution[];
  type: 'top' | 'flop';
}

export function ClientEvolutionList({ clients, type }: ClientEvolutionListProps) {
  return (
    <motion.div 
      className="space-y-4"
      initial="hidden"
      animate="visible"
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            staggerChildren: 0.1
          }
        }
      }}
    >
      {clients.map((client, index) => (
        <motion.div
          key={client.name}
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: { opacity: 1, y: 0 }
          }}
        >
          <ClientEvolutionCard
            client={client}
            rank={index + 1}
            type={type}
          />
        </motion.div>
      ))}
    </motion.div>
  );
}