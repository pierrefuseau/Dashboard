// Simplified world GeoJSON data with focus on relevant countries
export const worldGeoData = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {
        "name": "REUNION"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [55.536384, -21.115141]
      }
    },
    {
      "type": "Feature", 
      "properties": {
        "name": "CANADA"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-106.346771, 56.130366]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "MEXIQUE"
      },
      "geometry": {
        "type": "Point", 
        "coordinates": [-102.552784, 23.634501]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "MAYOTTE"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [45.166244, -12.8275]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "COTE IVOIRE"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-5.54708, 7.539989]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "GUADELOUPE"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-61.551701, 16.265]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "MARTINIQUE"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-61.024174, 14.641528]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "GUYANE"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-53.125782, 3.933889]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "NOUVELLE CALEDONIE"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [165.618042, -20.904305]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "POLYNESIE FRANCAISE"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-149.406843, -17.679742]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "SAINT MARTIN"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-63.052251, 18.0708]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "SAINT BARTHELEMY"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-62.833333, 17.9]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "WALLIS ET FUTUNA"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-178.131667, -14.2938]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "SAINT PIERRE ET MIQUELON"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [-56.27111, 46.8852]
      }
    }
  ]
};