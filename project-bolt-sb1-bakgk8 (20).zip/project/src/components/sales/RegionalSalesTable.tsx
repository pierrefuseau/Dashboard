import React from 'react';

const data = [
  { region: 'Île-de-France', ventes: '€845,000', evolution: 12.5 },
  { region: 'Auvergne-Rhône-Alpes', ventes: '€654,000', evolution: 8.2 },
  { region: 'Nouvelle-Aquitaine', ventes: '€425,000', evolution: 15.3 },
  { region: 'Occitanie', ventes: '€312,000', evolution: 6.8 },
  { region: 'Hauts-de-France', ventes: '€289,000', evolution: 9.1 },
];

export function RegionalSalesTable() {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Région
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Ventes
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Évolution
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {data.map((item) => (
            <tr key={item.region}>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                {item.region}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {item.ventes}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  item.evolution >= 10 ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                }`}>
                  +{item.evolution}%
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}