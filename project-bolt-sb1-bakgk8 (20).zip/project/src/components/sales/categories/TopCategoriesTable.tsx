import React from 'react';
import { Card } from '../../common/Card';
import { Package, Award } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { formatCurrency } from '../../../utils/formatters/currency';

export function TopCategoriesTable() {
  const { data: categories, isLoading } = useSheetData('VENTES', 'H4:I8', {
    transform: (data) => data
      .filter(row => row[0] && row[1]) // Filtrer les lignes vides
      .map(row => ({
        name: row[0] || '',
        revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
      }))
      .filter(category => category.revenue > 0) // Filtrer les catégories avec un CA de 0
  });

  const { data: totalRevenue } = useSheetData('VENTES', 'C3', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
    }
  });

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Top Catégories</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Catégorie
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                CA
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                % du CA Total
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {categories?.map((category, index) => {
              const percentage = totalRevenue ? (category.revenue / totalRevenue) * 100 : 0;
              const isTopPerformer = index === 0;
              
              return (
                <tr 
                  key={category.name}
                  className={`hover:bg-blue-50 transition-colors duration-150 ${
                    isTopPerformer ? 'bg-blue-50' : ''
                  }`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`
                        flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                        ${isTopPerformer ? 'bg-blue-100' : 'bg-gray-100'}
                      `}>
                        {isTopPerformer ? (
                          <Award className="h-5 w-5 text-blue-600" />
                        ) : (
                          <Package className="h-5 w-5 text-gray-400" />
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {category.name}
                        </div>
                        {isTopPerformer && (
                          <div className="text-xs text-blue-600">
                            Meilleure catégorie
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(category.revenue)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-grow">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">
                        {percentage.toFixed(1)}%
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}