import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';
import { Card } from '../../common/Card';
import { formatMillionsEuros } from '../../../utils/formatters/currency';

interface SalesMetricCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  format: 'currency' | 'number';
  color?: 'blue' | 'red' | 'green' | 'orange';
}

export function SalesMetricCard({
  title,
  value,
  icon: Icon,
  format = 'currency',
  color = 'blue'
}: SalesMetricCardProps) {
  const formattedValue = format === 'currency' 
    ? formatMillionsEuros(value)
    : value.toLocaleString('fr-FR');

  const colorClasses = {
    blue: { bg: 'bg-blue-50', text: 'text-blue-600' },
    red: { bg: 'bg-red-50', text: 'text-red-600' },
    green: { bg: 'bg-green-50', text: 'text-green-600' },
    orange: { bg: 'bg-orange-50', text: 'text-orange-600' }
  }[color];

  return (
    <Card className="relative">
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-gray-500 truncate">{title}</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900 truncate">
            {formattedValue}
          </p>
        </div>
        <div className={`flex-shrink-0 p-3 rounded-full ${colorClasses.bg}`}>
          <Icon className={`w-6 h-6 ${colorClasses.text}`} />
        </div>
      </div>
    </Card>
  );
}