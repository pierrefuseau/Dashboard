import React from 'react';
import { BarChart3, TrendingUp } from 'lucide-react';
import { SalesMetricCard } from './SalesMetricCard';
import { useSalesMetrics } from '../../../hooks/sales/useSalesMetrics';

export function SalesOverview() {
  const { revenue, margin, isLoading } = useSalesMetrics();

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
      <SalesMetricCard
        title="Chiffre d'affaires"
        value={revenue}
        icon={BarChart3}
        format="currency"
      />
      <SalesMetricCard
        title="Marge"
        value={margin}
        icon={TrendingUp}
        format="currency"
      />
    </div>
  );
}