import React from 'react';
import { TopClientsView } from './TopClientsView';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { LoadingSpinner } from '../../common/LoadingSpinner';
import { kgToTonnes } from '../../../utils/formatters/volume';

export function TopClientsPage() {
  const { data: clients, isLoading } = useSheetData('VENTES', 'B13:F17', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0,
      marginPercent: Number(row[2]?.replace(/[^0-9.-]/g, '')) || 0,
      marginValue: Number(row[3]?.replace(/[^0-9.-]/g, '')) || 0,
      // Convertir le volume de KG en tonnes
      volume: kgToTonnes(Number(row[4]?.replace(/[^0-9.-]/g, '')) || 0)
    }))
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return <TopClientsView clients={clients || []} />;
}