export interface Client {
  name: string;
  revenue: number;
  marginPercent: number;
  marginValue: number;
  volume: number;
}

export interface ClientCardProps extends Client {
  isTopClient?: boolean;
  rank: number;
}