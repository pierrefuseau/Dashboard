/**
 * Formate un volume sans virgules avec des espaces comme séparateurs de milliers
 */
export function formatVolume(volume: number): string {
  return Math.round(volume).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}