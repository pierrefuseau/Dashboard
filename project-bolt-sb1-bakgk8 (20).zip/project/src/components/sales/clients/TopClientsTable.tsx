import React from 'react';
import { Card } from '../../common/Card';
import { Package, Award } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { formatCurrency } from '../../../utils/formatters/currency';

export function TopClientsTable() {
  const { data: clients, isLoading } = useSheetData('VENTES', 'B13:F17', {
    transform: (data) => data
      .filter(row => row[0] && row[1]) // Filtrer les lignes vides
      .map(row => ({
        name: row[0] || '',
        revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0,
        marginPercent: Number(row[2]?.replace(/[^0-9.-]/g, '')) || 0,
        marginValue: Number(row[3]?.replace(/[^0-9.-]/g, '')) || 0,
        volume: Number(row[4]?.replace(/[^0-9.-]/g, '')) || 0
      }))
  });

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </Card>
    );
  }

  if (!clients?.length) {
    return (
      <Card>
        <div className="text-center py-12">
          <p className="text-gray-500">Aucun client à afficher</p>
        </div>
      </Card>
    );
  }

  const totalRevenue = clients.reduce((sum, client) => sum + client.revenue, 0);

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Top Clients</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Client
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                CA
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Marge %
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Marge €
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Volume
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {clients.map((client, index) => {
              const isTopPerformer = index === 0;
              
              return (
                <tr 
                  key={client.name}
                  className={`${isTopPerformer ? 'bg-blue-50' : ''} hover:bg-gray-50`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${
                        isTopPerformer ? 'bg-blue-100' : 'bg-gray-100'
                      }`}>
                        {isTopPerformer ? (
                          <Award className="h-5 w-5 text-blue-600" />
                        ) : (
                          <Package className="h-5 w-5 text-gray-400" />
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {client.name}
                        </div>
                        {isTopPerformer && (
                          <div className="text-xs text-blue-600">
                            Meilleur client
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-900">
                    {formatCurrency(client.revenue)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                    {client.marginPercent.toFixed(2)}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                    {formatCurrency(client.marginValue)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                    {client.volume.toLocaleString('fr-FR')}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}