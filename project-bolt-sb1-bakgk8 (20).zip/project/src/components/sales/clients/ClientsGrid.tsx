import React from 'react';
import { ClientCard } from './ClientCard';
import { Client } from './types';

interface ClientsGridProps {
  clients: Client[];
}

export function ClientsGrid({ clients }: ClientsGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {clients.map((client, index) => (
        <ClientCard
          key={client.name}
          {...client}
          isTopClient={index === 0}
          rank={index + 1}
        />
      ))}
    </div>
  );
}