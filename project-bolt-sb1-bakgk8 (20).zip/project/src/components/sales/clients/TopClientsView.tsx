import React from 'react';
import { ClientsGrid } from './ClientsGrid';

interface TopClientsViewProps {
  clients: Array<{
    name: string;
    revenue: number;
    marginPercent: number;
    marginValue: number;
    volume: number;
  }>;
}

export function TopClientsView({ clients }: TopClientsViewProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Top Clients</h2>
        <p className="text-sm text-gray-500 mt-1">
          Performance des meilleurs clients
        </p>
      </div>

      <ClientsGrid clients={clients} />
    </div>
  );
}