import React from 'react';
import { Award, TrendingUp, Package } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../utils/formatters/currency';
import { formatVolume } from './utils/formatters';
import { ClientCardProps } from './types';

export function ClientCard({
  name,
  revenue,
  marginPercent,
  marginValue,
  volume,
  isTopClient,
  rank
}: ClientCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`
        relative overflow-hidden rounded-xl border p-6 shadow-sm
        ${isTopClient ? 'border-blue-200 bg-blue-50/50' : 'border-gray-200 bg-white'}
        hover:shadow-md transition-all duration-200
      `}
    >
      {/* Badge Top Client */}
      {isTopClient && (
        <div className="absolute top-4 right-4">
          <div className="flex items-center space-x-1 bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-medium">
            <Award className="w-3 h-3" />
            <span>Top {rank}</span>
          </div>
        </div>
      )}

      {/* En-tête avec nom et icône */}
      <div className="flex items-center space-x-4 mb-6">
        <div className={`p-3 rounded-lg ${isTopClient ? 'bg-blue-100' : 'bg-gray-100'}`}>
          {isTopClient ? (
            <Award className="w-6 h-6 text-blue-600" />
          ) : (
            <Package className="w-6 h-6 text-gray-600" />
          )}
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{name}</h3>
          {isTopClient && (
            <span className="text-sm text-blue-600 font-medium">
              Meilleur client
            </span>
          )}
        </div>
      </div>

      {/* Métriques */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        {/* CA */}
        <div className="bg-white p-4 rounded-lg border border-gray-100">
          <div className="text-sm text-gray-500 mb-1">Chiffre d'affaires</div>
          <div className="text-lg font-semibold text-gray-900">
            {formatCurrency(revenue)}
          </div>
        </div>

        {/* Volume */}
        <div className="bg-white p-4 rounded-lg border border-gray-100">
          <div className="text-sm text-gray-500 mb-1">Volume</div>
          <div className="text-lg font-semibold text-gray-900">
            {formatVolume(volume)} T
          </div>
        </div>
      </div>

      {/* Marge */}
      <div className="bg-white p-4 rounded-lg border border-gray-100">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-500">Marge</span>
          <div className="flex items-center text-green-600">
            <TrendingUp className="w-4 h-4 mr-1" />
            <span className="text-sm font-medium">{marginPercent.toFixed(2)}%</span>
          </div>
        </div>
        <div className="text-lg font-semibold text-gray-900">
          {formatCurrency(marginValue)}
        </div>
      </div>
    </motion.div>
  );
}