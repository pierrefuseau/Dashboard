export interface ClientType {
  name: string;
  revenue: number;
  percentage: number;
  icon?: string;
}