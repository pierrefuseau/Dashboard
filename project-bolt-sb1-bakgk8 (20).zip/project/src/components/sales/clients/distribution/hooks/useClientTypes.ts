import { useSheetData } from '../../../../../hooks/sheets/useSheetData';
import { ClientType } from '../types';

export function useClientTypes() {
  return useSheetData<ClientType[]>('VENTES', 'B22:C26', {
    transform: (data) => {
      const items = data.map(row => ({
        name: row[0] || '',
        revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
      }))
      .filter(item => item.name && item.revenue > 0);

      const total = items.reduce((sum, item) => sum + item.revenue, 0);
      
      return items.map(item => ({
        ...item,
        percentage: (item.revenue / total) * 100
      }));
    }
  });
}