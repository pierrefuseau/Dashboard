import { Factory, CakeSlice, ShoppingCart, Store, Truck } from 'lucide-react';

export function getClientTypeIcon(typeName: string) {
  const icons: Record<string, any> = {
    'INDUSTRIEL': Factory,
    'ARTISANS BOUL/PAT/CHOLATIER': CakeSlice,
    'GRANDE SURFACE': ShoppingCart,
    'FRANCHISE': Store,
    'DISTRIBUTEUR': Truck
  };

  return icons[typeName] || Factory;
}