import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from '../../../common/Card';
import { ClientTypeTooltip } from './ClientTypeTooltip';
import { ClientTypeLegend } from './ClientTypeLegend';
import { useClientTypes } from './hooks/useClientTypes';
import { formatCurrency } from '../../../../utils/formatters/currency';

// Palette de couleurs distincte pour chaque typologie
const CLIENT_COLORS = {
  'INDUSTRIEL': ['#2563eb', '#1d4ed8'], // Bleu royal
  'ARTISANS BOUL/PAT/CHOLATIER': ['#059669', '#047857'], // Vert émeraude
  'GRANDE SURFACE': ['#7c3aed', '#6d28d9'], // Violet
  'FRANCHISE': ['#ea580c', '#c2410c'], // Orange brûlé
  'DISTRIBUTEUR': ['#0891b2', '#0e7490']  // Cyan
};

// Couleurs par défaut si le type n'est pas trouvé
const DEFAULT_COLORS = ['#6b7280', '#4b5563'];

export function ClientDistributionChart() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const { data: clientTypes, isLoading } = useClientTypes();

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </Card>
    );
  }

  const totalRevenue = clientTypes?.reduce((sum, type) => sum + type.revenue, 0) || 0;

  // Fonction pour obtenir les couleurs du gradient pour un type de client
  const getTypeColors = (typeName: string) => {
    return CLIENT_COLORS[typeName] || DEFAULT_COLORS;
  };

  // Calculer les positions des labels
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = outerRadius + 30;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    const clientType = clientTypes?.[index];

    if (!clientType) return null;

    return (
      <g>
        <path
          d={`M ${cx + (outerRadius + 5) * Math.cos(-midAngle * RADIAN)},${
            cy + (outerRadius + 5) * Math.sin(-midAngle * RADIAN)
          } L ${x},${y}`}
          stroke="#94a3b8"
          strokeWidth={1}
          fill="none"
        />
        <text
          x={x}
          y={y}
          textAnchor={x > cx ? 'start' : 'end'}
          dominantBaseline="central"
          className="text-sm font-medium fill-gray-700"
        >
          {`${clientType.name} (${(percent * 100).toFixed(1)}%)`}
        </text>
      </g>
    );
  };

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Répartition par Typologie de Clients</h3>
        <p className="mt-1 text-sm text-gray-500">
          Total : {formatCurrency(totalRevenue)}
        </p>
      </div>

      <div className="relative h-[500px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <defs>
              {clientTypes?.map((clientType, index) => {
                const [startColor, endColor] = getTypeColors(clientType.name);
                return (
                  <linearGradient
                    key={`gradient-${index}`}
                    id={`gradient-${index}`}
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1"
                  >
                    <stop offset="0%" stopColor={startColor} stopOpacity={0.8} />
                    <stop offset="100%" stopColor={endColor} stopOpacity={0.9} />
                  </linearGradient>
                );
              })}
            </defs>

            <Pie
              data={clientTypes}
              cx="50%"
              cy="50%"
              innerRadius="60%"
              outerRadius="80%"
              paddingAngle={2}
              dataKey="revenue"
              labelLine={false}
              label={renderCustomizedLabel}
              onMouseEnter={(_, index) => setActiveIndex(index)}
              onMouseLeave={() => setActiveIndex(null)}
            >
              {clientTypes?.map((_, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={`url(#gradient-${index})`}
                  stroke="white"
                  strokeWidth={2}
                  style={{
                    filter: activeIndex === index ? 'url(#shadow)' : 'none',
                    transform: activeIndex === index ? 'scale(1.05)' : 'scale(1)',
                    transformOrigin: 'center',
                    transition: 'all 0.3s ease-in-out'
                  }}
                />
              ))}
            </Pie>
            <defs>
              <filter id="shadow">
                <feDropShadow dx="0" dy="0" stdDeviation="3" floodOpacity="0.3" />
              </filter>
            </defs>
          </PieChart>
        </ResponsiveContainer>

        <AnimatePresence>
          {activeIndex !== null && clientTypes && (
            <ClientTypeTooltip
              clientType={clientTypes[activeIndex]}
              totalRevenue={totalRevenue}
            />
          )}
        </AnimatePresence>
      </div>

      <ClientTypeLegend
        clientTypes={clientTypes || []}
        activeIndex={activeIndex}
        onHover={setActiveIndex}
      />
    </Card>
  );
}