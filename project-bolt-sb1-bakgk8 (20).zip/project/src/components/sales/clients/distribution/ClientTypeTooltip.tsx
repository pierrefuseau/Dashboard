import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { ClientType } from './types';
import { getClientTypeIcon } from './utils/icons';

interface ClientTypeTooltipProps {
  clientType: ClientType;
  totalRevenue: number;
}

export function ClientTypeTooltip({ clientType, totalRevenue }: ClientTypeTooltipProps) {
  const Icon = getClientTypeIcon(clientType.name);
  const percentage = (clientType.revenue / totalRevenue) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="absolute inset-0 flex items-center justify-center pointer-events-none"
    >
      <div className="bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-blue-100">
        <div className="flex items-center space-x-3 mb-3">
          <div className="p-2 rounded-full bg-blue-50">
            <Icon className="w-6 h-6 text-blue-600" />
          </div>
          <h4 className="text-lg font-semibold text-gray-900">{clientType.name}</h4>
        </div>
        <p className="text-2xl font-bold text-blue-600">
          {formatCurrency(clientType.revenue)}
        </p>
        <p className="text-sm text-gray-600 mt-1">
          {percentage.toFixed(1)}% du CA total
        </p>
      </div>
    </motion.div>
  );
}