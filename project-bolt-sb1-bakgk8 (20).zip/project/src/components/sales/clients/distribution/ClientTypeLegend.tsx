import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { ClientType } from './types';
import { getClientTypeIcon } from './utils/icons';

interface ClientTypeLegendProps {
  clientTypes: ClientType[];
  activeIndex: number | null;
  onHover: (index: number | null) => void;
}

export function ClientTypeLegend({ clientTypes, activeIndex, onHover }: ClientTypeLegendProps) {
  return (
    <div className="mt-8 grid grid-cols-2 lg:grid-cols-3 gap-4">
      {clientTypes.map((clientType, index) => {
        const Icon = getClientTypeIcon(clientType.name);
        
        return (
          <motion.div
            key={clientType.name}
            className={`p-4 rounded-lg transition-colors cursor-pointer ${
              activeIndex === index ? 'bg-blue-50' : 'hover:bg-blue-50/50'
            }`}
            onMouseEnter={() => onHover(index)}
            onMouseLeave={() => onHover(null)}
            whileHover={{ scale: 1.02 }}
          >
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-full bg-blue-50">
                <Icon className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {clientType.name}
                </p>
                <p className="text-sm text-blue-600">
                  {formatCurrency(clientType.revenue)}
                </p>
                <div className="mt-2 w-full bg-blue-100 rounded-full h-1.5">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-blue-500 to-blue-600"
                    style={{ width: `${clientType.percentage}%` }}
                  />
                </div>
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}