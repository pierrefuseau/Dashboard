import React from 'react';
import { Card } from '../../common/Card';

export function SalesMap() {
  return (
    <Card>
      <div className="mb-4">
        <h3 className="text-lg font-medium text-gray-900">Points de vente</h3>
        <p className="mt-1 text-sm text-gray-500">
          Visualisation géographique de notre réseau commercial
        </p>
      </div>
      
      <div className="relative w-full h-[600px] rounded-lg overflow-hidden bg-gray-100">
        <iframe
          src="https://www.google.com/maps/d/embed?mid=1ridSZQxLZhh0R4ypSmu3b7_XD7cDg6Y&hl=fr"
          width="100%"
          height="100%"
          className="absolute inset-0 border-0 rounded-lg"
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Points de vente"
        />
      </div>

      <div className="mt-4 text-sm text-gray-500">
        <p>Cette carte affiche l'ensemble de nos points de vente et leur couverture géographique.</p>
      </div>
    </Card>
  );
}