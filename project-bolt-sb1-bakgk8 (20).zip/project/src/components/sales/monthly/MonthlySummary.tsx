import React from 'react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { Card } from '../../common/Card';
import { LoadingSpinner } from '../../common/LoadingSpinner';
import { MonthlyMetrics } from './components/MonthlyMetrics';
import { TopClientsTable } from './components/TopClientsTable';
import { TopProductsTable } from './components/TopProductsTable';
import { TopSalesTable } from './components/TopSalesTable';
import { formatMillionsEuros } from '../../../utils/formatters/currency';

export function MonthlySummary() {
  // Récupération des métriques mensuelles (C41:D43)
  const { data: monthlyMetrics, isLoading: metricsLoading } = useSheetData('VENTES', 'C41:D43', {
    transform: (data) => ({
      current: {
        revenue: Number(data?.[0]?.[0]?.toString().replace(/[^0-9.-]/g, '')) || 0,
        marginPercent: Number(data?.[1]?.[0]?.toString().replace(/[^0-9.-]/g, '')) || 0,
        marginValue: Number(data?.[2]?.[0]?.toString().replace(/[^0-9.-]/g, '')) || 0
      },
      previous: {
        revenue: Number(data?.[0]?.[1]?.toString().replace(/[^0-9.-]/g, '')) || 0,
        marginPercent: Number(data?.[1]?.[1]?.toString().replace(/[^0-9.-]/g, '')) || 0,
        marginValue: Number(data?.[2]?.[1]?.toString().replace(/[^0-9.-]/g, '')) || 0
      }
    })
  });

  // Récupération du top 5 clients (B46:D48)
  const { data: topClients, isLoading: clientsLoading } = useSheetData('VENTES', 'B46:D48', {
    transform: (data) => data.map(row => ({
      name: row[0]?.toString() || '',
      revenue: Number(row[1]?.toString().replace(/[^0-9.-]/g, '')) || 0,
      margin: Number(row[2]?.toString().replace(/[^0-9.-]/g, '')) || 0
    }))
  });

  // Récupération du top 5 produits (B51:E53)
  const { data: topProducts, isLoading: productsLoading } = useSheetData('VENTES', 'B51:E53', {
    transform: (data) => data.map(row => ({
      name: row[0]?.toString() || '',
      revenue: Number(row[1]?.toString().replace(/[^0-9.-]/g, '')) || 0,
      quantity: Number(row[2]?.toString().replace(/[^0-9.-]/g, '')) || 0,
      tonnage: Number(row[3]?.toString().replace(/[^0-9.-]/g, '')) / 1000 || 0 // Conversion en tonnes
    }))
  });

  // Récupération du top 3 commerciaux (B56:D58)
  const { data: topSales, isLoading: salesLoading } = useSheetData('VENTES', 'B56:D58', {
    transform: (data) => data.map(row => ({
      name: row[0]?.toString() || '',
      revenue: Number(row[1]?.toString().replace(/[^0-9.-]/g, '')) || 0,
      margin: Number(row[2]?.toString().replace(/[^0-9.-]/g, '')) || 0
    }))
  });

  if (metricsLoading || clientsLoading || productsLoading || salesLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Métriques mensuelles avec comparaison N/N-1 */}
      {monthlyMetrics && (
        <MonthlyMetrics 
          current={monthlyMetrics.current}
          previous={monthlyMetrics.previous}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top 5 clients */}
        <Card>
          <TopClientsTable clients={topClients || []} />
        </Card>

        {/* Top 5 produits */}
        <Card>
          <TopProductsTable products={topProducts || []} />
        </Card>
      </div>

      {/* Top 3 commerciaux */}
      <Card>
        <TopSalesTable sales={topSales || []} />
      </Card>
    </div>
  );
}