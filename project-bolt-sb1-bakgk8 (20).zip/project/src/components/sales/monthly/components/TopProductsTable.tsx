import React from 'react';
import { Package, Award } from 'lucide-react';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface TopProduct {
  name: string;
  revenue: number;
  quantity: number;
  tonnage: number;
}

interface TopProductsTableProps {
  products: TopProduct[];
}

export function TopProductsTable({ products }: TopProductsTableProps) {
  return (
    <div className="p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Package className="w-5 h-5 text-blue-600" />
        <h3 className="text-lg font-medium text-gray-900">Top 5 Produits du mois</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                CA
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Quantité
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Tonnage
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {products.map((product, index) => (
              <tr 
                key={product.name}
                className={`hover:bg-blue-50 transition-colors ${
                  index === 0 ? 'bg-blue-50' : ''
                }`}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className={`
                      flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                      ${index === 0 ? 'bg-blue-100' : 'bg-gray-100'}
                    `}>
                      {index === 0 ? (
                        <Award className="h-5 w-5 text-blue-600" />
                      ) : (
                        <Package className="h-5 w-5 text-gray-400" />
                      )}
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">
                        {product.name}
                      </div>
                      {index === 0 && (
                        <div className="text-xs text-blue-600">
                          Meilleure vente
                        </div>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-900">
                  {formatCurrency(product.revenue)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-900">
                  {product.quantity.toLocaleString('fr-FR')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-900">
                  {product.tonnage.toFixed(3)} T
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}