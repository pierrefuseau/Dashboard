import React from 'react';
import { Euro, TrendingUp, Wallet } from 'lucide-react';
import { Card } from '../../../common/Card';
import { formatMillionsEuros } from '../../../../utils/formatters/currency';

interface MonthlyMetricsProps {
  current: {
    revenue: number;
    marginPercent: number;
    marginValue: number;
  };
  previous: {
    revenue: number;
    marginPercent: number;
    marginValue: number;
  };
}

export function MonthlyMetrics({ current, previous }: MonthlyMetricsProps) {
  const calculateVariation = (current: number, previous: number) => {
    if (!previous) return 0;
    return ((current - previous) / previous) * 100;
  };

  // Ne garder que les métriques avec des valeurs > 0
  const metrics = [
    {
      title: "CA du mois",
      current: current.revenue,
      previous: previous.revenue,
      format: "currency",
      icon: Euro
    },
    {
      title: "Marge brute",
      current: current.marginPercent,
      previous: previous.marginPercent,
      format: "percentage",
      icon: TrendingUp
    },
    {
      title: "Marge en valeur",
      current: current.marginValue,
      previous: previous.marginValue,
      format: "currency",
      icon: Wallet
    }
  ].filter(metric => metric.current > 0 || metric.previous > 0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {metrics.map((metric) => {
        const variation = calculateVariation(metric.current, metric.previous);
        const isPositive = variation > 0;
        
        return (
          <Card key={metric.title}>
            <div className="flex items-center justify-between p-6">
              <div>
                <p className="text-sm font-medium text-gray-500">{metric.title}</p>
                <p className="mt-2 text-2xl font-semibold text-gray-900">
                  {metric.format === "currency" 
                    ? formatMillionsEuros(metric.current)
                    : `${(metric.current).toFixed(2)}%`
                  }
                </p>
                <div className="mt-2 flex items-center">
                  <span className={`text-sm font-medium ${
                    isPositive ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {isPositive ? '+' : ''}{variation.toFixed(1)}%
                  </span>
                  <span className="mx-2 text-gray-500">vs</span>
                  <span className="text-sm text-gray-500">
                    {metric.format === "currency"
                      ? formatMillionsEuros(metric.previous)
                      : `${(metric.previous).toFixed(2)}%`
                    }
                  </span>
                </div>
              </div>
              <div className="p-3 bg-blue-50 rounded-full">
                <metric.icon className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}