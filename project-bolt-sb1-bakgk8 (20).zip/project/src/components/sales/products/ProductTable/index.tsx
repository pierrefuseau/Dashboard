import React, { useState } from 'react';
import { Card } from '../../../common/Card';
import { ProductList } from './ProductList';
import { ProductHeader } from './ProductHeader';
import { ProductFilters } from './ProductFilters';
import { ProductDetails } from './ProductDetails';
import { ProductComparison } from './ProductComparison';
import { useProducts } from './hooks/useProducts';
import { Product } from './types';

export function ProductTable() {
  const [selectedProducts, setSelectedProducts] = useState<Product[]>([]);
  const [showDetails, setShowDetails] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  const { products, isLoading, filters, setFilters } = useProducts();

  const handleProductSelect = (product: Product) => {
    setSelectedProducts(prev => 
      prev.find(p => p.code === product.code)
        ? prev.filter(p => p.code !== product.code)
        : [...prev, product]
    );
  };

  return (
    <Card>
      <ProductHeader 
        totalProducts={products?.length || 0}
        selectedCount={selectedProducts.length}
        onCompare={() => setShowComparison(true)}
      />

      <ProductFilters 
        filters={filters}
        onChange={setFilters}
      />

      <ProductList
        products={products || []}
        selectedProducts={selectedProducts}
        onSelect={handleProductSelect}
        onShowDetails={() => setShowDetails(true)}
        isLoading={isLoading}
      />

      {showDetails && selectedProducts.length === 1 && (
        <ProductDetails
          product={selectedProducts[0]}
          onClose={() => {
            setShowDetails(false);
            setSelectedProducts([]);
          }}
        />
      )}

      {showComparison && selectedProducts.length > 1 && (
        <ProductComparison
          products={selectedProducts}
          onClose={() => {
            setShowComparison(false);
            setSelectedProducts([]);
          }}
        />
      )}
    </Card>
  );
}