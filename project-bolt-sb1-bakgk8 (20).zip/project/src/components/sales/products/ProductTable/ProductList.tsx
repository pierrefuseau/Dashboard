import React from 'react';
import { Award, Package, TrendingUp, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';
import { Product } from './types';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { cn } from '../../../../utils/cn';

interface ProductListProps {
  products: Product[];
  selectedProducts: Product[];
  onSelect: (product: Product) => void;
  onShowDetails: () => void;
  isLoading: boolean;
}

export function ProductList({
  products,
  selectedProducts,
  onSelect,
  onShowDetails,
  isLoading
}: ProductListProps) {
  if (isLoading) {
    return <ProductListSkeleton />;
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="w-12 px-4 py-3"></th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
              Rang
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
              Produit
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
              CA
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
              Volume
            </th>
            <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">
              % du Total
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {products.map((product, index) => (
            <motion.tr
              key={product.code}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              onClick={() => onSelect(product)}
              className={cn(
                "hover:bg-blue-50 cursor-pointer transition-colors",
                selectedProducts.includes(product) && "bg-blue-50",
                index < 3 && "bg-blue-50/50"
              )}
            >
              <td className="px-4 py-4">
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center",
                  index === 0 ? "bg-blue-100" : "bg-gray-100"
                )}>
                  {index === 0 ? (
                    <Award className="w-4 h-4 text-blue-600" />
                  ) : (
                    <Package className="w-4 h-4 text-gray-400" />
                  )}
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {product.rank}
              </td>
              <td className="px-6 py-4">
                <div>
                  <div className="text-sm font-medium text-gray-900">
                    {product.name}
                  </div>
                  <div className="text-sm text-gray-500">
                    {product.code}
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="text-right space-y-1">
                  <div className="text-sm font-medium text-gray-900">
                    {formatCurrency(product.revenue)}
                  </div>
                  <div className="flex items-center justify-end space-x-1">
                    {product.trend.revenue > 0 ? (
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500" />
                    )}
                    <span className={cn(
                      "text-xs font-medium",
                      product.trend.revenue > 0 ? "text-green-600" : "text-red-600"
                    )}>
                      {product.trend.revenue > 0 ? '+' : ''}{product.trend.revenue}%
                    </span>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="text-right space-y-1">
                  <div className="text-sm font-medium text-gray-900">
                    {product.volume.toLocaleString('fr-FR')} kg
                  </div>
                  <div className="flex items-center justify-end space-x-1">
                    {product.trend.volume > 0 ? (
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500" />
                    )}
                    <span className={cn(
                      "text-xs font-medium",
                      product.trend.volume > 0 ? "text-green-600" : "text-red-600"
                    )}>
                      {product.trend.volume > 0 ? '+' : ''}{product.trend.volume}%
                    </span>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="flex flex-col items-center space-y-2">
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${product.percentage.revenue}%` }}
                      className="bg-blue-600 h-1.5 rounded-full"
                      transition={{ duration: 1, delay: index * 0.1 }}
                    />
                  </div>
                  <span className="text-sm text-gray-500">
                    {product.percentage.revenue.toFixed(1)}%
                  </span>
                </div>
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ProductListSkeleton() {
  return (
    <div className="space-y-4">
      {[...Array(5)].map((_, i) => (
        <div key={i} className="h-20 bg-gray-100 animate-pulse rounded-lg" />
      ))}
    </div>
  );
}