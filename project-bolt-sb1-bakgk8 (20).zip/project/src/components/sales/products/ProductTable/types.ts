export interface Product {
  code: string;
  name: string;
  revenue: number;
  volume: number;
  rank: number;
  trend: {
    revenue: number;
    volume: number;
  };
  percentage: {
    revenue: number;
    volume: number;
  };
  category: string;
  isTopSeller?: boolean;
  isTopVolume?: boolean;
}

export interface ProductFilters {
  search: string;
  category?: string;
  minRevenue?: number;
  minVolume?: number;
  sortBy: 'revenue' | 'volume' | 'rank';
  sortOrder: 'asc' | 'desc';
}