import React, { useState } from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { ChartModal } from '../../common/ChartModal';
import { Maximize2 } from 'lucide-react';

export function TopProductsCharts() {
  const [modalConfig, setModalConfig] = useState<{
    isOpen: boolean;
    type: 'revenue' | 'volume';
    title: string;
  }>({
    isOpen: false,
    type: 'revenue',
    title: ''
  });

  const { data: revenueProducts, isLoading: revenueLoading } = useSheetData('VENTES', 'B31:C35', {
    transform: (data) => data
      .map(row => ({
        name: row[0] || '',
        revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
      }))
      .filter(product => product.name && product.revenue > 0) // Filtrer les produits sans revenus
  });

  const { data: volumeProducts, isLoading: volumeLoading } = useSheetData('VENTES', 'E31:F35', {
    transform: (data) => data
      .map(row => ({
        name: row[0] || '',
        volume: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 1000 || 0
      }))
      .filter(product => product.name && product.volume > 0) // Filtrer les produits sans volume
  });

  if (revenueLoading || volumeLoading) {
    return <div>Chargement des données...</div>;
  }

  const formatEuro = (value: number) => 
    new Intl.NumberFormat('fr-FR', { 
      style: 'currency', 
      currency: 'EUR',
      maximumFractionDigits: 0
    }).format(value);

  const formatVolume = (value: number) => 
    `${value.toFixed(2)} T`;

  const renderChart = (type: 'revenue' | 'volume', height: number = 400) => {
    const data = type === 'revenue' ? revenueProducts : volumeProducts;
    const dataKey = type === 'revenue' ? 'revenue' : 'volume';
    const formatter = type === 'revenue' ? formatEuro : formatVolume;
    const color = type === 'revenue' ? '#3B82F6' : '#60a5fa';

    return (
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={data} margin={{ top: 20, right: 30, left: 60, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
          <XAxis
            dataKey="name"
            tick={{ fontSize: 12, fill: '#4B5563' }}
            angle={-45}
            textAnchor="end"
            interval={0}
            height={80}
          />
          <YAxis
            tickFormatter={formatter}
            tick={{ fontSize: 12, fill: '#4B5563' }}
            width={80}
          />
          <Tooltip
            formatter={(value: number) => [formatter(value), type === 'revenue' ? "Chiffre d'affaires" : 'Volume']}
            contentStyle={{
              backgroundColor: 'rgba(255, 255, 255, 0.95)',
              border: 'none',
              borderRadius: '8px',
              padding: '12px',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
            }}
          />
          <Bar
            dataKey={dataKey}
            fill={color}
            radius={[4, 4, 0, 0]}
            barSize={40}
          />
        </BarChart>
      </ResponsiveContainer>
    );
  };

  return (
    <div className="grid grid-cols-1 gap-6">
      <Card>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-900">Top Produits - Chiffre d'affaires</h3>
          <button
            onClick={() => setModalConfig({ isOpen: true, type: 'revenue', title: "Top Produits - Chiffre d'affaires" })}
            className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
          >
            <Maximize2 className="h-5 w-5" />
          </button>
        </div>
        <div className="h-[400px]">
          {renderChart('revenue')}
        </div>
      </Card>

      <Card>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-900">Top Produits - Volume</h3>
          <button
            onClick={() => setModalConfig({ isOpen: true, type: 'volume', title: "Top Produits - Volume" })}
            className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
          >
            <Maximize2 className="h-5 w-5" />
          </button>
        </div>
        <div className="h-[400px]">
          {renderChart('volume')}
        </div>
      </Card>

      <ChartModal
        isOpen={modalConfig.isOpen}
        onClose={() => setModalConfig({ ...modalConfig, isOpen: false })}
        title={modalConfig.title}
      >
        {renderChart(modalConfig.type, 600)}
      </ChartModal>
    </div>
  );
}