import React from 'react';
import { Package, TrendingUp, Scale } from 'lucide-react';

interface ProductMetrics {
  name: string;
  revenue: number;
  volume: number;
  rank: number;
}

export function ProductPerformanceCards({ products }: { products: ProductMetrics[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product) => (
        <div 
          key={product.name}
          className={`
            relative p-6 bg-white rounded-xl shadow-sm border border-gray-100
            transition-all duration-200 hover:shadow-md
            ${product.rank === 1 ? 'ring-2 ring-blue-500' : ''}
          `}
        >
          {product.rank === 1 && (
            <div className="absolute -top-3 -right-3 bg-blue-500 text-white p-2 rounded-full">
              <TrendingUp className="w-4 h-4" />
            </div>
          )}

          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h3 className="font-medium text-gray-900 line-clamp-2">
                {product.name}
              </h3>
              {product.rank === 1 && (
                <span className="text-xs text-blue-600">Meilleure performance</span>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-sm text-gray-500 mb-1">
                <span>Chiffre d'affaires</span>
                <span className="font-medium text-gray-900">
                  {new Intl.NumberFormat('fr-FR', {
                    style: 'currency',
                    currency: 'EUR',
                    maximumFractionDigits: 0
                  }).format(product.revenue)}
                </span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-1.5">
                <div 
                  className="bg-blue-500 h-1.5 rounded-full"
                  style={{ width: `${(product.revenue / products[0].revenue) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-sm text-gray-500 mb-1">
                <span>Volume</span>
                <span className="font-medium text-gray-900">
                  {product.volume.toLocaleString('fr-FR')} T
                </span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-1.5">
                <div 
                  className="bg-green-500 h-1.5 rounded-full"
                  style={{ width: `${(product.volume / products[0].volume) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}