import React from 'react';
import { Package, TrendingUp, ArrowRight } from 'lucide-react';

interface ProductData {
  name: string;
  revenue: number;
  volume: number;
}

export function HierarchicalProductTable({ products }: { products: ProductData[] }) {
  const maxRevenue = Math.max(...products.map(p => p.revenue));
  const maxVolume = Math.max(...products.map(p => p.volume));

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">Performance des Produits</h2>
      </div>

      <div className="divide-y divide-gray-200">
        {products.map((product, index) => {
          const revenuePercentage = (product.revenue / maxRevenue) * 100;
          const volumePercentage = (product.volume / maxVolume) * 100;
          
          return (
            <div 
              key={product.name}
              className={`
                relative p-6 transition-colors duration-200
                ${index === 0 ? 'bg-blue-50' : 'hover:bg-gray-50'}
              `}
            >
              <div className="flex items-center mb-4">
                <div className={`
                  flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center
                  ${index === 0 ? 'bg-blue-100' : 'bg-gray-100'}
                `}>
                  {index === 0 ? (
                    <TrendingUp className="w-5 h-5 text-blue-600" />
                  ) : (
                    <Package className="w-5 h-5 text-gray-500" />
                  )}
                </div>
                
                <div className="ml-4 flex-1">
                  <h3 className="text-sm font-medium text-gray-900">
                    {product.name}
                  </h3>
                  {index === 0 && (
                    <span className="text-xs text-blue-600">Leader des ventes</span>
                  )}
                </div>

                <ArrowRight className="w-5 h-5 text-gray-400" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-500">CA</span>
                    <span className="font-medium text-gray-900">
                      {new Intl.NumberFormat('fr-FR', {
                        style: 'currency',
                        currency: 'EUR',
                        maximumFractionDigits: 0
                      }).format(product.revenue)}
                    </span>
                  </div>
                  <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div 
                      className="absolute inset-y-0 left-0 bg-blue-500 rounded-full transition-all duration-500"
                      style={{ width: `${revenuePercentage}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-500">Volume</span>
                    <span className="font-medium text-gray-900">
                      {product.volume.toLocaleString('fr-FR')} T
                    </span>
                  </div>
                  <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div 
                      className="absolute inset-y-0 left-0 bg-green-500 rounded-full transition-all duration-500"
                      style={{ width: `${volumePercentage}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}