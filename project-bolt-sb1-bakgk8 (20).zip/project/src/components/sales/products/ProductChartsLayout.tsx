import React, { useState } from 'react';
import { ChartContainer } from '../../common/ChartContainer';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { ChartModal } from '../../common/ChartModal';

export function ProductChartsLayout() {
  const [modalConfig, setModalConfig] = useState<{
    isOpen: boolean;
    type: 'revenue' | 'volume';
    title: string;
  }>({
    isOpen: false,
    type: 'revenue',
    title: ''
  });

  const { data: revenueData } = useSheetData('VENTES', 'B31:C35', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      value: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
    }))
  });

  const { data: volumeData } = useSheetData('VENTES', 'E31:F35', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      volume: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 1000 || 0 // Convert to tonnes
    }))
  });

  const formatEuro = (value: number) => 
    new Intl.NumberFormat('fr-FR', { 
      style: 'currency', 
      currency: 'EUR',
      maximumFractionDigits: 0
    }).format(value);

  const formatVolume = (value: number) => 
    `${value.toFixed(2)} T`;

  const renderRevenueChart = (height: number = 400) => (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={revenueData} margin={{ top: 20, right: 30, left: 60, bottom: 60 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
        <XAxis
          dataKey="name"
          tick={{ fontSize: 12, fill: '#4B5563' }}
          angle={-45}
          textAnchor="end"
          interval={0}
          height={80}
        />
        <YAxis
          tickFormatter={formatEuro}
          tick={{ fontSize: 12, fill: '#4B5563' }}
          width={80}
        />
        <Tooltip
          formatter={(value: number) => [formatEuro(value), "Chiffre d'affaires"]}
          contentStyle={{
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            border: 'none',
            borderRadius: '8px',
            padding: '12px',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
          }}
        />
        <Bar
          dataKey="value"
          fill="#3b82f6"
          radius={[4, 4, 0, 0]}
          barSize={40}
        />
      </BarChart>
    </ResponsiveContainer>
  );

  const renderVolumeChart = (height: number = 400) => (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={volumeData} margin={{ top: 20, right: 30, left: 40, bottom: 60 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
        <XAxis
          dataKey="name"
          tick={{ fontSize: 12, fill: '#4B5563' }}
          angle={-45}
          textAnchor="end"
          interval={0}
          height={80}
        />
        <YAxis
          tickFormatter={formatVolume}
          tick={{ fontSize: 12, fill: '#4B5563' }}
          width={80}
        />
        <Tooltip
          formatter={(value: number) => [formatVolume(value), 'Volume']}
          contentStyle={{
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            border: 'none',
            borderRadius: '8px',
            padding: '12px',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
          }}
        />
        <Bar
          dataKey="volume"
          fill="#60a5fa"
          radius={[4, 4, 0, 0]}
          barSize={40}
        />
      </BarChart>
    </ResponsiveContainer>
  );

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartContainer
          title="Top Produits - Chiffre d'affaires"
          height={400}
          onExpand={() => setModalConfig({
            isOpen: true,
            type: 'revenue',
            title: "Top Produits - Chiffre d'affaires"
          })}
        >
          {renderRevenueChart()}
        </ChartContainer>

        <ChartContainer
          title="Top Produits - Volume"
          height={400}
          onExpand={() => setModalConfig({
            isOpen: true,
            type: 'volume',
            title: "Top Produits - Volume"
          })}
        >
          {renderVolumeChart()}
        </ChartContainer>
      </div>

      <ChartModal
        isOpen={modalConfig.isOpen}
        onClose={() => setModalConfig({ ...modalConfig, isOpen: false })}
        title={modalConfig.title}
      >
        {modalConfig.type === 'revenue' ? renderRevenueChart(600) : renderVolumeChart(600)}
      </ChartModal>
    </>
  );
}