import React from 'react';
import { TrendingUp, TrendingDown, Package, ArrowRight } from 'lucide-react';

interface ProductMetrics {
  name: string;
  revenue: number;
  volume: number;
  previousRevenue?: number;
  previousVolume?: number;
}

export function ComparativeProductGrid({ products }: { products: ProductMetrics[] }) {
  const getGrowthIndicator = (current: number, previous?: number) => {
    if (!previous) return null;
    const growth = ((current - previous) / previous) * 100;
    
    if (growth > 0) {
      return (
        <div className="flex items-center text-green-600">
          <TrendingUp className="w-4 h-4 mr-1" />
          <span className="text-xs font-medium">+{growth.toFixed(1)}%</span>
        </div>
      );
    }
    
    return (
      <div className="flex items-center text-red-600">
        <TrendingDown className="w-4 h-4 mr-1" />
        <span className="text-xs font-medium">{growth.toFixed(1)}%</span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Graphique CA */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Chiffre d'affaires
          </h3>
          <div className="space-y-4">
            {products.map((product, index) => (
              <div key={`revenue-${product.name}`} className="relative">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600 truncate">
                    {product.name}
                  </span>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-900">
                      {new Intl.NumberFormat('fr-FR', {
                        style: 'currency',
                        currency: 'EUR',
                        maximumFractionDigits: 0
                      }).format(product.revenue)}
                    </span>
                    {getGrowthIndicator(product.revenue, product.previousRevenue)}
                  </div>
                </div>
                <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div 
                    className="absolute inset-y-0 left-0 bg-blue-500 rounded-full transition-all duration-500"
                    style={{ 
                      width: `${(product.revenue / products[0].revenue) * 100}%`,
                      opacity: 1 - (index * 0.2)
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Graphique Volume */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Volume
          </h3>
          <div className="space-y-4">
            {products.map((product, index) => (
              <div key={`volume-${product.name}`} className="relative">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600 truncate">
                    {product.name}
                  </span>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-900">
                      {product.volume.toLocaleString('fr-FR')} T
                    </span>
                    {getGrowthIndicator(product.volume, product.previousVolume)}
                  </div>
                </div>
                <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div 
                    className="absolute inset-y-0 left-0 bg-green-500 rounded-full transition-all duration-500"
                    style={{ 
                      width: `${(product.volume / products[0].volume) * 100}%`,
                      opacity: 1 - (index * 0.2)
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}