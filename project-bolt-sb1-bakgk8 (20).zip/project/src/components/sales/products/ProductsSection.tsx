import React from 'react';
import { TopProductsTable } from './TopProductsTable';
import { TopProductsVolumeTable } from './TopProductsVolumeTable';

export function ProductsSection() {
  return (
    <div className="space-y-6">
      <TopProductsTable />
      <TopProductsVolumeTable />
    </div>
  );
}