import React from 'react';
import { Card } from '../../common/Card';
import { Package, TrendingUp, Scale } from 'lucide-react';
import { numberFormatters } from '../../../utils/formatters/numbers';

interface ProductData {
  name: string;
  revenue: number;
  volume: number;
}

export function ProductPerformanceView({ products }: { products: ProductData[] }) {
  const maxRevenue = Math.max(...products.map(p => p.revenue));
  const maxVolume = Math.max(...products.map(p => p.volume));

  return (
    <div className="space-y-6">
      {products.map((product, index) => (
        <Card key={product.name} className={index === 0 ? 'border-blue-200 bg-blue-50' : ''}>
          <div className="flex items-start space-x-4">
            <div className={`
              flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center
              ${index === 0 ? 'bg-blue-100' : 'bg-gray-100'}
            `}>
              {index === 0 ? (
                <TrendingUp className="w-6 h-6 text-blue-600" />
              ) : (
                <Package className="w-6 h-6 text-gray-600" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-medium text-gray-900 truncate">
                    {product.name}
                  </h3>
                  {index === 0 && (
                    <span className="text-xs text-blue-600">Meilleure performance</span>
                  )}
                </div>
                <div className="text-sm text-gray-500">
                  #{index + 1}
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-4">
                {/* CA */}
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-500">CA</span>
                    <span className="font-medium text-gray-900">
                      {numberFormatters.euros(product.revenue)}
                    </span>
                  </div>
                  <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div 
                      className="absolute inset-y-0 left-0 bg-blue-500 rounded-full transition-all duration-500"
                      style={{ width: `${(product.revenue / maxRevenue) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Volume */}
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-500">Volume</span>
                    <span className="font-medium text-gray-900">
                      {numberFormatters.tonnes(product.volume)}
                    </span>
                  </div>
                  <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div 
                      className="absolute inset-y-0 left-0 bg-green-500 rounded-full transition-all duration-500"
                      style={{ width: `${(product.volume / maxVolume) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}