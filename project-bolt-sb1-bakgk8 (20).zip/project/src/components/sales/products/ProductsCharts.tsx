import React from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface Product {
  name: string;
  value: number;
  volume: number;
}

const mockProducts: Product[] = [
  { name: 'Produit A', value: 450000, volume: 1200 },
  { name: 'Produit B', value: 380000, volume: 950 },
  { name: 'Produit C', value: 320000, volume: 800 },
  { name: 'Produit D', value: 290000, volume: 720 },
  { name: 'Produit E', value: 250000, volume: 650 },
  { name: 'Produit F', value: 220000, volume: 580 },
  { name: 'Produit G', value: 190000, volume: 520 },
  { name: 'Produit H', value: 170000, volume: 480 },
  { name: 'Produit I', value: 150000, volume: 420 },
  { name: 'Produit J', value: 130000, volume: 380 },
];

export function ProductsCharts() {
  const formatEuro = (value: number) => 
    new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(value);

  const formatVolume = (value: number) => 
    `${value.toLocaleString('fr-FR')} T`;

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card title="Top 10 Produits en Valeur">
        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={mockProducts}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis tickFormatter={formatEuro} />
              <Tooltip 
                formatter={(value: number) => [formatEuro(value), 'Valeur']}
                labelStyle={{ color: '#374151' }}
              />
              <Bar dataKey="value" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card title="Top 10 Produits en Volume">
        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={mockProducts}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis tickFormatter={formatVolume} />
              <Tooltip 
                formatter={(value: number) => [formatVolume(value), 'Volume']}
                labelStyle={{ color: '#374151' }}
              />
              <Bar dataKey="volume" fill="#60a5fa" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}