import React from 'react';
import { Card } from '../../common/Card';
import { Package, Award } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { formatCurrency } from '../../../utils/formatters/currency';

export function TopFamiliesTable() {
  // Récupérer les données des familles
  const { data: families, isLoading: familiesLoading } = useSheetData('VENTES', 'E4:F8', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
    }))
  });

  // Récupérer le CA total de l'entreprise
  const { data: totalRevenue, isLoading: totalLoading } = useSheetData('VENTES', 'C3', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
    }
  });

  if (familiesLoading || totalLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Top Familles</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Famille
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                CA
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                % du CA Total
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {families?.map((family, index) => {
              const percentage = totalRevenue ? (family.revenue / totalRevenue) * 100 : 0;
              const isTopPerformer = index === 0;
              
              return (
                <tr 
                  key={family.name}
                  className={`
                    hover:bg-blue-50 transition-colors duration-150
                    ${isTopPerformer ? 'bg-blue-50' : ''}
                  `}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`
                        flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                        ${isTopPerformer ? 'bg-blue-100' : 'bg-gray-100'}
                      `}>
                        {isTopPerformer ? (
                          <Award className="h-5 w-5 text-blue-600" />
                        ) : (
                          <Package className="h-5 w-5 text-gray-400" />
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {family.name}
                        </div>
                        {isTopPerformer && (
                          <div className="text-xs text-blue-600">
                            Meilleure famille
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(family.revenue)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-grow">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">
                        {percentage.toFixed(1)}%
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}