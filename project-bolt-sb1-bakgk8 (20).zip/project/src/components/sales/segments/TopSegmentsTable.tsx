import React from 'react';
import { Card } from '../../common/Card';
import { Package, Award } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { formatCurrency } from '../../../utils/formatters/currency';

export function TopSegmentsTable() {
  // Récupérer les données des professions
  const { data: segments, isLoading: segmentsLoading } = useSheetData('VENTES', 'B22:C26', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
    }))
  });

  // Récupérer le CA total de l'entreprise
  const { data: totalRevenue, isLoading: totalLoading } = useSheetData('VENTES', 'C3', {
    transform: (data) => {
      if (!data?.[0]?.[0]) return 0;
      return Number(data[0][0].toString().replace(/[^0-9.-]/g, '')) || 0;
    }
  });

  if (segmentsLoading || totalLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Répartition par Profession</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Profession
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                CA
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                % du CA Total
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {segments?.map((segment, index) => {
              const percentage = totalRevenue ? (segment.revenue / totalRevenue) * 100 : 0;
              const isTopPerformer = index === 0;
              
              return (
                <tr 
                  key={segment.name}
                  className={`
                    hover:bg-blue-50 transition-colors duration-150
                    ${isTopPerformer ? 'bg-blue-50' : ''}
                  `}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`
                        flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                        ${isTopPerformer ? 'bg-blue-100' : 'bg-gray-100'}
                      `}>
                        {isTopPerformer ? (
                          <Award className="h-5 w-5 text-blue-600" />
                        ) : (
                          <Package className="h-5 w-5 text-gray-400" />
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {segment.name}
                        </div>
                        {isTopPerformer && (
                          <div className="text-xs text-blue-600">
                            Meilleure profession
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(segment.revenue)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-grow">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">
                        {percentage.toFixed(1)}%
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}