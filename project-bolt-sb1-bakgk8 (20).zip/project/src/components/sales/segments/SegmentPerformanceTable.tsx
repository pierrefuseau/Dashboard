import React from 'react';
import { Card } from '../../common/Card';

interface SegmentData {
  name: string;
  revenue: number;
  volume: number;
  margin: number;
}

const segments: SegmentData[] = [
  { name: 'Artisans', revenue: 850000, volume: 2100, margin: 28.5 },
  { name: 'Industriels', revenue: 1200000, volume: 3500, margin: 22.3 },
  { name: 'Export', revenue: 650000, volume: 1800, margin: 31.2 },
  { name: 'GMS', revenue: 1500000, volume: 4200, margin: 18.7 },
  { name: 'Franchisés', revenue: 750000, volume: 1950, margin: 25.4 },
];

export function SegmentPerformanceTable() {
  return (
    <Card title="Performance par Segment">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Segment
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                CA
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Volume
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Marge
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {segments.map((segment) => (
              <tr key={segment.name}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {segment.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(segment.revenue)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {segment.volume.toLocaleString('fr-FR')} T
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {segment.margin.toFixed(1)}%
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}