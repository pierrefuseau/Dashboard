import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Produit A', ventes: 4000 },
  { name: 'Produit B', ventes: 3000 },
  { name: 'Produit C', ventes: 2000 },
  { name: 'Produit D', ventes: 1500 },
  { name: 'Produit E', ventes: 1000 },
];

export function TopProductsChart() {
  return (
    <div className="h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="ventes" fill="#3b82f6" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}