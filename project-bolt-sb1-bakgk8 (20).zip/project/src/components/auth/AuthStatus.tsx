import React from 'react';
import { UserProfile } from './UserProfile';
import { LoginButton } from './LoginButton';
import { RefreshButton } from '../common/RefreshButton';
import { PartnerLogos } from '../common/PartnerLogos';
import { useAuthStore } from '../../store/authStore';

export function AuthStatus() {
  const { user } = useAuthStore();
  
  return (
    <div className="flex items-center space-x-4">
      <PartnerLogos />
      <RefreshButton />
      {user ? <UserProfile /> : <LoginButton />}
    </div>
  );
}