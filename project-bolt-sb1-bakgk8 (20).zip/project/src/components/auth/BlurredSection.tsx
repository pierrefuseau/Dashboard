import React from 'react';
import { useAuth } from '../../hooks/auth/useAuth';
import { cn } from '../../utils/cn';

interface BlurredSectionProps {
  permission: string;
  children: React.ReactNode;
  className?: string;
}

export function BlurredSection({ permission, children, className }: BlurredSectionProps) {
  const { hasPermission } = useAuth();
  const isAuthorized = hasPermission(permission);

  return (
    <div className={cn("relative group", className)}>
      <div className={cn(
        "transition-all duration-200",
        !isAuthorized && "blur-md pointer-events-none select-none"
      )}>
        {children}
      </div>
      
      {!isAuthorized && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-white/90 backdrop-blur-sm px-4 py-2 rounded-lg shadow-lg">
            <p className="text-sm font-medium text-gray-900">
              Accès restreint
            </p>
          </div>
        </div>
      )}
    </div>
  );
}