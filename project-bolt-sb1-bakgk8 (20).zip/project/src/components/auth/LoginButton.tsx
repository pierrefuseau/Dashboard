import React from 'react';
import { LogIn } from 'lucide-react';

export function LoginButton() {
  return (
    <button className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white rounded-lg hover:bg-gray-50 transition-colors border border-gray-200">
      <LogIn className="w-4 h-4" />
      <span>Se connecter</span>
    </button>
  );
}