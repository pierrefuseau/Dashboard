import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredPermission?: string;
}

export function ProtectedRoute({ children, requiredPermission }: ProtectedRouteProps) {
  const { user } = useAuthStore();
  const location = useLocation();

  // Si l'utilisateur n'est pas connecté, rediriger vers la page de connexion
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Si une permission spécifique est requise, vérifier que l'utilisateur la possède
  if (requiredPermission && user.permissions) {
    // Si l'utilisateur est ADMIN, autoriser l'accès à toutes les pages
    if (user.permissions.includes('ADMIN')) {
      return <>{children}</>;
    }
    
    // Sinon, vérifier la permission spécifique
    const hasPermission = user.permissions.includes(requiredPermission);
    if (!hasPermission) {
      return <Navigate to="/403" replace />;
    }
  }

  // Si tout est OK, afficher le contenu protégé
  return <>{children}</>;
}