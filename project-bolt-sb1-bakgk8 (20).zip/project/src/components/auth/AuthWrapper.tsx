import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { GoogleAuth } from './GoogleAuth';
import { UserHeader } from '../user/UserHeader';

interface AuthWrapperProps {
  children: React.ReactNode;
}

export function AuthWrapper({ children }: AuthWrapperProps) {
  const { user } = useAuthStore();

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="max-w-md w-full space-y-8 p-8 bg-white rounded-lg shadow">
          <div className="text-center">
            <img
              src="https://www.fuseau-sas.com/frontend/images/logo-fuseau.png"
              alt="FUSEAU"
              className="h-12 mx-auto mb-6"
            />
            <h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
            <p className="mt-2 text-sm text-gray-600">
              Connectez-vous pour accéder au tableau de bord
            </p>
          </div>
          <div className="mt-8">
            <GoogleAuth />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <UserHeader />
      <main className="pt-16">
        {children}
      </main>
    </div>
  );
}