import React from 'react';
import { LogOut } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

export function UserProfile() {
  const { user, logout } = useAuthStore();

  if (!user) return null;

  return (
    <div className="fixed bottom-8 left-8 flex items-center space-x-3 px-4 py-2 bg-white rounded-lg shadow-sm border border-gray-200">
      <img 
        src={user.picture} 
        alt={user.name}
        className="w-8 h-8 rounded-full"
      />
      <div className="flex flex-col">
        <span className="text-sm font-medium text-gray-900">{user.name}</span>
        <span className="text-xs text-gray-500">{user.email}</span>
      </div>
      <button
        onClick={logout}
        className="ml-4 p-1.5 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
      >
        <LogOut className="w-5 h-5" />
      </button>
    </div>
  );
}