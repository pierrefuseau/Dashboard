import React from 'react';
import { Type } from 'lucide-react';

const FONT_SIZES = ['normal', 'large', 'x-large'] as const;
type FontSize = typeof FONT_SIZES[number];

export function FontSizeAdjust() {
  const [fontSize, setFontSize] = React.useState<FontSize>('normal');

  React.useEffect(() => {
    document.documentElement.style.fontSize = {
      normal: '16px',
      large: '18px',
      'x-large': '20px'
    }[fontSize];
  }, [fontSize]);

  return (
    <button
      onClick={() => {
        const currentIndex = FONT_SIZES.indexOf(fontSize);
        const nextIndex = (currentIndex + 1) % FONT_SIZES.length;
        setFontSize(FONT_SIZES[nextIndex]);
      }}
      className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800 transition-colors"
      aria-label="Ajuster la taille du texte"
    >
      <Type className="w-5 h-5" aria-hidden="true" />
    </button>
  );
}