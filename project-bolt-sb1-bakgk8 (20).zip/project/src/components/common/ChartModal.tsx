import React, { useEffect, useCallback } from 'react';
import { X } from 'lucide-react';

interface ChartModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

export function ChartModal({ isOpen, onClose, title, children }: ChartModalProps) {
  const handleEscape = useCallback((event: KeyboardEvent) => {
    if (event.key === 'Escape') {
      onClose();
    }
  }, [onClose]);

  useEffect(() => {
    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, handleEscape]);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 overflow-hidden"
      role="dialog"
      aria-labelledby="modal-title"
      aria-modal="true"
    >
      <div className="flex min-h-screen items-center justify-center p-4">
        {/* Overlay avec animation */}
        <div 
          className="fixed inset-0 bg-black bg-opacity-75 transition-opacity"
          aria-hidden="true"
          onClick={onClose}
        />

        {/* Conteneur du modal avec animation */}
        <div 
          className="relative w-full max-w-7xl transform overflow-hidden rounded-lg bg-white shadow-xl transition-all"
          style={{ maxHeight: '90vh' }}
        >
          {/* En-tête */}
          <div className="absolute right-0 top-0 z-10 flex items-center justify-between w-full bg-white bg-opacity-90 px-6 py-4">
            <h2 
              id="modal-title"
              className="text-xl font-semibold text-gray-900"
            >
              {title}
            </h2>
            <button
              onClick={onClose}
              className="rounded-full p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-200"
              aria-label="Fermer"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          {/* Contenu scrollable */}
          <div className="mt-16 p-6 overflow-auto" style={{ maxHeight: 'calc(90vh - 4rem)' }}>
            <div className="h-full w-full">
              {children}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}