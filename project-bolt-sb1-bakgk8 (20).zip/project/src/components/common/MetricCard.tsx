import React from 'react';
import { Card } from './Card';
import { ArrowUpIcon, ArrowDownIcon } from 'lucide-react';
import { cn } from '../../utils/cn';

interface MetricCardProps {
  title: string;
  value: string | number;
  change?: number;
  trend?: 'up' | 'down';
  icon?: React.ReactNode;
  className?: string;
}

export function MetricCard({ 
  title, 
  value, 
  change, 
  trend,
  icon,
  className 
}: MetricCardProps) {
  return (
    <Card className={cn(
      "metric-card",
      className
    )}>
      <div className="flex items-center justify-between mb-3 sm:mb-4">
        <span className="text-sm sm:text-base text-gray-500 font-medium">{title}</span>
        {icon && (
          <div className="p-1.5 sm:p-2 rounded-lg bg-gray-50/80">
            {icon}
          </div>
        )}
      </div>
      
      <div className="space-y-1 sm:space-y-2">
        <div className="text-2xl sm:text-3xl font-bold">
          {value}
        </div>
        
        {(change || trend) && (
          <div className="flex items-center space-x-1.5 sm:space-x-2">
            {trend === 'up' ? (
              <ArrowUpIcon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-success" />
            ) : (
              <ArrowDownIcon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-error" />
            )}
            <span className={cn(
              "text-xs sm:text-sm font-medium",
              trend === 'up' ? "text-success" : "text-error"
            )}>
              {change && `${Math.abs(change)}%`}
            </span>
          </div>
        )}
      </div>
    </Card>
  );
}