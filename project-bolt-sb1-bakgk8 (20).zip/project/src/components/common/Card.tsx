import React from 'react';
import { cn } from '../../utils/cn';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  title?: string;
  children: React.ReactNode;
}

export function Card({ title, children, className, ...props }: CardProps) {
  return (
    <div 
      className={cn(
        "bg-white rounded-lg shadow-sm border border-gray-100",
        "p-4 sm:p-6", // Reduced padding on mobile
        "transition-all duration-200 hover:shadow-md",
        "overflow-hidden",
        className
      )} 
      {...props}
    >
      {title && (
        <h3 className="text-base sm:text-lg font-medium text-gray-900 mb-4">{title}</h3>
      )}
      <div className="overflow-x-auto -mx-4 sm:mx-0 pb-4">
        <div className="min-w-full inline-block align-middle px-4 sm:px-0">
          {children}
        </div>
      </div>
    </div>
  );
}