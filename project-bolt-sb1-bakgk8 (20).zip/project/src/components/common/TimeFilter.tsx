import React from 'react';
import { Calendar } from 'lucide-react';
import { cn } from '../../utils/cn';

export type TimeRange = 'day' | 'month' | 'year';

interface TimeFilterProps {
  value: TimeRange;
  onChange: (range: TimeRange) => void;
  className?: string;
}

export function TimeFilter({ value, onChange, className }: TimeFilterProps) {
  return (
    <div className={cn(
      "flex items-center space-x-2 bg-white rounded-lg border border-gray-200 p-1",
      className
    )}>
      <Calendar className="w-4 h-4 text-gray-400 ml-2" />
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as TimeRange)}
        className="text-sm text-gray-600 bg-transparent border-0 focus:ring-0 cursor-pointer pr-8"
      >
        <option value="day">Journalier</option>
        <option value="month">Mensuel</option>
        <option value="year">Annuel</option>
      </select>
    </div>
  );
}