import React from 'react';
import { EditButton } from './EditButton';

interface SectionHeaderProps {
  title: string;
  description?: string;
  section: 'sales' | 'purchasing' | 'hr' | 'logistics' | 'quality';
  onEdit?: () => void;
}

export function SectionHeader({ title, description, section, onEdit }: SectionHeaderProps) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
        {description && (
          <p className="mt-1 text-sm text-gray-500">{description}</p>
        )}
      </div>
      {onEdit && <EditButton section={section} onEdit={onEdit} />}
    </div>
  );
}