import React from 'react';
import { cn } from '../../utils/cn';

interface ResponsiveImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  sizes?: string;
  className?: string;
  fallbackSrc?: string;
}

export function ResponsiveImage({ 
  src, 
  alt,
  sizes = '100vw',
  className,
  fallbackSrc,
  ...props 
}: ResponsiveImageProps) {
  // Générer les srcset pour différentes tailles
  const generateSrcSet = (url: string) => {
    const widths = [480, 768, 1024, 1280, 1536];
    return widths
      .map(width => {
        // Ajouter le paramètre de largeur à l'URL de l'image
        const imageUrl = new URL(url);
        imageUrl.searchParams.set('w', width.toString());
        return `${imageUrl.toString()} ${width}w`;
      })
      .join(', ');
  };

  return (
    <img
      src={src}
      alt={alt}
      srcSet={generateSrcSet(src)}
      sizes={sizes}
      onError={(e) => {
        if (fallbackSrc) {
          (e.target as HTMLImageElement).src = fallbackSrc;
        }
      }}
      className={cn(
        "max-w-full h-auto",
        "transition-opacity duration-300",
        className
      )}
      {...props}
    />
  );
}