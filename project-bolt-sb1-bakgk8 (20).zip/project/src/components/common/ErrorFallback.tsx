import React from 'react';
import { cn } from '../../utils/cn';

interface ErrorFallbackProps {
  error: Error;
  resetErrorBoundary?: () => void;
  className?: string;
}

export function ErrorFallback({ error, resetErrorBoundary, className }: ErrorFallbackProps) {
  // Afficher un contenu vide au lieu d'un message d'erreur
  return <div className={cn("hidden", className)}></div>;
}