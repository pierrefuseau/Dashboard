import React from 'react';
import { Edit2 } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

interface EditButtonProps {
  section: 'sales' | 'purchasing' | 'hr' | 'logistics' | 'quality';
  onEdit: () => void;
}

export function EditButton({ section, onEdit }: EditButtonProps) {
  const user = useAuthStore((state) => state.user);

  // Vérifier si l'utilisateur a les droits d'édition pour cette section
  const canEdit = user?.role === 'admin' || 
    (user?.department === section && user?.role.startsWith('Responsable'));

  if (!canEdit) return null;

  return (
    <button
      onClick={onEdit}
      className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
    >
      <Edit2 className="w-4 h-4 mr-1.5" />
      Modifier
    </button>
  );
}