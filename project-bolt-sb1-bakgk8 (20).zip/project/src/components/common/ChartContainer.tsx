import React from 'react';
import { Maximize2 } from 'lucide-react';
import { Card } from './Card';

interface ChartContainerProps {
  title: string;
  subtitle?: string | React.ReactNode;
  onExpand?: () => void;
  children: React.ReactNode;
  height?: number;
}

export function ChartContainer({ 
  title, 
  subtitle, 
  onExpand, 
  children, 
  height = 400 
}: ChartContainerProps) {
  return (
    <Card className="w-full transform transition-all duration-500 hover:shadow-lg">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-gray-900">
            {title}
          </h3>
          {subtitle && (
            <div className="mt-1 text-sm text-gray-600">
              {subtitle}
            </div>
          )}
        </div>
        {onExpand && (
          <button
            onClick={onExpand}
            className="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
            aria-label="Agrandir le graphique"
          >
            <Maximize2 className="h-5 w-5" />
          </button>
        )}
      </div>
      <div 
        className="animate-fade-in transition-all duration-300"
        style={{ height: `${height}px` }}
      >
        {children}
      </div>
    </Card>
  );
}