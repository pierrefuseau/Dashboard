```tsx
import React, { useState } from 'react';
import { cn } from '../../utils/cn';

interface ImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'onLoad' | 'onError'> {
  src: string;
  alt: string;
  fallbackSrc?: string;
  aspectRatio?: '1:1' | '4:3' | '16:9' | '21:9';
  objectFit?: 'cover' | 'contain' | 'fill';
  loading?: 'lazy' | 'eager';
  sizes?: string;
}

export function Image({
  src,
  alt,
  fallbackSrc,
  aspectRatio = '16:9',
  objectFit = 'cover',
  loading = 'lazy',
  sizes = '100vw',
  className,
  ...props
}: ImageProps) {
  const [error, setError] = useState(false);
  const [loaded, setLoaded] = useState(false);

  // Calculer le padding-bottom pour le ratio d'aspect
  const aspectRatioStyles = {
    '1:1': 'pb-[100%]',
    '4:3': 'pb-[75%]',
    '16:9': 'pb-[56.25%]',
    '21:9': 'pb-[42.86%]'
  };

  // Générer les srcset pour différentes tailles
  const generateSrcSet = (url: string) => {
    const widths = [640, 750, 828, 1080, 1200, 1920, 2048, 3840];
    return widths
      .map(width => {
        // Ajouter le paramètre de largeur à l'URL de l'image
        const imageUrl = new URL(url);
        imageUrl.searchParams.set('w', width.toString());
        return `${imageUrl.toString()} ${width}w`;
      })
      .join(', ');
  };

  return (
    <div 
      className={cn(
        "relative overflow-hidden bg-gray-100 rounded-lg",
        aspectRatioStyles[aspectRatio],
        className
      )}
    >
      <img
        src={error ? fallbackSrc : src}
        alt={alt}
        srcSet={!error ? generateSrcSet(src) : undefined}
        sizes={sizes}
        loading={loading}
        onLoad={() => setLoaded(true)}
        onError={() => {
          if (!error && fallbackSrc) {
            setError(true);
          }
        }}
        className={cn(
          "absolute inset-0 w-full h-full transition-opacity duration-300",
          objectFit === 'cover' && "object-cover",
          objectFit === 'contain' && "object-contain",
          objectFit === 'fill' && "object-fill",
          loaded ? "opacity-100" : "opacity-0"
        )}
        {...props}
      />

      {/* Placeholder pendant le chargement */}
      {!loaded && (
        <div className="absolute inset-0 bg-gray-100 animate-pulse" />
      )}
    </div>
  );
}
```