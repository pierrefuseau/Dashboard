import React from 'react';
import { RefreshCw } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';

export function DataRefreshIndicator() {
  const queryClient = useQueryClient();
  const [isRefreshing, setIsRefreshing] = React.useState(false);
  const [lastUpdate, setLastUpdate] = React.useState<Date>(new Date());

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await queryClient.invalidateQueries();
      setLastUpdate(new Date());
    } finally {
      setTimeout(() => setIsRefreshing(false), 1000);
    }
  };

  return (
    <div className="flex items-center space-x-4">
      <button
        onClick={handleRefresh}
        disabled={isRefreshing}
        className={`flex items-center space-x-2 px-3 py-1.5 text-sm font-medium rounded-md transition-colors
          ${isRefreshing 
            ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
          }`}
      >
        <RefreshCw 
          className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} 
        />
        <span>
          {isRefreshing ? 'Actualisation...' : 'Actualiser'}
        </span>
      </button>
      <span className="text-sm text-gray-500">
        Dernière mise à jour : {lastUpdate.toLocaleTimeString('fr-FR')}
      </span>
    </div>
  );
}