import React from 'react';
import { Sun } from 'lucide-react';

export function ThemeToggle() {
  return (
    <button
      className="p-2 rounded-lg bg-gray-100 transition-colors"
      aria-label="Thème"
    >
      <Sun className="w-5 h-5 text-blue-500" aria-hidden="true" />
    </button>
  );
}