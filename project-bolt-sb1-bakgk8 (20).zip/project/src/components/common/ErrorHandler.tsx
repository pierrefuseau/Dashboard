import React from 'react';
import { Card } from './Card';

interface ErrorHandlerProps {
  error: Error | null;
  resetError?: () => void;
  children: React.ReactNode;
}

export function ErrorHandler({ error, resetError, children }: ErrorHandlerProps) {
  // Toujours afficher les enfants, même en cas d'erreur
  return <>{children}</>;
}