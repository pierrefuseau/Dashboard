import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';

export function LoadingFallback() {
  return (
    <div className="flex items-center justify-center h-64">
      <LoadingSpinner size="lg" />
    </div>
  );
}