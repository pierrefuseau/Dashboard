import React from 'react';
import { cn } from '../../../utils/cn';

interface TableBodyProps {
  children: React.ReactNode;
  className?: string;
}

export function TableBody({ children, className }: TableBodyProps) {
  return (
    <tbody className={cn(
      "bg-white divide-y divide-gray-200",
      "[&>tr:nth-child(even)]:bg-gray-50",
      className
    )}>
      {children}
    </tbody>
  );
}