import React from 'react';
import { cn } from '../../../utils/cn';

interface TableContainerProps {
  children: React.ReactNode;
  className?: string;
}

export function TableContainer({ children, className }: TableContainerProps) {
  return (
    <div className={cn(
      // Conteneur avec bordure et responsive
      "w-full overflow-x-auto border border-gray-300 rounded-lg",
      // Ombre légère
      "shadow-sm",
      className
    )}>
      <table className="min-w-full divide-y divide-gray-300">
        {children}
      </table>
    </div>
  );
}