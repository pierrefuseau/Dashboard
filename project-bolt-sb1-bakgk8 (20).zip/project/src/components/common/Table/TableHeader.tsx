import React from 'react';
import { cn } from '../../../utils/cn';

interface TableHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export function TableHeader({ children, className }: TableHeaderProps) {
  return (
    <thead className={cn(
      "bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider",
      className
    )}>
      {children}
    </thead>
  );
}