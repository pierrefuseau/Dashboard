import React from 'react';
import { cn } from '../../../utils/cn';

interface TableRowProps {
  children: React.ReactNode;
  className?: string;
  isHighlighted?: boolean;
}

export function TableRow({ 
  children, 
  className,
  isHighlighted = false 
}: TableRowProps) {
  return (
    <tr className={cn(
      // Hover effect
      "transition-colors duration-150 hover:bg-gray-50",
      // Highlighted state
      isHighlighted && "bg-blue-50 hover:bg-blue-50",
      className
    )}>
      {children}
    </tr>
  );
}