import React from 'react';
import { cn } from '../../../utils/cn';

interface TableCellProps {
  children: React.ReactNode;
  className?: string;
  align?: 'left' | 'center' | 'right';
  isHeader?: boolean;
}

export function TableCell({ 
  children, 
  className,
  align = 'left',
  isHeader = false 
}: TableCellProps) {
  const Tag = isHeader ? 'th' : 'td';
  
  return (
    <Tag className={cn(
      // Base styles
      "px-6 py-4 whitespace-nowrap text-sm",
      // Alignement
      {
        'text-left': align === 'left',
        'text-center': align === 'center',
        'text-right': align === 'right'
      },
      // Header specific styles
      isHeader && "font-semibold text-gray-500 uppercase tracking-wider",
      // Content specific styles
      !isHeader && "text-gray-900",
      className
    )}>
      {children}
    </Tag>
  );
}