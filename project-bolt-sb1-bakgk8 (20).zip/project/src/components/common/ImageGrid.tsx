```tsx
import React from 'react';
import { Image } from './Image';
import { cn } from '../../utils/cn';

interface ImageGridProps {
  images: Array<{
    src: string;
    alt: string;
    aspectRatio?: '1:1' | '4:3' | '16:9' | '21:9';
  }>;
  columns?: 1 | 2 | 3 | 4;
  gap?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function ImageGrid({
  images,
  columns = 3,
  gap = 'md',
  className
}: ImageGridProps) {
  const gapClasses = {
    sm: 'gap-2',
    md: 'gap-4',
    lg: 'gap-6'
  };

  const columnClasses = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 sm:grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
  };

  // Calculer les tailles d'images en fonction du nombre de colonnes
  const getSizes = () => {
    switch (columns) {
      case 1:
        return '100vw';
      case 2:
        return '(min-width: 640px) 50vw, 100vw';
      case 3:
        return '(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw';
      case 4:
        return '(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw';
      default:
        return '100vw';
    }
  };

  return (
    <div className={cn(
      'grid',
      columnClasses[columns],
      gapClasses[gap],
      className
    )}>
      {images.map((image, index) => (
        <Image
          key={index}
          src={image.src}
          alt={image.alt}
          aspectRatio={image.aspectRatio || '16:9'}
          sizes={getSizes()}
          className="w-full"
        />
      ))}
    </div>
  );
}
```