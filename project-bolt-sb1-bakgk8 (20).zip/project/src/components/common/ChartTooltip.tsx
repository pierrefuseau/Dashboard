import React from 'react';
import { cn } from '../../utils/cn';

interface ChartTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
  valueFormatter?: (value: number) => string;
  periodFormatter?: (period: string) => string;
  className?: string;
}

export function ChartTooltip({ 
  active, 
  payload, 
  label,
  valueFormatter = (value) => value.toString(),
  periodFormatter = (period) => period,
  className 
}: ChartTooltipProps) {
  if (!active || !payload?.length) {
    return null;
  }

  return (
    <div className={cn(
      "bg-white px-4 py-3 shadow-lg border border-gray-100 rounded-lg",
      className
    )}>
      <div className="text-sm font-medium text-gray-900 mb-2">
        {periodFormatter(label || '')}
      </div>
      {payload.map((entry, index) => (
        <div 
          key={index}
          className="flex items-center justify-between space-x-8 text-sm"
        >
          <span className="text-gray-600">{entry.name}</span>
          <span className="font-medium text-gray-900">
            {valueFormatter(entry.value)}
          </span>
        </div>
      ))}
    </div>
  );
}