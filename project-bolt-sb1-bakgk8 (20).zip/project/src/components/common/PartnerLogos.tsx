import React from 'react';

export function PartnerLogos() {
  return (
    <div className="flex items-center space-x-4">
      <a 
        href="https://www.delicesagro.com"
        target="_blank"
        rel="noopener noreferrer"
        className="h-16 w-auto bg-white rounded-lg border border-gray-200 px-4 py-2 hover:bg-gray-50 transition-colors"
        aria-label="Delices Agro"
      >
        <img 
          src="https://www.delicesagro.com/front/fonts/logo-delices-agro-dark.svg"
          alt="Delices Agro"
          className="h-12 w-auto"
        />
      </a>

      <a
        href="https://www.cpropre.com"
        target="_blank"
        rel="noopener noreferrer"
        className="h-16 w-auto bg-white rounded-lg border border-gray-200 px-4 py-2 hover:bg-gray-50 transition-colors"
        aria-label="C'Propre"
      >
        <img 
          src="https://drive.google.com/uc?export=view&id=1JTM9lPz3LuFi6ip5GOOpMpRPDeYpY7vj"
          alt="C'Propre"
          className="h-12 w-auto"
        />
      </a>
    </div>
  );
}