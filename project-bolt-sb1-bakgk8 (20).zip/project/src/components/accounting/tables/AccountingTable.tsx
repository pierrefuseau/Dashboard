import React from 'react';
import { Card } from '../../common/Card';
import { formatCurrency } from '../../../utils/formatters/currency';

const mockData = [
  { account: '411000', label: 'Clients', debit: 450000, credit: 0 },
  { account: '401000', label: 'Fournisseurs', debit: 0, credit: 320000 },
  { account: '512000', label: 'Banque', debit: 780000, credit: 0 },
  { account: '445660', label: 'TVA', debit: 0, credit: 95000 },
  { account: '607000', label: 'Achats', debit: 650000, credit: 0 }
];

export function AccountingTable() {
  return (
    <Card title="Balance des comptes">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Compte
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Libellé
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Débit
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Crédit
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {mockData.map((row) => (
              <tr key={row.account} className="hover:bg-gray-50">
                <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {row.account}
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                  {row.label}
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                  {row.debit > 0 ? formatCurrency(row.debit) : '-'}
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                  {row.credit > 0 ? formatCurrency(row.credit) : '-'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}