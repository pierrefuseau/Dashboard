import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';
import { Card } from '../../common/Card';
import { formatCurrency } from '../../../utils/formatters/currency';

interface AccountingMetricCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  format?: 'currency' | 'percentage' | 'number';
  color?: 'indigo';
}

export function AccountingMetricCard({
  title,
  value,
  icon: Icon,
  format = 'currency',
  color = 'indigo'
}: AccountingMetricCardProps) {
  const formatValue = (val: number) => {
    if (val === 0) return 'Non disponible';
    
    switch (format) {
      case 'currency':
        return formatCurrency(val);
      case 'percentage':
        return `${val.toFixed(1)}%`;
      default:
        return val.toString();
    }
  };

  return (
    <Card>
      <div className="flex items-center justify-between p-4 sm:p-6">
        <div className="min-w-0 flex-1">
          <p className="text-sm sm:text-base font-medium text-gray-500 truncate">
            {title}
          </p>
          <p className="mt-1 text-xl sm:text-2xl lg:text-3xl font-semibold text-indigo-600 truncate">
            {formatValue(value)}
          </p>
        </div>
        <div className="flex-shrink-0 p-3 rounded-full bg-indigo-50">
          <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-indigo-600" />
        </div>
      </div>
    </Card>
  );
}