import React from 'react';
import { Calculator, TrendingUp, Receipt } from 'lucide-react';
import { AccountingMetricCard } from './metrics/AccountingMetricCard';
import { ReceivablesTable } from './receivables/ReceivablesTable';
import { LoansOverview } from './loans/LoansOverview';
import { NavigationTabs } from '../common/NavigationTabs';
import { useAccountingMetrics } from '../../hooks/accounting/useAccountingMetrics';
import { LoadingSpinner } from '../common/LoadingSpinner';

export function AccountingPage() {
  const [activeTab, setActiveTab] = React.useState('overview');
  const { revenue, grossMargin, treasury, treasuryDate, isLoading } = useAccountingMetrics();

  const tabs = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: Calculator },
    { id: 'receivables', label: 'Encours Clients', icon: Receipt },
    { id: 'loans', label: 'Emprunts', icon: TrendingUp }
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'receivables':
        return <ReceivablesTable />;
      case 'loans':
        return <LoansOverview />;
      default:
        return (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <AccountingMetricCard
              title="Chiffre d'affaires Bilan"
              value={revenue}
              icon={Calculator}
              format="currency"
            />
            <AccountingMetricCard
              title="Marge Brute Bilan"
              value={grossMargin}
              icon={TrendingUp}
              format="currency"
            />
            <AccountingMetricCard
              title={`Trésorerie (au ${treasuryDate})`}
              value={treasury}
              icon={Receipt}
              format="currency"
            />
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Comptabilité</h2>
        <p className="mt-1 text-sm text-gray-500">
          Suivi des indicateurs financiers et comptables
        </p>
      </div>

      <NavigationTabs
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        variant="default"
      />

      <div className="mt-6">
        {renderContent()}
      </div>
    </div>
  );
}