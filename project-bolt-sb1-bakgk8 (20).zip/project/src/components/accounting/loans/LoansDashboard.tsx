import React, { useState } from 'react';
import { useLoans } from '../../../hooks/accounting/useLoans';
import { LoansSummaryCards } from './components/LoansSummaryCards';
import { LoansTable } from './components/LoansTable';
import { LoanDetails } from './components/LoanDetails';
import { LoadingSpinner } from '../../common/LoadingSpinner';

export function LoansDashboard() {
  const { data, isLoading } = useLoans();
  const [selectedLoanId, setSelectedLoanId] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (!data?.loans) {
    return (
      <div className="text-center text-gray-500 py-8">
        Aucune donnée d'emprunt disponible
      </div>
    );
  }

  const selectedLoan = data.loans.find(loan => loan.id === selectedLoanId);

  return (
    <div className="space-y-6">
      <LoansSummaryCards summary={data.summary} />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-3">
          <LoansTable 
            loans={data.loans}
            onSelectLoan={setSelectedLoanId}
            selectedLoanId={selectedLoanId}
          />
        </div>
        
        {selectedLoan && (
          <div className="lg:col-span-1">
            <LoanDetails 
              loan={selectedLoan} 
              onClose={() => setSelectedLoanId(null)}
            />
          </div>
        )}
      </div>
    </div>
  );
}