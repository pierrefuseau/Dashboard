/**
 * Configuration des logos des banques
 */
export const BANK_LOGOS = {
  'BPI': 'https://upload.wikimedia.org/wikipedia/fr/thumb/8/83/Bpifrance_logo.svg/2560px-Bpifrance_logo.svg.png',
  'BNP': 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Logo_BNP_Paribas.svg/2560px-Logo_BNP_Paribas.svg.png',
  'CRCA': 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Logo_Cr%C3%A9dit_Agricole.svg/2560px-Logo_Cr%C3%A9dit_Agricole.svg.png',
  'LCL': 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Logo_LCL.svg/2560px-Logo_LCL.svg.png'
} as const;

/**
 * Récupère l'URL du logo pour un prêteur donné
 */
export function getBankLogo(lender: string): string | undefined {
  const matchingBank = Object.keys(BANK_LOGOS).find(key => 
    lender.toUpperCase().includes(key)
  );

  return matchingBank ? BANK_LOGOS[matchingBank as keyof typeof BANK_LOGOS] : undefined;
}