/**
 * Configuration des couleurs et styles par prêteur
 */
export const LENDER_STYLES = {
  'BPI': {
    border: 'border-blue-500',
    bg: 'bg-blue-50',
    text: 'text-blue-700',
    hover: 'hover:bg-blue-50/80'
  },
  'BNP': {
    border: 'border-green-500',
    bg: 'bg-green-50',
    text: 'text-green-700',
    hover: 'hover:bg-green-50/80'
  },
  'CRCA': {
    border: 'border-red-500',
    bg: 'bg-red-50',
    text: 'text-red-700',
    hover: 'hover:bg-red-50/80'
  },
  'LCL': {
    border: 'border-purple-500',
    bg: 'bg-purple-50',
    text: 'text-purple-700',
    hover: 'hover:bg-purple-50/80'
  }
} as const;

/**
 * Retourne les styles Tailwind pour un prêteur donné
 */
export function getLenderStyles(lender: string) {
  const matchingLender = Object.keys(LENDER_STYLES).find(key => 
    lender.toUpperCase().includes(key)
  );

  return matchingLender 
    ? LENDER_STYLES[matchingLender as keyof typeof LENDER_STYLES]
    : {
        border: 'border-gray-200',
        bg: 'bg-gray-50',
        text: 'text-gray-700',
        hover: 'hover:bg-gray-50/80'
      };
}