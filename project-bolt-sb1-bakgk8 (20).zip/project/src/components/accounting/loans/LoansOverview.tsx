import React from 'react';
import { LoansDashboard } from './LoansDashboard';

export function LoansOverview() {
  return <LoansDashboard />;
}