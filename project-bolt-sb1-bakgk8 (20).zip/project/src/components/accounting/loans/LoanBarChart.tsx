import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card } from '../../common/Card';
import { Loan } from './types';
import { formatCurrency } from '../../../utils/formatters/currency';

interface LoanBarChartProps {
  loans: Loan[];
}

export function LoanBarChart({ loans }: LoanBarChartProps) {
  const data = loans.map(loan => ({
    id: loan.id,
    amount: loan.amount,
    interest: loan.interestPaid
  }));

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Montants empruntés et intérêts</h3>
        <p className="mt-1 text-sm text-gray-500">Répartition par emprunt</p>
      </div>

      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            layout="vertical"
            margin={{ top: 20, right: 30, left: 40, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" tickFormatter={formatCurrency} />
            <YAxis type="category" dataKey="id" width={100} />
            <Tooltip formatter={(value: number) => formatCurrency(value)} />
            <Legend />
            <Bar dataKey="amount" name="Montant emprunté" fill="#3b82f6" />
            <Bar dataKey="interest" name="Intérêts payés" fill="#ef4444" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}