import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card } from '../../common/Card';
import { Loan } from './types';
import { formatCurrency } from '../../../utils/formatters/currency';

interface LoanTimelineChartProps {
  loans: Loan[];
}

const COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#6366f1'];

export function LoanTimelineChart({ loans }: LoanTimelineChartProps) {
  const years = Array.from(
    { length: 15 }, 
    (_, i) => 2017 + i
  );

  const data = years.map(year => {
    const point: any = { year };
    loans.forEach(loan => {
      const startYear = new Date(loan.startDate).getFullYear();
      const endYear = new Date(loan.endDate).getFullYear();
      if (year >= startYear && year <= endYear) {
        point[loan.id] = loan.remainingAmount;
      }
    });
    return point;
  });

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Calendrier des échéances</h3>
        <p className="mt-1 text-sm text-gray-500">Évolution des montants restants</p>
      </div>

      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="year" />
            <YAxis tickFormatter={formatCurrency} />
            <Tooltip 
              formatter={(value: number) => formatCurrency(value)}
              labelFormatter={(label) => `Année ${label}`}
            />
            <Legend />
            {loans.map((loan, index) => (
              <Line
                key={loan.id}
                type="monotone"
                dataKey={loan.id}
                name={`${loan.id} (${loan.lender})`}
                stroke={COLORS[index % COLORS.length]}
                strokeWidth={2}
                dot={{ r: 4 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}