import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card } from '../../common/Card';
import { YearlyLoanAmount } from './types';
import { formatCurrency } from '../../../utils/formatters/currency';

interface StackedLoanChartProps {
  data: YearlyLoanAmount[];
}

const COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#6366f1'];

export function StackedLoanChart({ data }: StackedLoanChartProps) {
  const lenders = Array.from(
    new Set(data.flatMap(d => Object.keys(d.amounts)))
  );

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Répartition des emprunts par année</h3>
        <p className="mt-1 text-sm text-gray-500">Montants restants par prêteur</p>
      </div>

      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="year" />
            <YAxis tickFormatter={(value) => formatCurrency(value)} />
            <Tooltip 
              formatter={(value: number) => formatCurrency(value)}
              labelFormatter={(label) => `Année ${label}`}
            />
            <Legend />
            {lenders.map((lender, index) => (
              <Bar
                key={lender}
                dataKey={`amounts.${lender}`}
                name={lender}
                stackId="a"
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}