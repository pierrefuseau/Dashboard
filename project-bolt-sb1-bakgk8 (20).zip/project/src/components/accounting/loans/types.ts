export interface Loan {
  id: string;
  lender: string;
  subject: string;
  name: string;
  amount: number;
  monthlyPayment: number;
  interestRate: number;
  duration: number;
  startDate: string;
  endDate: string;
  remainingAmount: number;
  paidAmount: number;
  remainingJan2025: number;
  interestPaid: number;
}

export interface LoanFilter {
  search: string;
  lender?: string;
  status?: 'all' | 'active' | 'completed';
}