import React from 'react';
import { Clock, CheckCircle, AlertTriangle } from 'lucide-react';
import { cn } from '../../../../utils/cn';

interface LoanStatusBadgeProps {
  endDate: string;
  className?: string;
}

export function LoanStatusBadge({ endDate, className }: LoanStatusBadgeProps) {
  const dueDate = new Date(endDate);
  const now = new Date();
  const monthsUntilDue = (dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24 * 30);

  if (dueDate < now) {
    return (
      <div className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
        "bg-red-100 text-red-800",
        className
      )}>
        <AlertTriangle className="w-3 h-3 mr-1" />
        Échéance dépassée
      </div>
    );
  }

  if (monthsUntilDue <= 3) {
    return (
      <div className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
        "bg-orange-100 text-orange-800",
        className
      )}>
        <Clock className="w-3 h-3 mr-1" />
        Échéance proche
      </div>
    );
  }

  return (
    <div className={cn(
      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
      "bg-green-100 text-green-800",
      className
    )}>
      <CheckCircle className="w-3 h-3 mr-1" />
      En cours
    </div>
  );
}