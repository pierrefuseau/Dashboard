import React from 'react';
import { getBankLogo } from '../utils/bankLogos';

interface BankLogoProps {
  lender: string;
  className?: string;
}

export function BankLogo({ lender, className = '' }: BankLogoProps) {
  const logoUrl = getBankLogo(lender);

  if (!logoUrl) return null;

  return (
    <div className={`flex items-center justify-center ${className}`}>
      <img 
        src={logoUrl} 
        alt={`Logo ${lender}`}
        className="h-8 w-auto object-contain"
        onError={(e) => {
          // Masquer l'image en cas d'erreur de chargement
          (e.target as HTMLImageElement).style.display = 'none';
        }}
      />
    </div>
  );
}