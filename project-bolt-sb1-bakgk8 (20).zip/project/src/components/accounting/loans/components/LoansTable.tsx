import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Loan } from '../types';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { formatDate } from '../../../../utils/formatters/date';
import { LoanStatusBadge } from './LoanStatusBadge';
import { getLenderStyles } from '../utils/lenderColors';

interface LoansTableProps {
  loans: Loan[];
  onSelectLoan: (loanId: string) => void;
  selectedLoanId: string | null;
}

type SortField = 'endDate' | 'amount' | 'remainingJan2025' | 'monthlyPayment';

export function LoansTable({ loans, onSelectLoan, selectedLoanId }: LoansTableProps) {
  const [sortConfig, setSortConfig] = useState<{
    field: SortField;
    direction: 'asc' | 'desc';
  }>({
    field: 'endDate',
    direction: 'asc'
  });

  const sortedLoans = React.useMemo(() => {
    return [...loans].sort((a, b) => {
      const multiplier = sortConfig.direction === 'asc' ? 1 : -1;
      
      switch (sortConfig.field) {
        case 'endDate':
          return multiplier * (new Date(a.endDate).getTime() - new Date(b.endDate).getTime());
        case 'amount':
          return multiplier * (a.amount - b.amount);
        case 'remainingJan2025':
          return multiplier * (a.remainingJan2025 - b.remainingJan2025);
        case 'monthlyPayment':
          return multiplier * (a.monthlyPayment - b.monthlyPayment);
        default:
          return 0;
      }
    });
  }, [loans, sortConfig]);

  const handleSort = (field: SortField) => {
    setSortConfig(current => ({
      field,
      direction: current.field === field && current.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const SortIcon = ({ column }: { column: SortField }) => {
    if (sortConfig.field !== column) return null;
    return sortConfig.direction === 'asc' ? 
      <ChevronUp className="w-4 h-4" /> : 
      <ChevronDown className="w-4 h-4" />;
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Référence
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Prêteur
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Sujet
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              <button 
                onClick={() => handleSort('amount')}
                className="flex items-center justify-end space-x-1 w-full"
              >
                <span>Montant</span>
                <SortIcon column="amount" />
              </button>
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              <button 
                onClick={() => handleSort('monthlyPayment')}
                className="flex items-center justify-end space-x-1 w-full"
              >
                <span>Échéance</span>
                <SortIcon column="monthlyPayment" />
              </button>
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              <button 
                onClick={() => handleSort('remainingJan2025')}
                className="flex items-center justify-end space-x-1 w-full"
              >
                <span>Restant dû</span>
                <SortIcon column="remainingJan2025" />
              </button>
            </th>
            <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
              <button 
                onClick={() => handleSort('endDate')}
                className="flex items-center justify-center space-x-1 w-full"
              >
                <span>Échéance finale</span>
                <SortIcon column="endDate" />
              </button>
            </th>
            <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
              Statut
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {sortedLoans.map((loan) => {
            const styles = getLenderStyles(loan.lender);
            
            return (
              <tr 
                key={loan.id}
                onClick={() => onSelectLoan(loan.id)}
                className={`
                  cursor-pointer transition-colors
                  ${selectedLoanId === loan.id ? styles.bg : styles.hover}
                  ${styles.border} border-l-4
                `}
              >
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {loan.id}
                </td>
                <td className={`px-6 py-4 whitespace-nowrap text-sm ${styles.text}`}>
                  {loan.lender}
                </td>
                <td className="px-6 py-4 text-sm text-gray-900">
                  {loan.subject}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                  {formatCurrency(loan.amount)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                  {formatCurrency(loan.monthlyPayment)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                  {formatCurrency(loan.remainingJan2025)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-center text-gray-500">
                  {formatDate(loan.endDate)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-center">
                  <LoanStatusBadge endDate={loan.endDate} />
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}