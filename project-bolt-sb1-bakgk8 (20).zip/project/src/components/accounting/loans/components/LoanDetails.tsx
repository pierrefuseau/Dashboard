import React from 'react';
import { X, Calendar, Percent, Clock, Euro } from 'lucide-react';
import { Loan } from '../types';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { getLenderStyles } from '../utils/lenderColors';
import { BankLogo } from './BankLogo';

interface LoanDetailsProps {
  loan: Loan;
  onClose: () => void;
}

export function LoanDetails({ loan, onClose }: LoanDetailsProps) {
  const styles = getLenderStyles(loan.lender);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl">
        {/* En-tête */}
        <div className={`px-6 py-4 border-b ${styles.border} border-l-4 rounded-t-lg`}>
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <h3 className={`text-lg font-medium ${styles.text}`}>
                Détails de l'emprunt
              </h3>
              <BankLogo lender={loan.lender} />
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Contenu */}
        <div className="p-6 space-y-6">
          {/* Informations principales */}
          <div>
            <h4 className="text-sm font-medium text-gray-500 mb-4">Informations générales</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Référence</p>
                <p className="mt-1 text-sm font-medium text-gray-900">{loan.id}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Prêteur</p>
                <p className="mt-1 text-sm font-medium text-gray-900">{loan.lender}</p>
              </div>
            </div>
          </div>

          {/* Montants */}
          <div>
            <h4 className="text-sm font-medium text-gray-500 mb-4">Montants</h4>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Euro className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-500">Montant emprunté</span>
                </div>
                <span className="text-sm font-medium text-gray-900">
                  {formatCurrency(loan.amount)}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Euro className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-500">Restant dû</span>
                </div>
                <span className="text-sm font-medium text-gray-900">
                  {formatCurrency(loan.remainingJan2025)}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Euro className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-500">Intérêts versés</span>
                </div>
                <span className="text-sm font-medium text-gray-900">
                  {formatCurrency(loan.interestPaid)}
                </span>
              </div>
            </div>
          </div>

          {/* Caractéristiques */}
          <div>
            <h4 className="text-sm font-medium text-gray-500 mb-4">Caractéristiques</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Percent className="h-5 w-5 text-gray-400 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Taux fixe</p>
                  <p className="text-sm font-medium text-gray-900">{loan.interestRate}%</p>
                </div>
              </div>
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Clock className="h-5 w-5 text-gray-400 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Durée</p>
                  <p className="text-sm font-medium text-gray-900">{loan.duration} mois</p>
                </div>
              </div>
            </div>
          </div>

          {/* Dates */}
          <div>
            <h4 className="text-sm font-medium text-gray-500 mb-4">Dates</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Calendar className="h-5 w-5 text-gray-400 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Début</p>
                  <p className="text-sm font-medium text-gray-900">
                    {format(new Date(loan.startDate), 'dd MMMM yyyy', { locale: fr })}
                  </p>
                </div>
              </div>
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Calendar className="h-5 w-5 text-gray-400 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Fin</p>
                  <p className="text-sm font-medium text-gray-900">
                    {format(new Date(loan.endDate), 'dd MMMM yyyy', { locale: fr })}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}