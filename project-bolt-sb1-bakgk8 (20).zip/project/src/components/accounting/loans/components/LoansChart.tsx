import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Loan } from '../types';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { ChartModal } from '../../../common/ChartModal';
import { Maximize2 } from 'lucide-react';

interface LoansChartProps {
  loans: Loan[];
}

export function LoansChart({ loans }: LoansChartProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Préparer les données pour le graphique
  const years = Array.from(
    new Set(
      loans.map(loan => new Date(loan.endDate).getFullYear())
    )
  ).sort();

  const lenders = Array.from(
    new Set(loans.map(loan => loan.lender))
  ).sort();

  const chartData = years.map(year => {
    const yearData: any = { year };
    
    lenders.forEach(lender => {
      yearData[lender] = loans
        .filter(loan => 
          loan.lender === lender && 
          new Date(loan.endDate).getFullYear() >= year
        )
        .reduce((sum, loan) => sum + loan.remainingJan2025, 0);
    });

    yearData.total = Object.values(yearData)
      .reduce((sum: number, val: any) => 
        typeof val === 'number' ? sum + val : sum, 0
      );

    return yearData;
  });

  // Générer des couleurs uniques pour chaque prêteur
  const colors = [
    '#3b82f6', // blue-500
    '#ef4444', // red-500
    '#10b981', // emerald-500
    '#f59e0b', // amber-500
    '#8b5cf6', // violet-500
    '#ec4899', // pink-500
    '#6366f1', // indigo-500
    '#14b8a6'  // teal-500
  ];

  const renderChart = (height: number = 400) => (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={chartData} margin={{ top: 20, right: 30, left: 60, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
        <XAxis 
          dataKey="year"
          tick={{ fill: '#6B7280', fontSize: 12 }}
        />
        <YAxis
          tickFormatter={formatCurrency}
          tick={{ fill: '#6B7280', fontSize: 12 }}
        />
        <Tooltip
          formatter={(value: number) => [formatCurrency(value), 'Montant restant']}
          contentStyle={{
            backgroundColor: 'white',
            border: '1px solid #E5E7EB',
            borderRadius: '0.5rem',
            padding: '12px'
          }}
        />
        <Legend />
        {lenders.map((lender, index) => (
          <Bar
            key={lender}
            dataKey={lender}
            name={lender}
            stackId="a"
            fill={colors[index % colors.length]}
            radius={[4, 4, 0, 0]}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium text-gray-900">
            Évolution des emprunts
          </h3>
          <p className="mt-1 text-sm text-gray-500">
            Montants restants par année et par prêteur
          </p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
        >
          <Maximize2 className="h-5 w-5" />
        </button>
      </div>

      <div className="p-4">
        <div className="h-[400px]">
          {renderChart()}
        </div>
      </div>

      <ChartModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Évolution des emprunts"
      >
        {renderChart(600)}
      </ChartModal>
    </div>
  );
}