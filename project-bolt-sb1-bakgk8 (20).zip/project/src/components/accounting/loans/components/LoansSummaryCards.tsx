import React from 'react';
import { Euro, Wallet } from 'lucide-react';
import { LoanSummary } from '../types';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface LoansSummaryCardsProps {
  summary: LoanSummary;
}

export function LoansSummaryCards({ summary }: LoansSummaryCardsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Montant total des emprunts */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Montant total emprunté</p>
            <p className="mt-2 text-2xl font-semibold text-gray-900">
              {formatCurrency(summary.totalAmount)}
            </p>
          </div>
          <div className="p-3 bg-blue-50 rounded-full">
            <Euro className="w-6 h-6 text-blue-600" />
          </div>
        </div>
      </div>

      {/* Montant restant dû */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Montant restant dû</p>
            <p className="mt-2 text-2xl font-semibold text-gray-900">
              {formatCurrency(summary.totalRemaining)}
            </p>
          </div>
          <div className="p-3 bg-blue-50 rounded-full">
            <Wallet className="w-6 h-6 text-blue-600" />
          </div>
        </div>
      </div>
    </div>
  );
}