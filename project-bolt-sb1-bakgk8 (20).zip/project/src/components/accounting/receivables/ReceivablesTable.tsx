import React from 'react';
import { Card } from '../../common/Card';
import { ArrowUpDown } from 'lucide-react';
import { formatCurrency } from '../../../utils/formatters/currency';
import { useReceivables } from '../../../hooks/accounting/useReceivables';
import { LoadingSpinner } from '../../common/LoadingSpinner';

export function ReceivablesTable() {
  const { data: receivables, totalCompanyReceivables, isLoading } = useReceivables();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  // Calculate total amount from detailed receivables
  const detailedTotal = receivables?.reduce((sum, item) => sum + item.amount, 0) || 0;

  return (
    <Card>
      <div className="mb-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium text-gray-900">Encours Clients</h3>
            <p className="mt-1 text-sm text-gray-500">
              Total encours détaillés : {formatCurrency(detailedTotal)}
            </p>
          </div>
          <div className="bg-blue-50 text-blue-600 px-4 py-2 rounded-lg">
            <div className="text-sm font-medium">Encours Total Entreprise</div>
            <div className="text-lg font-semibold">{formatCurrency(totalCompanyReceivables)}</div>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Code
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Client
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Montant
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                % du Total
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {receivables?.map((receivable) => (
              <tr key={receivable.code} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {receivable.code}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {receivable.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right font-medium text-gray-900">
                  {formatCurrency(receivable.amount)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  <div className="flex items-center justify-end">
                    <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${receivable.percentage}%` }}
                      />
                    </div>
                    <span className="text-sm text-gray-600">
                      {receivable.percentage.toFixed(1)}%
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}