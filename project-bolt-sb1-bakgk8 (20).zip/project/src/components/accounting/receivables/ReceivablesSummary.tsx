import React from 'react';
import { TrendingUp, Users, Percent } from 'lucide-react';
import { Card } from '../../common/Card';
import { formatCurrency } from '../../../utils/formatters/currency';

interface ReceivablesSummaryProps {
  totalAmount: number;
  topClient: { name: string; amount: number };
  top3Percentage: number;
}

export function ReceivablesSummary({ 
  totalAmount, 
  topClient, 
  top3Percentage 
}: ReceivablesSummaryProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Total Encours</p>
            <p className="mt-2 text-2xl font-semibold text-gray-900">
              {formatCurrency(totalAmount)}
            </p>
          </div>
          <div className="p-3 bg-blue-50 rounded-full">
            <TrendingUp className="w-6 h-6 text-blue-600" />
          </div>
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Client Principal</p>
            <p className="mt-2 text-lg font-semibold text-gray-900">
              {topClient.name}
            </p>
            <p className="text-sm text-blue-600">
              {formatCurrency(topClient.amount)}
            </p>
          </div>
          <div className="p-3 bg-blue-50 rounded-full">
            <Users className="w-6 h-6 text-blue-600" />
          </div>
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Top 3 Clients</p>
            <p className="mt-2 text-2xl font-semibold text-gray-900">
              {top3Percentage.toFixed(1)}%
            </p>
            <p className="text-sm text-gray-500">du total des encours</p>
          </div>
          <div className="p-3 bg-blue-50 rounded-full">
            <Percent className="w-6 h-6 text-blue-600" />
          </div>
        </div>
      </Card>
    </div>
  );
}