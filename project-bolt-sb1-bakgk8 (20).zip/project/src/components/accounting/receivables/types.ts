export interface Receivable {
  code: string;
  name: string;
  amount: number;
  percentage: number;
}