import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { Card } from '../../common/Card';
import { ReceivablesTable } from './ReceivablesTable';
import { ReceivablesSummary } from './ReceivablesSummary';
import { ReceivablesCharts } from './ReceivablesCharts';
import { useReceivables } from '../../../hooks/accounting/useReceivables';
import { LoadingSpinner } from '../../common/LoadingSpinner';

export function ReceivablesOverview() {
  const { data: receivables, isLoading } = useReceivables();
  const [sortConfig, setSortConfig] = useState<{
    key: 'amount' | 'percentage';
    direction: 'asc' | 'desc';
  }>({ key: 'amount', direction: 'desc' });
  const [searchTerm, setSearchTerm] = useState('');

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner />
        </div>
      </Card>
    );
  }

  // Ensure receivables is always an array
  const safeReceivables = receivables || [];

  const filteredReceivables = safeReceivables.filter(r => 
    r.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const sortedReceivables = [...filteredReceivables].sort((a, b) => {
    const multiplier = sortConfig.direction === 'desc' ? -1 : 1;
    return (a[sortConfig.key] - b[sortConfig.key]) * multiplier;
  });

  const totalAmount = safeReceivables.reduce((sum, r) => sum + r.amount, 0);
  const topClient = safeReceivables[0] || { name: 'N/A', amount: 0 };
  const top3Percentage = safeReceivables
    .slice(0, 3)
    .reduce((sum, r) => sum + r.percentage, 0);

  return (
    <div className="space-y-6">
      <ReceivablesSummary 
        totalAmount={totalAmount}
        topClient={topClient}
        top3Percentage={top3Percentage}
      />

      {safeReceivables.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ReceivablesCharts receivables={safeReceivables} />
        </div>
      )}

      <Card>
        <div className="mb-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">
              Détail des Encours Clients
            </h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Rechercher un client..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        {sortedReceivables.length > 0 ? (
          <ReceivablesTable 
            receivables={sortedReceivables}
            sortConfig={sortConfig}
            onSort={setSortConfig}
          />
        ) : (
          <div className="text-center text-gray-500 py-8">
            Aucun résultat trouvé
          </div>
        )}
      </Card>
    </div>
  );
}