import React from 'react';
import { LogOut } from 'lucide-react';
import { useAuth } from '../../hooks/auth/useAuth';
import { cn } from '../../utils/cn';

export function UserProfileButton() {
  const { user, logout } = useAuth();

  if (!user) return null;

  // Extraire les initiales du nom
  const initials = user.name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase();

  return (
    <button
      onClick={logout}
      className={cn(
        // Style visuel
        "w-full bg-white/90 backdrop-blur-sm rounded-lg shadow-sm border border-gray-200",
        "p-2",
        // Interactions
        "hover:bg-gray-50/90 active:bg-gray-100/90",
        "transition-all duration-200",
        // Focus
        "focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
      )}
      aria-label="Profil utilisateur"
    >
      <div className="flex items-center">
        {/* Avatar avec initiales */}
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
          <span className="text-xs font-medium text-gray-600">{initials}</span>
        </div>

        {/* Informations utilisateur - version compacte */}
        <div className="flex-1 min-w-0 ml-2 text-left">
          <span className="text-xs font-medium text-gray-900 truncate block">
            {user.name}
          </span>
        </div>

        {/* Icône de déconnexion */}
        <LogOut className="flex-shrink-0 w-4 h-4 text-gray-400 ml-1" />
      </div>
    </button>
  );
}