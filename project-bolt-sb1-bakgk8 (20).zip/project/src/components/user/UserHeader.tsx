import React from 'react';
import { Bell, ChevronDown } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

export function UserHeader() {
  const { user } = useAuthStore();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  if (!user) return null;

  return (
    <header className="flex items-center justify-between px-6 py-4 bg-white border-b">
      <div className="flex items-center space-x-4">
        <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
      </div>

      <div className="flex items-center space-x-6">
        <button className="relative p-2 text-gray-400 hover:text-gray-500">
          <Bell className="w-6 h-6" />
          <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full" />
        </button>

        <div className="relative">
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="flex items-center space-x-3 focus:outline-none"
          >
            <img
              src={user.picture}
              alt={user.name}
              className="w-8 h-8 rounded-full"
            />
            <div className="text-sm text-left">
              <p className="font-medium text-gray-700">{user.name}</p>
              <p className="text-gray-500">{user.email}</p>
            </div>
            <ChevronDown className="w-4 h-4 text-gray-500" />
          </button>

          {isMenuOpen && (
            <div className="absolute right-0 z-10 w-48 mt-2 bg-white rounded-md shadow-lg">
              <div className="py-1">
                <button
                  onClick={() => {
                    // Handle logout
                  }}
                  className="block w-full px-4 py-2 text-sm text-left text-gray-700 hover:bg-gray-100"
                >
                  Se déconnecter
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}