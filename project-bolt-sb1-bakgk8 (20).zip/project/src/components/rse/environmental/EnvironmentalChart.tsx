import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { EnvironmentalTimeline } from '../../../types/rse';

interface EnvironmentalChartProps {
  data: EnvironmentalTimeline[];
}

export function EnvironmentalChart({ data }: EnvironmentalChartProps) {
  return (
    <div className="h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="period" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="recycling" 
            name="Recyclage" 
            stroke="#22c55e" 
            strokeWidth={2}
          />
          <Line 
            type="monotone" 
            dataKey="energy" 
            name="Énergie Renouvelable" 
            stroke="#3b82f6" 
            strokeWidth={2}
          />
          <Line 
            type="monotone" 
            dataKey="water" 
            name="Consommation d'eau" 
            stroke="#f59e0b" 
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}