import React from 'react';
import { Card } from '../../common/Card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useEnvironmentalMetrics } from '../../../hooks/rse/useEnvironmentalMetrics';

export function EnvironmentalMetrics() {
  const { data: metrics, isLoading } = useEnvironmentalMetrics();

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Indicateurs Environnementaux</h3>
        <p className="mt-1 text-sm text-gray-500">
          Suivi des performances environnementales
        </p>
      </div>

      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={metrics?.timeline}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="period" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="recycling" name="Recyclage" stroke="#22c55e" />
            <Line type="monotone" dataKey="energy" name="Énergie Renouvelable" stroke="#3b82f6" />
            <Line type="monotone" dataKey="water" name="Consommation d'eau" stroke="#f59e0b" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}