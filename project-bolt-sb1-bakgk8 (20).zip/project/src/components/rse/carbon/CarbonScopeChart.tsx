import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { formatRSEValue } from '../../../utils/formatters/rse';
import { CarbonScope } from '../../../types/rse';

interface CarbonScopeChartProps {
  scopes: CarbonScope[];
  total: number;
}

export function CarbonScopeChart({ scopes, total }: CarbonScopeChartProps) {
  const COLORS = ['#22c55e', '#3b82f6', '#f59e0b'];

  return (
    <div className="h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={scopes}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={100}
            fill="#8884d8"
            paddingAngle={5}
            dataKey="value"
            label={({ name, percent }) => `${name} (${(percent * 100).toFixed(1)}%)`}
          >
            {scopes.map((entry, index) => (
              <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            formatter={(value: number) => [formatRSEValue(value, 'co2'), 'Émissions']}
          />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}