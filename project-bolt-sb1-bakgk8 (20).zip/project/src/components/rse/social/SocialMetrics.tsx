import React from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useSocialMetrics } from '../../../hooks/rse/useSocialMetrics';

export function SocialMetrics() {
  const { data: metrics, isLoading } = useSocialMetrics();

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900">Indicateurs Sociaux</h3>
          <p className="mt-1 text-sm text-gray-500">
            Évolution des indicateurs sociaux clés
          </p>
        </div>

        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={metrics}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <h4 className="text-lg font-medium text-gray-900 mb-4">Égalité & Diversité</h4>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">Égalité H/F</span>
                <span className="font-medium">85%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: '85%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">Diversité</span>
                <span className="font-medium">78%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: '78%' }} />
              </div>
            </div>
          </div>
        </Card>

        <Card>
          <h4 className="text-lg font-medium text-gray-900 mb-4">Formation & Développement</h4>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-semibold text-blue-600">24h</div>
                <div className="text-sm text-blue-600">Formation moyenne</div>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-semibold text-blue-600">92%</div>
                <div className="text-sm text-blue-600">Satisfaction</div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}