import React from 'react';
import { Leaf, Users, Building2, Recycle } from 'lucide-react';
import { RSEMetricCard } from '../metrics/RSEMetricCard';
import { useRSEMetrics } from '../../../hooks/rse/useRSEMetrics';

export function RSEOverview() {
  const { data: metrics, isLoading } = useRSEMetrics();

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <RSEMetricCard
        title="Émissions CO2"
        value={metrics?.carbonEmissions || 0}
        target={metrics?.carbonTarget}
        icon={Leaf}
        format="co2"
      />
      <RSEMetricCard
        title="Égalité H/F"
        value={metrics?.genderEquality || 0}
        target={metrics?.genderTarget}
        icon={Users}
        format="percentage"
      />
      <RSEMetricCard
        title="Taux de Recyclage"
        value={metrics?.recyclingRate || 0}
        target={metrics?.recyclingTarget}
        icon={Recycle}
        format="percentage"
      />
      <RSEMetricCard
        title="Score RSE Global"
        value={metrics?.globalScore || 0}
        target={metrics?.globalTarget}
        icon={Building2}
        format="score"
      />
    </div>
  );
}