import React from 'react';
import { RSEMetricCard } from '../metrics/RSEMetricCard';
import { Leaf, Users, Building2, Recycle } from 'lucide-react';
import { RSEMetrics } from '../../../types/rse';

interface RSEMetricsGridProps {
  metrics: RSEMetrics;
}

export function RSEMetricsGrid({ metrics }: RSEMetricsGridProps) {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <RSEMetricCard
        title="Émissions CO2"
        value={metrics.carbonEmissions}
        target={metrics.carbonTarget}
        icon={Leaf}
        format="co2"
        color="green"
      />
      <RSEMetricCard
        title="Égalité H/F"
        value={metrics.genderEquality}
        target={metrics.genderTarget}
        icon={Users}
        format="percentage"
        color="blue"
      />
      <RSEMetricCard
        title="Taux de Recyclage"
        value={metrics.recyclingRate}
        target={metrics.recyclingTarget}
        icon={Recycle}
        format="percentage"
        color="green"
      />
      <RSEMetricCard
        title="Score RSE Global"
        value={metrics.globalScore}
        target={metrics.globalTarget}
        icon={Building2}
        format="score"
        color="blue"
      />
    </div>
  );
}