import React, { useState } from 'react';
import { RiskManagementOverview } from './RiskManagementOverview';
import { RiskList } from './RiskList';

export function RiskManagementSection() {
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <RiskManagementOverview 
        selectedStatus={selectedStatus}
        onStatusSelect={setSelectedStatus}
      />
      <RiskList selectedStatus={selectedStatus} />
    </div>
  );
}