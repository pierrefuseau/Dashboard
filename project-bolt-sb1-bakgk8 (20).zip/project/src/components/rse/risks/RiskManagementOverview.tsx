import React from 'react';
import { Card } from '../../common/Card';
import { AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

interface RiskManagementOverviewProps {
  selectedStatus: string | null;
  onStatusSelect: (status: string | null) => void;
}

const riskSummary = {
  identified: 12,
  treated: 10,
  inProgress: 2
};

export function RiskManagementOverview({ selectedStatus, onStatusSelect }: RiskManagementOverviewProps) {
  return (
    <Card>
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Gestion des risques</h2>
        <p className="mt-1 text-sm text-gray-500">Vue d'ensemble des risques et leur statut</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.button
          onClick={() => onStatusSelect(selectedStatus === 'identified' ? null : 'identified')}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className={`bg-orange-50 rounded-xl p-6 border transition-all ${
            selectedStatus === 'identified' 
              ? 'border-orange-400 shadow-lg' 
              : 'border-orange-100 hover:border-orange-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-gray-500">Risques identifiés</div>
              <div className="mt-2 text-3xl font-bold text-orange-600">{riskSummary.identified}</div>
            </div>
            <div className="p-3 bg-orange-100 rounded-full">
              <AlertTriangle className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </motion.button>

        <motion.button
          onClick={() => onStatusSelect(selectedStatus === 'treated' ? null : 'treated')}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className={`bg-green-50 rounded-xl p-6 border transition-all ${
            selectedStatus === 'treated' 
              ? 'border-green-400 shadow-lg' 
              : 'border-green-100 hover:border-green-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-gray-500">Risques traités</div>
              <div className="mt-2 text-3xl font-bold text-green-600">{riskSummary.treated}</div>
            </div>
            <div className="p-3 bg-green-100 rounded-full">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </motion.button>

        <motion.button
          onClick={() => onStatusSelect(selectedStatus === 'in_progress' ? null : 'in_progress')}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className={`bg-blue-50 rounded-xl p-6 border transition-all ${
            selectedStatus === 'in_progress' 
              ? 'border-blue-400 shadow-lg' 
              : 'border-blue-100 hover:border-blue-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-gray-500">En cours</div>
              <div className="mt-2 text-3xl font-bold text-blue-600">{riskSummary.inProgress}</div>
            </div>
            <div className="p-3 bg-blue-100 rounded-full">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </motion.button>
      </div>

      <div className="mt-6">
        <div className="relative pt-1">
          <div className="flex mb-2 items-center justify-between">
            <div>
              <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-100">
                Progression
              </span>
            </div>
            <div className="text-right">
              <span className="text-xs font-semibold inline-block text-green-600">
                {Math.round((riskSummary.treated / riskSummary.identified) * 100)}%
              </span>
            </div>
          </div>
          <div className="overflow-hidden h-2 mb-4 text-xs flex rounded-full bg-gray-100">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(riskSummary.treated / riskSummary.identified) * 100}%` }}
              transition={{ duration: 1, delay: 0.5 }}
              className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500"
            />
          </div>
        </div>
      </div>
    </Card>
  );
}