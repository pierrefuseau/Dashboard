import React from 'react';
import { Card } from '../../common/Card';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from 'recharts';
import { useGovernanceMetrics } from '../../../hooks/rse/useGovernanceMetrics';

export function GovernanceMetrics() {
  const { data: metrics, isLoading } = useGovernanceMetrics();

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900">Gouvernance</h3>
          <p className="mt-1 text-sm text-gray-500">
            Évaluation des pratiques de gouvernance
          </p>
        </div>

        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart cx="50%" cy="50%" outerRadius="80%" data={metrics}>
              <PolarGrid />
              <PolarAngleAxis dataKey="name" />
              <PolarRadiusAxis angle={30} domain={[0, 100]} />
              <Radar
                name="Score"
                dataKey="value"
                stroke="#22c55e"
                fill="#22c55e"
                fillOpacity={0.6}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <h4 className="text-lg font-medium text-gray-900 mb-4">Conformité & Éthique</h4>
          <div className="space-y-4">
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="text-lg font-medium text-green-800">95%</div>
              <div className="text-sm text-green-600">Conformité aux normes</div>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="text-lg font-medium text-green-800">100%</div>
              <div className="text-sm text-green-600">Formation éthique</div>
            </div>
          </div>
        </Card>

        <Card>
          <h4 className="text-lg font-medium text-gray-900 mb-4">Gestion des risques</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium text-gray-900">Risques identifiés</span>
              <span className="text-sm text-gray-600">12</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium text-gray-900">Risques traités</span>
              <span className="text-sm text-gray-600">10</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium text-gray-900">En cours</span>
              <span className="text-sm text-gray-600">2</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}