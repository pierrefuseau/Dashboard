import React from 'react';
import { cn } from '../../utils/cn';

interface TabsProps {
  defaultValue: string;
  children: React.ReactNode;
  className?: string;
  variant?: 'default' | 'sales' | 'purchasing' | 'hr' | 'logistics' | 'quality' | 'boutique' | 'rse' | 'accounting';
}

interface TabsListProps {
  children: React.ReactNode;
  className?: string;
}

interface TabsTriggerProps {
  value: string;
  children: React.ReactNode;
  className?: string;
}

interface TabsContentProps {
  value: string;
  children: React.ReactNode;
  className?: string;
}

const TabsContext = React.createContext<{
  value: string;
  onChange: (value: string) => void;
  variant: 'default' | 'sales' | 'purchasing' | 'hr' | 'logistics' | 'quality' | 'boutique' | 'rse' | 'accounting';
}>({ value: '', onChange: () => {}, variant: 'default' });

export function Tabs({ defaultValue, children, className, variant = 'default' }: TabsProps) {
  const [value, setValue] = React.useState(defaultValue);

  return (
    <TabsContext.Provider value={{ value, onChange: setValue, variant }}>
      <div className={cn('w-full', className)}>
        {children}
      </div>
    </TabsContext.Provider>
  );
}

export function TabsList({ children, className }: TabsListProps) {
  return (
    <div className={cn(
      'flex space-x-1 rounded-lg p-1 bg-white shadow-sm border border-gray-200',
      className
    )}>
      {children}
    </div>
  );
}

export function TabsTrigger({ value, children, className }: TabsTriggerProps) {
  const { value: selectedValue, onChange, variant } = React.useContext(TabsContext);
  const isSelected = value === selectedValue;

  const getVariantStyles = () => {
    switch (variant) {
      case 'sales':
        return {
          selected: 'text-blue-600 bg-blue-50',
          hover: 'hover:text-blue-700 hover:bg-blue-50/50'
        };
      case 'purchasing':
        return {
          selected: 'text-red-600 bg-red-50',
          hover: 'hover:text-red-700 hover:bg-red-50/50'
        };
      case 'hr':
        return {
          selected: 'text-violet-600 bg-violet-50',
          hover: 'hover:text-violet-700 hover:bg-violet-50/50'
        };
      case 'logistics':
        return {
          selected: 'text-orange-600 bg-orange-50',
          hover: 'hover:text-orange-700 hover:bg-orange-50/50'
        };
      case 'quality':
        return {
          selected: 'text-yellow-600 bg-yellow-50',
          hover: 'hover:text-yellow-700 hover:bg-yellow-50/50'
        };
      case 'boutique':
        return {
          selected: 'text-pink-600 bg-pink-50',
          hover: 'hover:text-pink-700 hover:bg-pink-50/50'
        };
      case 'rse':
        return {
          selected: 'text-green-600 bg-green-50',
          hover: 'hover:text-green-700 hover:bg-green-50/50'
        };
      case 'accounting':
        return {
          selected: 'text-indigo-600 bg-indigo-50',
          hover: 'hover:text-indigo-700 hover:bg-indigo-50/50'
        };
      default:
        return {
          selected: 'text-gray-900 bg-gray-100',
          hover: 'hover:text-gray-700 hover:bg-gray-50'
        };
    }
  };

  const styles = getVariantStyles();

  return (
    <button
      className={cn(
        'flex items-center space-x-2 px-4 py-2.5 text-sm font-medium rounded-md transition-all duration-200',
        isSelected ? styles.selected : styles.hover,
        className
      )}
      onClick={() => onChange(value)}
    >
      {children}
    </button>
  );
}

export function TabsContent({ value, children, className }: TabsContentProps) {
  const { value: selectedValue } = React.useContext(TabsContext);

  if (value !== selectedValue) return null;

  return (
    <div className={cn('mt-4', className)}>
      {children}
    </div>
  );
}