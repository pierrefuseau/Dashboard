import React from 'react';
import { ShoppingBag, Users, TrendingUp, Package } from 'lucide-react';
import { BoutiqueMetricCard } from './BoutiqueMetricCard';
import { useBoutiqueMetrics } from '../../../hooks/boutique/useBoutiqueMetrics';

export function BoutiqueMetrics() {
  const { dailyRevenue, monthlyRevenue, monthlyMargin, customerCount } = useBoutiqueMetrics();

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <BoutiqueMetricCard
        title="CA du jour"
        value={dailyRevenue}
        icon={ShoppingBag}
        format="currency"
        color="boutique"
      />
      <BoutiqueMetricCard
        title="Nombre de clients du jour"
        value={customerCount}
        icon={Users}
        format="number"
        color="boutique"
      />
      <BoutiqueMetricCard
        title="CA début de mois"
        value={monthlyRevenue}
        icon={TrendingUp}
        format="currency"
        color="boutique"
      />
      <BoutiqueMetricCard
        title="Marge Mensuelle"
        value={monthlyMargin}
        icon={Package}
        format="percentage"
        color="boutique"
      />
    </div>
  );
}