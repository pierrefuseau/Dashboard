import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';
import { Card } from '../../common/Card';
import { formatBoutiqueAmount, formatBoutiquePercentage } from '../../../utils/formatters/boutique';

interface BoutiqueMetricCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  format?: 'currency' | 'percentage' | 'number';
  color?: 'pink';
}

export function BoutiqueMetricCard({
  title,
  value,
  icon: Icon,
  format = 'number',
  color = 'pink'
}: BoutiqueMetricCardProps) {
  const formatValue = (val: number) => {
    if (val === 0) return 'Non disponible';
    
    switch (format) {
      case 'currency':
        return formatBoutiqueAmount(val);
      case 'percentage':
        return formatBoutiquePercentage(val);
      default:
        return val.toString();
    }
  };

  return (
    <Card className="relative transform transition-all duration-200 hover:scale-105 p-6">
      <div className="flex items-center space-x-6">
        <div className="flex-shrink-0 p-4 rounded-xl bg-pink-50">
          <Icon className="w-8 h-8 text-pink-500" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-lg font-medium text-gray-500 mb-2">{title}</p>
          <p className={`text-3xl font-bold text-pink-600 truncate`}>
            {formatValue(value)}
          </p>
        </div>
      </div>
    </Card>
  );
}