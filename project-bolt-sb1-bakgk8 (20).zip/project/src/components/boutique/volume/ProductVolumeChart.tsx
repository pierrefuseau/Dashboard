import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ChartModal } from '../../common/ChartModal';
import { Card } from '../../common/Card';
import { Maximize2 } from 'lucide-react';

const mockData = [
  { name: 'Produit A', volume: 250 },
  { name: 'Produit B', volume: 196 },
  { name: 'Produit C', volume: 150 },
  { name: 'Produit D', volume: 124 },
  { name: 'Produit E', volume: 108 }
];

export function ProductVolumeChart() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const renderChart = (height: number = 400) => (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={mockData} margin={{ top: 20, right: 30, left: 40, bottom: 60 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
        <XAxis
          dataKey="name"
          tick={{ fontSize: 12, fill: '#4B5563' }}
          angle={-30}
          textAnchor="end"
          interval={0}
          height={60}
        />
        <YAxis
          tick={{ fontSize: 12, fill: '#4B5563' }}
          width={60}
        />
        <Tooltip
          formatter={(value: number) => [`${value} unités`, 'Volume']}
          contentStyle={{
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            border: 'none',
            borderRadius: '8px',
            padding: '12px',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
          }}
        />
        <Bar
          dataKey="volume"
          fill="#fbcfe8"
          radius={[4, 4, 0, 0]}
          barSize={40}
        />
      </BarChart>
    </ResponsiveContainer>
  );

  return (
    <Card>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium text-gray-900">Volume des Ventes par Produit</h3>
        <button
          onClick={() => setIsModalOpen(true)}
          className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
        >
          <Maximize2 className="h-5 w-5" />
        </button>
      </div>
      <div className="h-[400px]">
        {renderChart()}
      </div>

      <ChartModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Volume des Ventes par Produit"
      >
        {renderChart(600)}
      </ChartModal>
    </Card>
  );
}