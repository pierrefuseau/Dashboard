import React from 'react';
import { Card } from '../../common/Card';
import { useSheetData } from '../../../hooks/sheets/useSheetData';

export function BoutiquePerformanceCharts() {
  // Données CA (B19:C28)
  const { data: revenueData } = useSheetData('BOUTIQUE', 'B19:C28', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 100 || 0
    }))
  });

  // Données Marge (B31:C40)
  const { data: marginData } = useSheetData('BOUTIQUE', 'B31:C40', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      margin: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 100 || 0
    }))
  });

  // Données Volume (E19:F28)
  const { data: volumeData } = useSheetData('BOUTIQUE', 'E19:F28', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      volume: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
    }))
  });

  return (
    <div className="grid grid-cols-1 gap-6">
      {/* Top CA */}
      <Card>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Top CA</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Produit
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  CA
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {revenueData?.map((item, index) => (
                <tr key={item.name} className={index === 0 ? 'bg-boutique-50' : ''}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                    {new Intl.NumberFormat('fr-FR', {
                      style: 'currency',
                      currency: 'EUR',
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }).format(item.revenue)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Top Marge */}
      <Card>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Top Marge</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Produit
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Marge
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {marginData?.map((item, index) => (
                <tr key={item.name} className={index === 0 ? 'bg-boutique-50' : ''}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                    {`${item.margin.toFixed(2)}%`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Top Volume */}
      <Card>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Top Volume</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Produit
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Volume
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {volumeData?.map((item, index) => (
                <tr key={item.name} className={index === 0 ? 'bg-boutique-50' : ''}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                    {Math.round(item.volume).toLocaleString('fr-FR')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}