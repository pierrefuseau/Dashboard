import React, { useState } from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { ChartModal } from '../../common/ChartModal';
import { Maximize2 } from 'lucide-react';

export function BoutiquePerformanceChart() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Récupération des données de marge (B31:C40)
  const { data: marginData } = useSheetData('BOUTIQUE', 'B31:C40', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      margin: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 100 || 0
    }))
  });

  // Récupération des données de volume (E19:F28)
  const { data: volumeData } = useSheetData('BOUTIQUE', 'E19:F28', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      volume: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 100 || 0
    }))
  });

  // Fusion des données
  const combinedData = marginData?.map(marginItem => {
    const volumeItem = volumeData?.find(v => v.name === marginItem.name);
    return {
      name: marginItem.name,
      margin: marginItem.margin,
      volume: volumeItem?.volume || 0
    };
  }).filter(item => item.name && (item.margin > 0 || item.volume > 0));

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('fr-FR', { 
      style: 'currency', 
      currency: 'EUR',
      maximumFractionDigits: 0
    }).format(value);

  const formatVolume = (value: number) => 
    `${value.toFixed(0)} unités`;

  const renderChart = (height: number = 400) => (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart 
        data={combinedData} 
        margin={{ top: 20, right: 60, left: 40, bottom: 80 }}
        barGap={0}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
        
        <XAxis
          dataKey="name"
          tick={{ fontSize: 12, fill: '#4B5563' }}
          angle={-45}
          textAnchor="end"
          interval={0}
          height={80}
        />
        
        <YAxis
          yAxisId="left"
          tickFormatter={formatCurrency}
          tick={{ fontSize: 12, fill: '#4B5563' }}
          label={{ 
            value: 'Marge', 
            angle: -90, 
            position: 'insideLeft',
            style: { textAnchor: 'middle', fill: '#4B5563', fontSize: 12 }
          }}
        />
        
        <YAxis
          yAxisId="right"
          orientation="right"
          tickFormatter={formatVolume}
          tick={{ fontSize: 12, fill: '#4B5563' }}
          label={{ 
            value: 'Volume', 
            angle: 90, 
            position: 'insideRight',
            style: { textAnchor: 'middle', fill: '#4B5563', fontSize: 12 }
          }}
        />
        
        <Tooltip
          formatter={(value: number, name: string) => [
            name === 'volume' ? formatVolume(value) : formatCurrency(value),
            name === 'margin' ? 'Marge' : 'Volume'
          ]}
          contentStyle={{
            backgroundColor: 'white',
            border: '1px solid #E5E7EB',
            borderRadius: '0.5rem',
            padding: '12px'
          }}
        />
        
        <Legend />
        
        <Bar
          yAxisId="left"
          dataKey="margin"
          name="Marge"
          fill="#ec4899"
          radius={[4, 4, 0, 0]}
          barSize={30}
        />
        
        <Bar
          yAxisId="right"
          dataKey="volume"
          name="Volume"
          fill="#fbcfe8"
          radius={[4, 4, 0, 0]}
          barSize={30}
        />
      </BarChart>
    </ResponsiveContainer>
  );

  return (
    <Card>
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Performance des Produits</h3>
          <p className="text-sm text-gray-500">Marge et volume par produit</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
        >
          <Maximize2 className="h-5 w-5" />
        </button>
      </div>
      
      <div className="h-[400px]">
        {renderChart()}
      </div>

      <ChartModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Performance des Produits"
      >
        {renderChart(600)}
      </ChartModal>
    </Card>
  );
}