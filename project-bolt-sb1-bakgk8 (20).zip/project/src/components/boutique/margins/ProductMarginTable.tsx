import React from 'react';
import { Card } from '../../common/Card';
import { TrendingUp, Award } from 'lucide-react';
import { useTopMargins } from '../../../hooks/boutique/useTopMargins';

export function ProductMarginTable() {
  const { data: margins, isLoading } = useTopMargins();

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  const maxMargin = Math.max(...(margins?.map(p => p.margin) || [0]));

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Top Marge par Produit</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-boutique-100">
          <thead className="bg-boutique-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-boutique-600 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-boutique-600 uppercase tracking-wider">
                Marge
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-boutique-600 uppercase tracking-wider">
                Performance
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-boutique-100">
            {margins?.map((product, index) => {
              const isTopPerformer = index === 0;
              const percentage = (product.margin / maxMargin) * 100;
              
              return (
                <tr 
                  key={product.name}
                  className={`
                    transition-colors duration-150 hover:bg-boutique-50
                    ${isTopPerformer ? 'bg-boutique-50' : ''}
                  `}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`
                        flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                        ${isTopPerformer ? 'bg-boutique-100' : 'bg-gray-100'}
                      `}>
                        {isTopPerformer ? (
                          <Award className="h-5 w-5 text-boutique-600" />
                        ) : (
                          <TrendingUp className="h-5 w-5 text-gray-400" />
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {product.name}
                        </div>
                        {isTopPerformer && (
                          <div className="text-xs text-boutique-600">
                            Meilleure marge
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {product.margin.toFixed(2)}%
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-grow">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-boutique-500 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}