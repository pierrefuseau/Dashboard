import React from 'react';
import { Card } from '../../common/Card';
import { useSheetData } from '../../../hooks/sheets/useSheetData';

export function TopMarginsTable() {
  const { data: margins } = useSheetData('BOUTIQUE', 'B31:C40', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      margin: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 100 || 0
    }))
  });

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Top Produits - Marge</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Marge
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {margins?.map((product, index) => (
              <tr 
                key={product.name}
                className={`hover:bg-boutique-50 transition-colors duration-150 ${
                  index === 0 ? 'bg-boutique-50' : ''
                }`}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {product.name}
                      </div>
                      {index === 0 && (
                        <div className="text-xs text-boutique-600">
                          Meilleure marge
                        </div>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  <div className="text-sm text-gray-900">
                    {`${product.margin.toFixed(2)}%`}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}