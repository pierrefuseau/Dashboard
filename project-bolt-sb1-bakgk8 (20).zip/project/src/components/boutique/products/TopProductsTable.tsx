import React from 'react';
import { Card } from '../../common/Card';
import { useSheetData } from '../../../hooks/sheets/useSheetData';

export function TopProductsTable() {
  const { data: products } = useSheetData('BOUTIQUE', 'B19:C28', {
    transform: (data) => data.map(row => ({
      name: row[0] || '',
      revenue: Number(row[1]?.replace(/[^0-9.-]/g, '')) / 100 || 0
    }))
  });

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Top Produits - CA</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produit
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                CA
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {products?.map((product, index) => (
              <tr 
                key={product.name}
                className={`hover:bg-boutique-50 transition-colors duration-150 ${
                  index === 0 ? 'bg-boutique-50' : ''
                }`}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {product.name}
                      </div>
                      {index === 0 && (
                        <div className="text-xs text-boutique-600">
                          Meilleure vente
                        </div>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  <div className="text-sm text-gray-900">
                    {new Intl.NumberFormat('fr-FR', {
                      style: 'currency',
                      currency: 'EUR',
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }).format(product.revenue)}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}