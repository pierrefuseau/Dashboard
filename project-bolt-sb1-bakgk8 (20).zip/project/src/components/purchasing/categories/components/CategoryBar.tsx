import React from 'react';
import { motion } from 'framer-motion';
import { Category } from '../types';

interface CategoryBarProps {
  category: Category;
  index: number;
  height: number;
  isHovered: boolean;
  onHover: (name: string | null) => void;
}

export function CategoryBar({ category, index, height, isHovered, onHover }: CategoryBarProps) {
  const delay = index * 0.2;

  return (
    <div className="relative w-32">
      <motion.div
        className={`absolute inset-0 rounded-t-lg bg-gradient-to-br ${category.color}`}
        initial={{ opacity: 0 }}
        animate={{ opacity: isHovered ? 0.9 : 0.7 }}
        transition={{ duration: 0.2 }}
        style={{
          height: `${height}px`,
          transformStyle: 'preserve-3d',
          transform: 'translateZ(20px)',
          boxShadow: '0 0 20px rgba(0,0,0,0.1)'
        }}
        onMouseEnter={() => onHover(category.name)}
        onMouseLeave={() => onHover(null)}
      >
        {/* Icône de catégorie */}
        <div className="absolute -top-8 left-1/2 -translate-x-1/2 p-3 rounded-full bg-white/90 shadow-lg">
          <category.icon className="w-6 h-6 text-gray-600" />
        </div>
      </motion.div>
    </div>
  );
}