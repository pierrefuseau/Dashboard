import React from 'react';
import { Category } from '../types';

interface CategoryLegendProps {
  categories: Category[];
}

export function CategoryLegend({ categories }: CategoryLegendProps) {
  return (
    <div className="mt-16 grid grid-cols-3 gap-4">
      {categories.map((category, index) => (
        <div key={category.name} className="text-center">
          <div className="text-sm font-medium text-gray-900">
            {index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉'} {category.name}
          </div>
          <div className="text-xs text-gray-500 mt-1">
            {category.percentage.toFixed(1)}% du total
          </div>
        </div>
      ))}
    </div>
  );
}