import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { TooltipData } from '../types';

interface CategoryTooltipProps {
  data: TooltipData;
}

export function CategoryTooltip({ data }: CategoryTooltipProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="absolute -top-24 left-1/2 -translate-x-1/2 bg-white px-4 py-2 rounded-lg shadow-xl border border-gray-100 z-10"
    >
      <div className="text-sm font-semibold text-gray-900">{data.name}</div>
      <div className="text-sm text-gray-600">{formatCurrency(data.value)}</div>
      <div className="text-xs text-gray-500">{data.percentage.toFixed(1)}% du total</div>
    </motion.div>
  );
}