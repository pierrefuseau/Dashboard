import { useSheetData } from '../../../../hooks/sheets/useSheetData';
import { Category } from '../types';
import { CATEGORY_CONFIGS, DEFAULT_CONFIG } from '../config/categoryConfig';

export function useCategoryData() {
  return useSheetData('ACHATS', 'E3:F5', {
    transform: (data) => {
      const items = data.map(row => ({
        name: row[0] || '',
        value: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
      }))
      .filter(item => item.name && item.value > 0)
      .sort((a, b) => b.value - a.value)
      .slice(0, 3);

      const total = items.reduce((sum, item) => sum + item.value, 0);

      return items.map(item => ({
        ...item,
        percentage: (item.value / total) * 100,
        ...CATEGORY_CONFIGS[item.name] || DEFAULT_CONFIG
      }));
    }
  });
}