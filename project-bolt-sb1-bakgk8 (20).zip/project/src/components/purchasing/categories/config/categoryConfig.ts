import { CandyCane, Cookie, Milk } from 'lucide-react';
import { CategoryConfig } from '../types';

export const CATEGORY_CONFIGS: Record<string, CategoryConfig> = {
  'SUCRE': {
    icon: CandyCane,
    color: 'from-blue-400 to-blue-600'
  },
  'CHOCOLAT': {
    icon: Cookie,
    color: 'from-amber-700 to-amber-900'
  },
  'BEURRE': {
    icon: Milk,
    color: 'from-yellow-400 to-yellow-600'
  }
};

export const DEFAULT_CONFIG: CategoryConfig = {
  icon: Cookie,
  color: 'from-gray-400 to-gray-600'
};