import React, { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Card } from '../../common/Card';
import { formatCurrency } from '../../../utils/formatters/currency';
import { useCategoryData } from './hooks/useCategoryData';
import { CategoryBar } from './components/CategoryBar';
import { CategoryTooltip } from './components/CategoryTooltip';
import { CategoryLegend } from './components/CategoryLegend';
import { LoadingSpinner } from '../../common/LoadingSpinner';

export function ProductCategoriesChart() {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);
  const { data: categories, isLoading } = useCategoryData();

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-96">
          <LoadingSpinner />
        </div>
      </Card>
    );
  }

  if (!categories?.length) {
    return null;
  }

  const totalValue = categories.reduce((sum, cat) => sum + cat.value, 0);

  return (
    <Card>
      <div className="mb-8">
        <h3 className="text-xl font-semibold text-gray-900 text-center">
          Top 3 des Catégories par Montant d'Achats
        </h3>
        <p className="mt-2 text-sm text-gray-500 text-center">
          Total des achats : {formatCurrency(totalValue)}
        </p>
      </div>

      <div className="relative h-[400px] bg-gradient-to-b from-gray-50 to-white rounded-xl overflow-hidden">
        {/* Effet de brillance */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white/20 via-transparent to-transparent"></div>

        {/* Podium */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[90%] h-24 bg-gradient-to-b from-gray-200/50 to-gray-300/50 rounded-t-lg"></div>

        <div className="relative h-full flex items-end justify-center space-x-8 pb-24">
          {categories.map((category, index) => {
            const height = 200 + (index === 0 ? 80 : index === 1 ? 40 : 0);
            const isHovered = hoveredCategory === category.name;

            return (
              <div key={category.name} className="relative">
                <CategoryBar
                  category={category}
                  index={index}
                  height={height}
                  isHovered={isHovered}
                  onHover={setHoveredCategory}
                />

                <AnimatePresence>
                  {isHovered && (
                    <CategoryTooltip data={category} />
                  )}
                </AnimatePresence>

                {/* Étiquette */}
                <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 w-full text-center">
                  <div className="text-sm font-medium text-gray-900">{category.name}</div>
                  <div className="text-xs text-gray-500">{formatCurrency(category.value)}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <CategoryLegend categories={categories} />
    </Card>
  );
}