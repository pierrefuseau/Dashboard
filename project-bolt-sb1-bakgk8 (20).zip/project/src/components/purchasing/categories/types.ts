export interface Category {
  name: string;
  value: number;
  percentage: number;
  icon: React.ElementType;
  color: string;
}

export interface CategoryConfig {
  icon: React.ElementType;
  color: string;
}

export interface TooltipData {
  name: string;
  value: number;
  percentage: number;
}