import React from 'react';
import { LucideIcon } from 'lucide-react';
import { Card } from '../../common/Card';
import { formatCurrency, formatMillionsEuros } from '../../../utils/formatters/currency';

interface PurchaseMetricCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  format?: 'currency' | 'millions' | 'percentage' | 'volume' | 'number';
  color?: 'red' | 'green' | 'blue' | 'orange';
}

export function PurchaseMetricCard({
  title,
  value,
  icon: Icon,
  format = 'number',
  color = 'red'
}: PurchaseMetricCardProps) {
  const formatValue = (val: number) => {
    if (isNaN(val)) return 'N/A';
    
    switch (format) {
      case 'currency':
        return formatCurrency(val);
      case 'millions':
        return formatMillionsEuros(val);
      case 'percentage':
        return `${val.toFixed(1)}%`;
      case 'volume':
        // Arrondir à l'entier le plus proche
        return `${Math.round(val).toLocaleString('fr-FR')} T`;
      case 'number':
        return val.toLocaleString('fr-FR');
      default:
        return val.toString();
    }
  };

  const getColorClasses = (colorName: string) => {
    switch (colorName) {
      case 'green':
        return { bg: 'bg-green-50', text: 'text-green-600' };
      case 'blue':
        return { bg: 'bg-blue-50', text: 'text-blue-600' };
      case 'orange':
        return { bg: 'bg-orange-50', text: 'text-orange-600' };
      default:
        return { bg: 'bg-red-50', text: 'text-red-600' };
    }
  };

  const colorClasses = getColorClasses(color);

  return (
    <Card className="relative">
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-gray-500 truncate">{title}</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900 truncate">
            {formatValue(value)}
          </p>
        </div>
        <div className={`flex-shrink-0 p-3 rounded-full ${colorClasses.bg}`}>
          <Icon className={`w-6 h-6 ${colorClasses.text}`} />
        </div>
      </div>
    </Card>
  );
}