import React from 'react';
import { Package, ShoppingCart, TrendingDown, Receipt } from 'lucide-react';
import { PurchaseMetricCard } from './PurchaseMetricCard';
import { useSheetData } from '../../../hooks/sheets/useSheetData';

export function PurchaseOverview() {
  const { data: metrics, isLoading } = useSheetData('ACHATS', 'C2:C3', {
    transform: (data) => ({
      totalAmount: Number(data?.[0]?.[0]?.replace(/[^0-9.-]/g, '')) || 0,
      totalVolume: Number(data?.[1]?.[0]?.replace(/[^0-9.-]/g, '')) || 0
    })
  });

  const { data: rfaValues } = useSheetData('ACHATS', 'B7:C7', {
    transform: (data) => ({
      rfaN: Number(data?.[0]?.[0]?.replace(/[^0-9.-]/g, '')) || 0,
      rfaN1: Number(data?.[0]?.[1]?.replace(/[^0-9.-]/g, '')) || 0
    })
  });

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <PurchaseMetricCard
        title="Volume Acheté"
        value={metrics?.totalVolume || 0}
        icon={Package}
        format="volume"
        color="red"
      />
      <PurchaseMetricCard
        title="Montant Achats"
        value={metrics?.totalAmount || 0}
        icon={ShoppingCart}
        format="currency"
        color="red"
      />
      <PurchaseMetricCard
        title="RFA N"
        value={rfaValues?.rfaN || 0}
        icon={Receipt}
        format="currency"
        color="red"
      />
      <PurchaseMetricCard
        title="RFA N-1"
        value={rfaValues?.rfaN1 || 0}
        icon={TrendingDown}
        format="currency"
        color="red"
      />
    </div>
  );
}