import React from 'react';
import { Package } from 'lucide-react';
import { Card } from '../../common/Card';
import { formatTonnage } from '../../../utils/formatters/tonnage';
import { usePurchaseVolume } from '../../../hooks/purchases/usePurchaseVolume';

export function VolumeMetricCard() {
  const { data: volume, isLoading } = usePurchaseVolume();

  return (
    <Card className="relative">
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1 pr-4">
          <p className="text-sm font-medium text-gray-500 truncate">Volume Acheté</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900 truncate">
            {isLoading ? 'Chargement...' : formatTonnage(volume || 0)}
          </p>
        </div>
        <div className="flex-shrink-0 p-3 rounded-full bg-red-50">
          <Package className="w-6 h-6 text-red-600" />
        </div>
      </div>
    </Card>
  );
}