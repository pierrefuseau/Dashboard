import React from 'react';
import { Card } from '../../common/Card';
import { useSheetData } from '../../../hooks/sheets/useSheetData';

export function PurchaseAnalysisTable() {
  const { data: purchaseData, isLoading } = useSheetData('ACHATS', 'B2:C3', {
    transform: (data) => ({
      amount: Number(data?.[0]?.[1]?.replace(/[^0-9.-]/g, '')) || 0,
      volume: Number(data?.[1]?.[1]?.replace(/[^0-9.-]/g, '')) || 0
    })
  });

  const { data: rfaData } = useSheetData('ACHATS', 'B7:C7', {
    transform: (data) => ({
      rfaCurrent: Number(data?.[0]?.[0]?.replace(/[^0-9.-]/g, '')) || 0,
      rfaPrevious: Number(data?.[0]?.[1]?.replace(/[^0-9.-]/g, '')) || 0
    })
  });

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  const formatVolume = (value: number) => {
    const tonnes = value / 1000; // Conversion en tonnes
    return {
      value: tonnes.toFixed(2),
      unit: 'T'
    };
  };

  const formatAmount = (value: number) => {
    const millions = value / 1000000; // Conversion en millions
    return `${millions.toFixed(3)} M€`;
  };

  const formatRFA = (value: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0
    }).format(value);
  };

  return (
    <Card title="Analyse des Achats">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Indicateur
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Valeur
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Unité
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {/* Volume */}
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                Volume Total
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">
                {formatVolume(purchaseData?.volume || 0).value}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {formatVolume(purchaseData?.volume || 0).unit}
              </td>
            </tr>

            {/* Montant */}
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                Montant Total
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right" colSpan={2}>
                {formatAmount(purchaseData?.amount || 0)}
              </td>
            </tr>

            {/* RFA N */}
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                RFA N
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right" colSpan={2}>
                {formatRFA(rfaData?.rfaCurrent || 0)}
              </td>
            </tr>

            {/* RFA N-1 */}
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                RFA N-1
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right" colSpan={2}>
                {formatRFA(rfaData?.rfaPrevious || 0)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </Card>
  );
}