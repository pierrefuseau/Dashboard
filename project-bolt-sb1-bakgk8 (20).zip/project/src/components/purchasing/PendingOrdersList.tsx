import React from 'react';
import { Clock, CheckCircle, AlertTriangle } from 'lucide-react';

const data = [
  {
    id: 'CMD-001',
    fournisseur: 'Fournisseur A',
    montant: '€12,500',
    statut: 'en_attente',
    dateLivraison: '2024-03-15'
  },
  {
    id: 'CMD-002',
    fournisseur: 'Fournisseur B',
    montant: '€8,750',
    statut: 'confirmee',
    dateLivraison: '2024-03-12'
  },
  {
    id: 'CMD-003',
    fournisseur: 'Fournisseur C',
    montant: '€15,200',
    statut: 'retard',
    dateLivraison: '2024-03-10'
  }
];

const statutConfig = {
  en_attente: { icon: Clock, className: 'text-yellow-500', text: 'En attente' },
  confirmee: { icon: CheckCircle, className: 'text-green-500', text: 'Confirmée' },
  retard: { icon: AlertTriangle, className: 'text-red-500', text: 'En retard' }
};

export function PendingOrdersList() {
  return (
    <div className="space-y-4">
      {data.map((order) => {
        const StatusIcon = statutConfig[order.statut].icon;
        
        return (
          <div
            key={order.id}
            className="bg-gray-50 rounded-lg p-4 flex items-center justify-between"
          >
            <div className="flex-1">
              <div className="flex items-center">
                <span className="font-medium text-gray-900">{order.id}</span>
                <span className="mx-2 text-gray-300">•</span>
                <span className="text-gray-500">{order.fournisseur}</span>
              </div>
              <div className="mt-1 text-sm text-gray-500">
                Livraison prévue : {new Date(order.dateLivraison).toLocaleDateString('fr-FR')}
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="font-medium text-gray-900">{order.montant}</span>
              <div className={`flex items-center ${statutConfig[order.statut].className}`}>
                <StatusIcon className="w-4 h-4 mr-1" />
                <span className="text-sm">{statutConfig[order.statut].text}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}