```typescript
import { useState } from 'react';
import { useSheetData } from '../../../../../hooks/sheets/useSheetData';
import { Supplier, SupplierFiltersState } from '../types';

const initialFilters: SupplierFiltersState = {
  search: '',
  status: 'active'
};

export function useSupplierData() {
  const [filters, setFilters] = useState<SupplierFiltersState>(initialFilters);

  const { data: rawSuppliers, isLoading } = useSheetData('ACHATS', 'B37:D46', {
    transform: (data) => data.map(row => ({
      code: row[0]?.toString().split(' - ')[0] || '',
      name: row[0]?.toString().split(' - ')[1] || '',
      amount: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0,
      volume: Number(row[2]?.replace(/[^0-9.-]/g, '')) || 0,
      performance: Math.round(Math.random() * 30) + 70, // Simulé pour l'exemple
      status: 'active' as const,
      category: 'Standard',
      deliveryRate: Math.round(Math.random() * 20) + 80, // Simulé
      qualityScore: Math.round(Math.random() * 20) + 80 // Simulé
    }))
  });

  // Appliquer les filtres
  const suppliers = rawSuppliers?.filter(supplier => {
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      const matchesSearch = 
        supplier.name.toLowerCase().includes(searchTerm) ||
        supplier.code.toLowerCase().includes(searchTerm);
      if (!matchesSearch) return false;
    }

    if (filters.minAmount && supplier.amount < filters.minAmount) return false;
    if (filters.maxAmount && supplier.amount > filters.maxAmount) return false;
    if (filters.minVolume && supplier.volume < filters.minVolume) return false;
    if (filters.maxVolume && supplier.volume > filters.maxVolume) return false;
    if (filters.status && supplier.status !== filters.status) return false;
    if (filters.category && supplier.category !== filters.category) return false;
    if (filters.performanceThreshold && supplier.performance < filters.performanceThreshold) return false;

    return true;
  });

  return {
    data: suppliers,
    isLoading,
    filters,
    setFilters
  };
}
```