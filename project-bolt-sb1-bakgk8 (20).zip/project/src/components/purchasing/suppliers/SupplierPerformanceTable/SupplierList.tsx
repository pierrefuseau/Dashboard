```tsx
import React from 'react';
import { Package, Award, TrendingUp, TrendingDown } from 'lucide-react';
import { Supplier } from './types';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { cn } from '../../../../utils/cn';

interface SupplierListProps {
  suppliers: Supplier[];
  isLoading: boolean;
  onSelect: (supplier: Supplier) => void;
  onCompare: () => void;
}

export function SupplierList({ suppliers, isLoading, onSelect, onCompare }: SupplierListProps) {
  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-20 bg-gray-100 rounded-lg" />
        ))}
      </div>
    );
  }

  const maxAmount = Math.max(...suppliers.map(s => s.amount));
  const maxVolume = Math.max(...suppliers.map(s => s.volume));

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Fournisseur
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              Montant PR
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              Volume (KG)
            </th>
            <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
              Performance
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {suppliers.map((supplier, index) => {
            const isTopSupplier = index === 0;
            const amountPercentage = (supplier.amount / maxAmount) * 100;
            const volumePercentage = (supplier.volume / maxVolume) * 100;
            
            return (
              <tr 
                key={supplier.code}
                onClick={() => onSelect(supplier)}
                className={cn(
                  "hover:bg-red-50 transition-colors duration-150 cursor-pointer",
                  isTopSupplier && "bg-red-50"
                )}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className={cn(
                      "flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center",
                      isTopSupplier ? "bg-red-100" : "bg-gray-100"
                    )}>
                      {isTopSupplier ? (
                        <Award className="h-5 w-5 text-red-600" />
                      ) : (
                        <Package className="h-5 w-5 text-gray-400" />
                      )}
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">
                        {supplier.code} - {supplier.name}
                      </div>
                      {isTopSupplier && (
                        <div className="text-xs text-red-600">
                          Fournisseur principal
                        </div>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(supplier.amount)}
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                      <div
                        className="bg-red-600 h-1.5 rounded-full transition-all duration-500"
                        style={{ width: `${amountPercentage}%` }}
                      />
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">
                      {supplier.volume.toLocaleString('fr-FR')}
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                      <div
                        className="bg-red-600 h-1.5 rounded-full transition-all duration-500"
                        style={{ width: `${volumePercentage}%` }}
                      />
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center justify-center">
                    <div className={cn(
                      "flex items-center space-x-1 px-2 py-1 rounded-full text-sm",
                      supplier.performance >= 90 ? "bg-green-100 text-green-800" :
                      supplier.performance >= 75 ? "bg-yellow-100 text-yellow-800" :
                      "bg-red-100 text-red-800"
                    )}>
                      {supplier.performance >= 75 ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                      <span>{supplier.performance}%</span>
                    </div>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
```