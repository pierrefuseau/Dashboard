```tsx
import React, { useState } from 'react';
import { Card } from '../../../common/Card';
import { SupplierList } from './SupplierList';
import { SupplierSearch } from './SupplierSearch';
import { SupplierFilters } from './SupplierFilters';
import { SupplierDetails } from './SupplierDetails';
import { SupplierComparison } from './SupplierComparison';
import { useSupplierData } from './hooks/useSupplierData';
import { Download, SlidersHorizontal } from 'lucide-react';
import { exportToCSV } from '../../../../utils/export/csvExport';
import { Supplier } from './types';

export function SupplierPerformanceTable() {
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [showComparison, setShowComparison] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const { data: suppliers, isLoading, filters, setFilters } = useSupplierData();

  const handleExport = () => {
    if (!suppliers) return;
    
    const headers = ['Code', 'Fournisseur', 'Montant PR', 'Volume (KG)', 'Performance'];
    const data = suppliers.map(supplier => [
      supplier.code,
      supplier.name,
      supplier.amount.toString(),
      supplier.volume.toString(),
      `${supplier.performance}%`
    ]);
    
    exportToCSV(data, headers, 'performance-fournisseurs');
  };

  return (
    <Card>
      <div className="mb-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium text-gray-900">Performance Fournisseurs</h3>
            <p className="mt-1 text-sm text-gray-500">
              Analyse détaillée des performances de nos fournisseurs
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
            >
              <SlidersHorizontal className="w-5 h-5" />
            </button>
            <button
              onClick={handleExport}
              className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
            >
              <Download className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="mt-4 space-y-4">
          <SupplierSearch onSearch={(term) => setFilters({ ...filters, search: term })} />
          
          {showFilters && (
            <SupplierFilters 
              filters={filters} 
              onChange={setFilters} 
              onClose={() => setShowFilters(false)} 
            />
          )}
        </div>
      </div>

      <SupplierList
        suppliers={suppliers || []}
        isLoading={isLoading}
        onSelect={setSelectedSupplier}
        onCompare={() => setShowComparison(true)}
      />

      {selectedSupplier && (
        <SupplierDetails
          supplier={selectedSupplier}
          onClose={() => setSelectedSupplier(null)}
        />
      )}

      {showComparison && (
        <SupplierComparison
          suppliers={suppliers || []}
          onClose={() => setShowComparison(false)}
        />
      )}
    </Card>
  );
}
```