```typescript
export interface Supplier {
  code: string;
  name: string;
  amount: number;
  volume: number;
  performance: number;
  status: 'active' | 'inactive';
  category: string;
  deliveryRate: number;
  qualityScore: number;
  lastOrder?: Date;
}

export interface SupplierFiltersState {
  search: string;
  minAmount?: number;
  maxAmount?: number;
  minVolume?: number;
  maxVolume?: number;
  status?: 'active' | 'inactive';
  category?: string;
  performanceThreshold?: number;
}
```