import React from 'react';
import { Card } from '../../common/Card';
import { Package, Award } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { formatCurrency } from '../../../utils/formatters/currency';

export function SupplierPerformanceTable() {
  const { data: suppliers, isLoading } = useSheetData('ACHATS', 'B37:D46', {
    transform: (data) => data
      .filter(row => row[0] && row[1]) // Filter out empty rows
      .map((row, index) => {
        // Split the code and name if they're combined
        const [code, ...nameParts] = (row[0] || '').toString().split(' - ');
        const name = nameParts.join(' - ');
        
        return {
          id: `supplier-${index}-${code}`, // Create a unique ID using index and code
          code,
          name,
          amount: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0,
          volume: Number(row[2]?.replace(/[^0-9.-]/g, '')) || 0
        };
      })
      .filter(supplier => supplier.code && supplier.amount > 0)
  });

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
        </div>
      </Card>
    );
  }

  const totalAmount = suppliers?.reduce((sum, supplier) => sum + supplier.amount, 0) || 0;
  const totalVolume = suppliers?.reduce((sum, supplier) => sum + supplier.volume, 0) || 0;

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Performance Fournisseurs</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Fournisseur
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Montant PR
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Volume (kg)
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {suppliers?.map((supplier, index) => {
              const isTopPerformer = index === 0;
              
              return (
                <tr 
                  key={supplier.id} // Use the unique ID we created
                  className={`hover:bg-red-50 transition-colors duration-150 ${
                    isTopPerformer ? 'bg-red-50' : ''
                  }`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`
                        flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                        ${isTopPerformer ? 'bg-red-100' : 'bg-gray-100'}
                      `}>
                        {isTopPerformer ? (
                          <Award className="h-5 w-5 text-red-600" />
                        ) : (
                          <Package className="h-5 w-5 text-gray-400" />
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {supplier.code} - {supplier.name}
                        </div>
                        {isTopPerformer && (
                          <div className="text-xs text-red-600">
                            Fournisseur principal
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm text-gray-900">{formatCurrency(supplier.amount)}</div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                      <div 
                        className="bg-red-600 h-1.5 rounded-full" 
                        style={{ width: `${(supplier.amount / totalAmount) * 100}%` }}
                      />
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm text-gray-900">{supplier.volume.toLocaleString('fr-FR')}</div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                      <div 
                        className="bg-orange-600 h-1.5 rounded-full" 
                        style={{ width: `${(supplier.volume / totalVolume) * 100}%` }}
                      />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}