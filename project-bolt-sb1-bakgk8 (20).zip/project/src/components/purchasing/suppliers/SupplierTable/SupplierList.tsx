```tsx
import React from 'react';
import { Award, Package, AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';
import { Supplier } from './types';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { cn } from '../../../../utils/cn';

interface SupplierListProps {
  suppliers: Supplier[];
  selectedSuppliers: Supplier[];
  onSelect: (supplier: Supplier) => void;
  onShowDetails: () => void;
  isLoading: boolean;
}

export function SupplierList({
  suppliers,
  selectedSuppliers,
  onSelect,
  onShowDetails,
  isLoading
}: SupplierListProps) {
  if (isLoading) {
    return <SupplierListSkeleton />;
  }

  const maxAmount = Math.max(...suppliers.map(s => s.amount));
  const maxVolume = Math.max(...suppliers.map(s => s.volume));

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="w-12 px-4 py-3"></th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
              Fournisseur
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
              Montant PR
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
              Volume
            </th>
            <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">
              Performance
            </th>
            <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">
              Alertes
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {suppliers.map((supplier, index) => (
            <motion.tr
              key={supplier.code}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              onClick={() => onSelect(supplier)}
              className={cn(
                "hover:bg-red-50 cursor-pointer transition-colors",
                selectedSuppliers.includes(supplier) && "bg-red-50",
                index < 3 && "bg-red-50/50"
              )}
            >
              <td className="px-4 py-4">
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center",
                  index === 0 ? "bg-red-100" : "bg-gray-100"
                )}>
                  {index === 0 ? (
                    <Award className="w-4 h-4 text-red-600" />
                  ) : (
                    <Package className="w-4 h-4 text-gray-400" />
                  )}
                </div>
              </td>
              <td className="px-6 py-4">
                <div>
                  <div className="text-sm font-medium text-gray-900">
                    {supplier.name}
                  </div>
                  <div className="text-sm text-gray-500">
                    {supplier.code}
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="text-right space-y-1">
                  <div className="text-sm font-medium text-gray-900">
                    {formatCurrency(supplier.amount)}
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(supplier.amount / maxAmount) * 100}%` }}
                      className="bg-red-600 h-1 rounded-full"
                      transition={{ duration: 1, delay: index * 0.1 }}
                    />
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="text-right space-y-1">
                  <div className="text-sm font-medium text-gray-900">
                    {supplier.volume.toLocaleString('fr-FR')} kg
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(supplier.volume / maxVolume) * 100}%` }}
                      className="bg-red-600 h-1 rounded-full"
                      transition={{ duration: 1, delay: index * 0.1 }}
                    />
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="flex flex-col items-center space-y-1">
                  <div className={cn(
                    "px-2 py-1 rounded-full text-sm font-medium flex items-center space-x-1",
                    supplier.performance.overall >= 90 ? "bg-green-100 text-green-800" :
                    supplier.performance.overall >= 75 ? "bg-yellow-100 text-yellow-800" :
                    "bg-red-100 text-red-800"
                  )}>
                    {supplier.performance.overall >= 75 ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    <span>{supplier.performance.overall}%</span>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                {supplier.alerts && supplier.alerts.length > 0 && (
                  <div className="flex justify-center">
                    <AlertTriangle className={cn(
                      "w-5 h-5",
                      supplier.alerts[0].type === 'error' ? "text-red-500" :
                      supplier.alerts[0].type === 'warning' ? "text-yellow-500" :
                      "text-blue-500"
                    )} />
                  </div>
                )}
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function SupplierListSkeleton() {
  return (
    <div className="space-y-4">
      {[...Array(5)].map((_, i) => (
        <div key={i} className="h-20 bg-gray-100 animate-pulse rounded-lg" />
      ))}
    </div>
  );
}
```