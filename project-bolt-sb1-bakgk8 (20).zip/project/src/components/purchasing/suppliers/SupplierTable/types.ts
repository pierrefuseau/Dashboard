```typescript
export interface Supplier {
  code: string;
  name: string;
  amount: number;
  volume: number;
  performance: {
    overall: number;
    delivery: number;
    quality: number;
  };
  status: 'active' | 'inactive';
  category: string;
  lastOrder?: Date;
  trend: {
    amount: number;
    volume: number;
  };
  alerts?: {
    type: 'warning' | 'error' | 'info';
    message: string;
  }[];
}

export interface SupplierFilters {
  search: string;
  status?: 'active' | 'inactive';
  category?: string;
  performanceMin?: number;
  amountMin?: number;
  volumeMin?: number;
  sortBy?: 'amount' | 'volume' | 'performance';
  sortOrder?: 'asc' | 'desc';
}
```