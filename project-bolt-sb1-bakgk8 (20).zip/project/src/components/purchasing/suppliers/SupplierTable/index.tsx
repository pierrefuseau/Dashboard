```tsx
import React, { useState } from 'react';
import { Card } from '../../../common/Card';
import { SupplierList } from './SupplierList';
import { SupplierHeader } from './SupplierHeader';
import { SupplierFilters } from './SupplierFilters';
import { SupplierDetails } from './SupplierDetails';
import { SupplierComparison } from './SupplierComparison';
import { useSuppliers } from './hooks/useSuppliers';
import { Supplier } from './types';

export function SupplierTable() {
  const [selectedSuppliers, setSelectedSuppliers] = useState<Supplier[]>([]);
  const [showDetails, setShowDetails] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  const { suppliers, isLoading, filters, setFilters } = useSuppliers();

  const handleSupplierSelect = (supplier: Supplier) => {
    setSelectedSuppliers(prev => 
      prev.find(s => s.code === supplier.code) 
        ? prev.filter(s => s.code !== supplier.code)
        : [...prev, supplier]
    );
  };

  return (
    <Card>
      <SupplierHeader 
        totalSuppliers={suppliers?.length || 0}
        selectedCount={selectedSuppliers.length}
        onCompare={() => setShowComparison(true)}
      />

      <SupplierFilters 
        filters={filters}
        onChange={setFilters}
      />

      <SupplierList
        suppliers={suppliers || []}
        selectedSuppliers={selectedSuppliers}
        onSelect={handleSupplierSelect}
        onShowDetails={() => setShowDetails(true)}
        isLoading={isLoading}
      />

      {showDetails && selectedSuppliers.length === 1 && (
        <SupplierDetails
          supplier={selectedSuppliers[0]}
          onClose={() => {
            setShowDetails(false);
            setSelectedSuppliers([]);
          }}
        />
      )}

      {showComparison && selectedSuppliers.length > 1 && (
        <SupplierComparison
          suppliers={selectedSuppliers}
          onClose={() => {
            setShowComparison(false);
            setSelectedSuppliers([]);
          }}
        />
      )}
    </Card>
  );
}
```