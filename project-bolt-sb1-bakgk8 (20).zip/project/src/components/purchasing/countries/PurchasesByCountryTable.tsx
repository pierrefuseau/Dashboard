import React from 'react';
import { Card } from '../../common/Card';
import { usePurchasesByCountry } from '../../../hooks/purchases/usePurchasesByCountry';
import { numberFormatters } from '../../../utils/formatters/numbers';

export function PurchasesByCountryTable() {
  const { data: countries, isLoading } = usePurchasesByCountry();

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  const totalAmount = countries?.reduce((sum, country) => sum + country.amount, 0) || 0;

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900">Achats par Pays</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Pays
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Montant
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                % du Total
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {countries?.map((country, index) => {
              const percentage = (country.amount / totalAmount) * 100;
              
              return (
                <tr 
                  key={country.country}
                  className={`hover:bg-red-50 transition-colors duration-150 ${
                    index === 0 ? 'bg-red-50' : ''
                  }`}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {country.country}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                    {numberFormatters.euros(country.amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-grow">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-red-600 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">
                        {percentage.toFixed(1)}%
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}