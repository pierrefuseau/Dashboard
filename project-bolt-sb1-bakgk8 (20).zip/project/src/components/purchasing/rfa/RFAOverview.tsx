import React from 'react';
import { Card } from '../../common/Card';
import { Receipt, TrendingDown } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { formatCurrency } from '../../../utils/formatters/currency';
import { RFAPartnersRanking } from './partners/RFAPartnersRanking';
import { TopFlopRFA } from './evolution/TopFlopRFA';

export function RFAOverview() {
  const { data: rfaData, isLoading } = useSheetData('ACHATS', 'B7:C7', {
    transform: (data) => ({
      current: Number(data?.[0]?.[1]?.replace(/[^0-9.-]/g, '')) || 0,
      previous: Number(data?.[0]?.[0]?.replace(/[^0-9.-]/g, '')) || 0
    })
  });

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin h-8 w-8 border-4 border-red-500 rounded-full border-t-transparent" />
        </div>
      </Card>
    );
  }

  const evolution = rfaData ? ((rfaData.current - rfaData.previous) / rfaData.previous) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Carte RFA principale */}
      <Card>
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900">Remises de Fin d'Année</h3>
          <p className="text-sm text-gray-500 mt-1">Comparaison RFA N vs N-1</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* RFA N */}
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">RFA N</p>
                <p className="mt-2 text-2xl font-semibold text-gray-900">
                  {formatCurrency(rfaData?.current || 0)}
                </p>
              </div>
              <div className="p-3 bg-red-50 rounded-full">
                <Receipt className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </div>

          {/* RFA N-1 */}
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">RFA N-1</p>
                <p className="mt-2 text-2xl font-semibold text-gray-900">
                  {formatCurrency(rfaData?.previous || 0)}
                </p>
              </div>
              <div className="p-3 bg-red-50 rounded-full">
                <TrendingDown className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Évolution */}
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-600">Évolution</span>
            <span className={`text-sm font-medium ${evolution >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {evolution >= 0 ? '+' : ''}{evolution.toFixed(1)}%
            </span>
          </div>
        </div>
      </Card>

      {/* Classement des partenaires */}
      <RFAPartnersRanking />

      {/* Top/Flop RFA */}
      <TopFlopRFA />
    </div>
  );
}