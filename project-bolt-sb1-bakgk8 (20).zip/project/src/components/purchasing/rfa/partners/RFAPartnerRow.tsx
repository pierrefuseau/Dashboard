import React from 'react';
import { RFAPartner } from '../../../../types/purchases';
import { EvolutionIndicator } from './EvolutionIndicator';
import { formatRFAValue } from '../../../../utils/formatters/rfa';

interface RFAPartnerRowProps {
  partner: RFAPartner;
  rank: number;
}

export function RFAPartnerRow({ partner, rank }: RFAPartnerRowProps) {
  const isTopThree = rank <= 3;

  return (
    <tr 
      className={`
        transition-colors hover:bg-gray-50
        ${isTopThree ? 'bg-red-50' : ''}
      `}
    >
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex items-center">
          <div className="ml-4">
            <div className="text-sm font-medium text-gray-900">
              {partner.name}
            </div>
            {isTopThree && (
              <div className="text-xs text-red-600">
                Top {rank}
              </div>
            )}
          </div>
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
        {formatRFAValue(partner.currentRFA)}
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <EvolutionIndicator value={partner.evolution} />
      </td>
    </tr>
  );
}