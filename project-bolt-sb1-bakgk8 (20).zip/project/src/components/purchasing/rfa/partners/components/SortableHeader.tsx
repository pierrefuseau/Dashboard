import React from 'react';
import { ArrowUpDown } from 'lucide-react';
import { tableStyles } from '../styles';
import { SortField } from '../types';

interface SortableHeaderProps {
  label: string;
  field: SortField;
  onSort: (field: SortField) => void;
}

export function SortableHeader({ label, field, onSort }: SortableHeaderProps) {
  return (
    <th 
      className={`${tableStyles.header} ${tableStyles.headerSort}`}
      onClick={() => onSort(field)}
    >
      <div className="flex items-center space-x-1">
        <span>{label}</span>
        <ArrowUpDown className={tableStyles.sortIcon} />
      </div>
    </th>
  );
}