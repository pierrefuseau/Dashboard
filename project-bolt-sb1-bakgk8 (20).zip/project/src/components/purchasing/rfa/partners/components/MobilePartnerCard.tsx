import React from 'react';
import { RFAPartnerDisplayData } from '../types';
import { EvolutionIndicator } from './EvolutionIndicator';
import { formatRFAValue } from '../../../../../utils/formatters/rfa';
import { tableStyles } from '../styles';

interface MobilePartnerCardProps {
  partner: RFAPartnerDisplayData;
}

export function MobilePartnerCard({ partner }: MobilePartnerCardProps) {
  const cardStyle = partner.isTopRank 
    ? tableStyles.mobileCard.top 
    : tableStyles.mobileCard.default;

  return (
    <div className={`${tableStyles.mobileCard.base} ${cardStyle}`}>
      <div className="flex justify-between items-start mb-2">
        <div>
          <h3 className="font-medium text-gray-900">{partner.name}</h3>
          {partner.isTopRank && (
            <span className="text-xs text-red-600">Top {partner.rank}</span>
          )}
        </div>
        <div className="text-sm font-medium text-gray-900">
          {formatRFAValue(partner.currentRFA)}
        </div>
      </div>
      <div className="flex items-center mt-2">
        <EvolutionIndicator value={partner.evolution} />
      </div>
    </div>
  );
}