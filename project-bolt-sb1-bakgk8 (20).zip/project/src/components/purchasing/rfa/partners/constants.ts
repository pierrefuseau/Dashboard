export const SORT_FIELDS = {
  CURRENT_RFA: 'currentRFA',
  EVOLUTION: 'evolution'
} as const;

export const TABLE_HEADERS = {
  PARTNER: 'Partenaire',
  CURRENT_RFA: 'RFA Actuelle',
  EVOLUTION: 'Évolution'
} as const;

export const CSV_EXPORT = {
  FILENAME: 'classement-partenaires-rfa',
  HEADERS: ['Partenaire', 'RFA Actuelle', 'Évolution']
} as const;

export const TOP_RANK_THRESHOLD = 3;