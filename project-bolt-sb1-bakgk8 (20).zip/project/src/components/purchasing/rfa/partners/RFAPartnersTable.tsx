import React, { useState } from 'react';
import { RFAPartnerRow } from './RFAPartnerRow';
import { RFAPartner } from '../../../../types/purchases';
import { ArrowUpDown } from 'lucide-react';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface RFAPartnersTableProps {
  partners: RFAPartner[];
}

type SortField = 'currentRFA' | 'previousRFA';
type SortDirection = 'asc' | 'desc';

export function RFAPartnersTable({ partners }: RFAPartnersTableProps) {
  const [sortConfig, setSortConfig] = useState<{
    field: SortField;
    direction: SortDirection;
  }>({
    field: 'currentRFA',
    direction: 'desc'
  });

  const sortedPartners = React.useMemo(() => {
    const sorted = [...partners].sort((a, b) => {
      const multiplier = sortConfig.direction === 'desc' ? -1 : 1;
      return (a[sortConfig.field] - b[sortConfig.field]) * multiplier;
    });
    return sorted;
  }, [partners, sortConfig]);

  const handleSort = (field: SortField) => {
    setSortConfig(current => ({
      field,
      direction: current.field === field && current.direction === 'desc' ? 'asc' : 'desc'
    }));
  };

  return (
    <div className="overflow-x-auto">
      {/* Version Desktop */}
      <table className="min-w-full hidden md:table">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Partenaire
            </th>
            <th 
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer group"
              onClick={() => handleSort('currentRFA')}
            >
              <div className="flex items-center space-x-1">
                <span>RFA N</span>
                <ArrowUpDown className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </th>
            <th 
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer group"
              onClick={() => handleSort('previousRFA')}
            >
              <div className="flex items-center space-x-1">
                <span>RFA N-1</span>
                <ArrowUpDown className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {sortedPartners.map((partner, index) => (
            <tr 
              key={partner.name}
              className={`hover:bg-red-50 transition-colors duration-150 ${
                index < 3 ? 'bg-red-50' : ''
              }`}
            >
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div>
                    <div className="text-sm font-medium text-gray-900">
                      {partner.name}
                    </div>
                    {index < 3 && (
                      <div className="text-xs text-red-600">
                        Top {index + 1}
                      </div>
                    )}
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {formatCurrency(partner.currentRFA)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {formatCurrency(partner.previousRFA)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Version Mobile */}
      <div className="md:hidden space-y-4">
        {sortedPartners.map((partner, index) => (
          <div 
            key={partner.name}
            className={`p-4 rounded-lg border ${
              index < 3 ? 'border-red-200 bg-red-50' : 'border-gray-200'
            }`}
          >
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-medium text-gray-900">{partner.name}</h3>
                {index < 3 && (
                  <span className="text-xs text-red-600">Top {index + 1}</span>
                )}
              </div>
            </div>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between">
                <span className="text-sm text-gray-500">RFA N</span>
                <span className="text-sm font-medium text-gray-900">
                  {formatCurrency(partner.currentRFA)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-500">RFA N-1</span>
                <span className="text-sm font-medium text-gray-900">
                  {formatCurrency(partner.previousRFA)}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}