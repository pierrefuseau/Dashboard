import React from 'react';
import { Card } from '../../../common/Card';
import { RFAPartnersTable } from './RFAPartnersTable';
import { useRFAPartners } from '../../../../hooks/purchases/useRFAPartners';
import { LoadingSpinner } from '../../../common/LoadingSpinner';
import { Download } from 'lucide-react';
import { exportToCSV } from '../../../../utils/export/csvExport';

export function RFAPartnersRanking() {
  const { data: partners, isLoading } = useRFAPartners();

  const handleExport = () => {
    if (!partners?.length) return;
    
    const headers = ['Partenaire', 'RFA Actuelle', 'RFA N-1'];
    const data = partners.map(p => [
      p.name,
      p.currentRFA.toString(),
      p.previousRFA.toString()
    ]);
    
    exportToCSV(data, headers, 'classement-partenaires-rfa');
  };

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner />
        </div>
      </Card>
    );
  }

  if (!partners?.length) {
    return (
      <Card>
        <div className="text-center text-gray-500">
          Aucune donnée disponible
        </div>
      </Card>
    );
  }

  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            Classement des Partenaires – RFA
          </h2>
          <p className="mt-1 text-sm text-gray-500">
            Top partenaires en termes de RFA pour cette année, comparé à l'année dernière
          </p>
        </div>
        <button
          onClick={handleExport}
          className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
        >
          <Download className="w-4 h-4 mr-2" />
          Exporter
        </button>
      </div>

      <RFAPartnersTable partners={partners} />
    </Card>
  );
}