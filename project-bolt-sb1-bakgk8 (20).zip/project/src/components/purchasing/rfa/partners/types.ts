export type SortField = 'currentRFA' | 'evolution';
export type SortDirection = 'asc' | 'desc';

export interface SortConfig {
  field: SortField;
  direction: SortDirection;
}

export interface RFAPartnerDisplayData {
  name: string;
  currentRFA: number;
  evolution: number;
  rank: number;
  isTopRank: boolean;
}