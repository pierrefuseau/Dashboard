export const tableStyles = {
  header: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider',
  headerSort: 'cursor-pointer group',
  sortIcon: 'w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity',
  row: {
    base: 'transition-colors hover:bg-gray-50',
    top: 'bg-red-50'
  },
  cell: 'px-6 py-4 whitespace-nowrap',
  mobileCard: {
    base: 'p-4 rounded-lg border',
    top: 'border-red-200 bg-red-50',
    default: 'border-gray-200'
  }
} as const;

export const evolutionStyles = {
  container: 'inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium',
  positive: 'text-green-800 bg-green-100',
  negative: 'text-red-800 bg-red-100',
  icon: 'w-4 h-4 mr-1'
} as const;