import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface EvolutionIndicatorProps {
  value: number;
}

export function EvolutionIndicator({ value }: EvolutionIndicatorProps) {
  const isPositive = value >= 0;
  
  return (
    <div className={`
      inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium
      ${isPositive ? 'text-green-800 bg-green-100' : 'text-red-800 bg-red-100'}
    `}>
      {isPositive ? (
        <TrendingUp className="w-4 h-4 mr-1" />
      ) : (
        <TrendingDown className="w-4 h-4 mr-1" />
      )}
      {isPositive ? '+' : ''}{value.toFixed(1)}%
    </div>
  );
}