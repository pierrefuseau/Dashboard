import { useMemo } from 'react';
import { RFAPartner } from '../../../../../types/purchases';
import { SortConfig } from '../types';
import { TOP_RANK_THRESHOLD } from '../constants';

export function useSortedPartners(partners: RFAPartner[], sortConfig: SortConfig) {
  return useMemo(() => {
    const sorted = [...partners].sort((a, b) => {
      const multiplier = sortConfig.direction === 'desc' ? -1 : 1;
      return (a[sortConfig.field] - b[sortConfig.field]) * multiplier;
    });

    return sorted.map((partner, index) => ({
      ...partner,
      rank: index + 1,
      isTopRank: index < TOP_RANK_THRESHOLD
    }));
  }, [partners, sortConfig]);
}