import React from 'react';
import { Card } from '../../../common/Card';
import { RFAEvolutionList } from './RFAEvolutionList';
import { useRFAEvolution } from '../../../../hooks/purchases/useRFAEvolution';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { LoadingSpinner } from '../../../common/LoadingSpinner';

export function TopFlopRFA() {
  const { data: evolutions, isLoading } = useRFAEvolution();

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner />
        </div>
      </Card>
    );
  }

  if (!evolutions?.length) {
    return null;
  }

  // Séparer et trier les évolutions positives et négatives
  const positiveEvolutions = evolutions
    .filter(e => e.evolution >= 0)
    .sort((a, b) => b.evolution - a.evolution)
    .slice(0, 5);

  const negativeEvolutions = evolutions
    .filter(e => e.evolution < 0)
    .sort((a, b) => a.evolution - b.evolution)
    .slice(0, 5);

  return (
    <Card>
      <div className="mb-8">
        <h3 className="text-xl font-semibold text-gray-900">
          Évolution RFA (Top & Flop)
        </h3>
        <p className="mt-2 text-sm text-gray-500">
          Analyse des meilleures et moins bonnes performances
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Top 5 */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-green-50">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <h4 className="text-lg font-semibold text-gray-900">
              Top 5 RFA
            </h4>
          </div>
          <RFAEvolutionList 
            evolutions={positiveEvolutions} 
            type="top"
            prefix="top"
          />
        </div>

        {/* Flop 5 */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-red-50">
              <TrendingDown className="w-5 h-5 text-red-600" />
            </div>
            <h4 className="text-lg font-semibold text-gray-900">
              Flop 5 RFA
            </h4>
          </div>
          <RFAEvolutionList 
            evolutions={negativeEvolutions} 
            type="flop"
            prefix="flop"
          />
        </div>
      </div>
    </Card>
  );
}