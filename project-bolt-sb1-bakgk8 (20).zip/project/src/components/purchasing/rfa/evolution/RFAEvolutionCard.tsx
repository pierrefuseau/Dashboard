import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface RFAEvolutionCardProps {
  name: string;
  evolution: number;
  rank: number;
  type: 'top' | 'flop';
}

export function RFAEvolutionCard({ name, evolution, rank, type }: RFAEvolutionCardProps) {
  const isPositive = evolution >= 0;
  
  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
      className={`
        relative p-5 rounded-xl border shadow-sm transition-all duration-200
        hover:shadow-md backdrop-blur-sm
        ${type === 'top' 
          ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-100' 
          : 'bg-gradient-to-br from-red-50 to-rose-50 border-red-100'
        }
      `}
    >
      <div className="flex items-center justify-between space-x-4">
        {/* Rang et Nom */}
        <div className="flex items-center space-x-4 flex-1 min-w-0">
          <div className={`
            w-8 h-8 flex items-center justify-center rounded-full 
            font-semibold text-sm transition-colors
            ${type === 'top' 
              ? 'bg-green-100 text-green-700' 
              : 'bg-red-100 text-red-700'
            }
          `}>
            {rank}
          </div>
          <div className="min-w-0">
            <h4 className="text-base font-semibold text-gray-900 truncate">
              {name}
            </h4>
          </div>
        </div>

        {/* Évolution et Icône */}
        <div className={`
          flex items-center space-x-2 px-3 py-1.5 rounded-full
          ${type === 'top'
            ? 'bg-green-100/50 text-green-700'
            : 'bg-red-100/50 text-red-700'
          }
        `}>
          <span className="text-sm font-medium whitespace-nowrap">
            {isPositive ? '+' : ''}{formatCurrency(evolution)}
          </span>
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {isPositive ? (
              <ArrowUpRight className="w-4 h-4 flex-shrink-0" />
            ) : (
              <ArrowDownRight className="w-4 h-4 flex-shrink-0" />
            )}
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}