import React from 'react';
import { motion } from 'framer-motion';
import { RFAEvolutionCard } from './RFAEvolutionCard';
import { RFAEvolution } from '../../../../hooks/purchases/useRFAEvolution';

interface RFAEvolutionListProps {
  evolutions: RFAEvolution[];
  type: 'top' | 'flop';
  prefix: string;
}

export function RFAEvolutionList({ evolutions, type, prefix }: RFAEvolutionListProps) {
  return (
    <motion.div 
      className="space-y-4"
      initial="hidden"
      animate="visible"
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            staggerChildren: 0.1
          }
        }
      }}
    >
      {evolutions.map((evolution, index) => (
        <motion.div
          key={`${prefix}-${evolution.name}-${index}`}
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: { opacity: 1, y: 0 }
          }}
        >
          <RFAEvolutionCard
            name={evolution.name}
            evolution={evolution.evolution}
            rank={index + 1}
            type={type}
          />
        </motion.div>
      ))}
    </motion.div>
  );
}