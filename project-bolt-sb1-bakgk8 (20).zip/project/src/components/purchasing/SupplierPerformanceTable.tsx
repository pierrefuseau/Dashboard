import React from 'react';
import { Card } from '../common/Card';

interface SupplierData {
  name: string;
  amount: number;
  volume: number;
  growth: number;
}

const suppliers: SupplierData[] = [
  { name: 'Fournisseur A', amount: 1200000, volume: 3200, growth: 8.5 },
  { name: 'Fournisseur B', amount: 950000, volume: 2800, growth: 5.2 },
  { name: 'Fournisseur C', amount: 780000, volume: 2100, growth: -2.1 },
  { name: 'Fournisseur D', amount: 650000, volume: 1900, growth: 12.4 },
  { name: 'Fournisseur E', amount: 520000, volume: 1500, growth: 3.8 }
];

export function SupplierPerformanceTable() {
  return (
    <Card title="Performance Fournisseurs">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Fournisseur
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Montant
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Volume
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Évolution
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {suppliers.map((supplier) => (
              <tr key={supplier.name}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {supplier.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {(supplier.amount / 1000000).toFixed(1)}M€
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {supplier.volume.toLocaleString('fr-FR')} T
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    supplier.growth >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {supplier.growth >= 0 ? '+' : ''}{supplier.growth}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}