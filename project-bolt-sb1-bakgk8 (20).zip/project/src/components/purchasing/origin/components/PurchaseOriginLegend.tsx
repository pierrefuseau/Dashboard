import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { getCountryFlag } from '../../../../utils/countryFlags';

interface PurchaseOriginLegendProps {
  data: Array<{
    country: string;
    amount: number;
    volume: number;
  }>;
  activeIndex: number | null;
  onHover: (index: number | null) => void;
  hiddenCountries: string[];
  onToggleCountry: (country: string) => void;
  viewMode: 'amount' | 'volume' | 'percentage';
}

export function PurchaseOriginLegend({
  data,
  activeIndex,
  onHover,
  hiddenCountries,
  onToggleCountry,
  viewMode
}: PurchaseOriginLegendProps) {
  const totalAmount = data.reduce((sum, item) => sum + item.amount, 0);
  const totalVolume = data.reduce((sum, item) => sum + item.volume, 0);

  const getValue = (item: typeof data[0]) => {
    switch (viewMode) {
      case 'volume':
        return `${item.volume.toLocaleString('fr-FR')} T`;
      case 'percentage':
        return `${((item.amount / totalAmount) * 100).toFixed(1)}%`;
      default:
        return formatCurrency(item.amount);
    }
  };

  return (
    <div className="mt-8 grid grid-cols-2 lg:grid-cols-3 gap-4">
      {data.map((item, index) => (
        <motion.div
          key={item.country}
          className={`
            flex items-center p-3 rounded-lg cursor-pointer transition-colors
            ${activeIndex === index ? 'bg-red-50' : 'hover:bg-red-50/50'}
            ${hiddenCountries.includes(item.country) ? 'opacity-50' : ''}
          `}
          onMouseEnter={() => onHover(index)}
          onMouseLeave={() => onHover(null)}
          whileHover={{ scale: 1.02 }}
        >
          <input
            type="checkbox"
            checked={!hiddenCountries.includes(item.country)}
            onChange={() => onToggleCountry(item.country)}
            className="mr-3 rounded text-red-600 focus:ring-red-500"
          />
          <div className="flex items-center flex-1 min-w-0">
            <span className="text-2xl mr-2">{getCountryFlag(item.country)}</span>
            <div>
              <p className="text-sm font-medium text-gray-900 truncate">
                {item.country}
              </p>
              <p className="text-sm text-red-600">
                {getValue(item)}
              </p>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}