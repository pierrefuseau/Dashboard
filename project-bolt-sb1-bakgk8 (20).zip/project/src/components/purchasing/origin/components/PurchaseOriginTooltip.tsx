import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface PurchaseOriginTooltipProps {
  country: string;
  amount: number;
  volume: number;
  percentage: number;
  flag: string;
}

export function PurchaseOriginTooltip({
  country,
  amount,
  volume,
  percentage,
  flag
}: PurchaseOriginTooltipProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="absolute inset-0 flex items-center justify-center pointer-events-none"
    >
      <div className="bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-red-100">
        <div className="flex items-center space-x-3 mb-3">
          <span className="text-2xl">{flag}</span>
          <h4 className="text-lg font-semibold text-gray-900">{country}</h4>
        </div>
        <div className="space-y-2">
          <p className="text-2xl font-bold text-red-600">
            {formatCurrency(amount)}
          </p>
          <p className="text-sm text-gray-600">
            Volume : {volume.toLocaleString('fr-FR')} T
          </p>
          <p className="text-sm text-gray-600">
            {percentage.toFixed(1)}% du total
          </p>
        </div>
      </div>
    </motion.div>
  );
}