import React from 'react';
import { BarChart2, Scale, Percent, History } from 'lucide-react';

interface PurchaseOriginControlsProps {
  viewMode: 'amount' | 'volume' | 'percentage';
  onViewModeChange: (mode: 'amount' | 'volume' | 'percentage') => void;
  showComparison: boolean;
  onComparisonChange: (show: boolean) => void;
}

export function PurchaseOriginControls({
  viewMode,
  onViewModeChange,
  showComparison,
  onComparisonChange
}: PurchaseOriginControlsProps) {
  return (
    <div className="flex items-center space-x-2">
      <div className="bg-white rounded-lg border border-gray-200 p-1 flex space-x-1">
        <button
          onClick={() => onViewModeChange('amount')}
          className={`p-1.5 rounded-md transition-colors ${
            viewMode === 'amount'
              ? 'bg-red-50 text-red-600'
              : 'text-gray-400 hover:text-gray-600'
          }`}
          title="Montant"
        >
          <BarChart2 className="w-4 h-4" />
        </button>
        <button
          onClick={() => onViewModeChange('volume')}
          className={`p-1.5 rounded-md transition-colors ${
            viewMode === 'volume'
              ? 'bg-red-50 text-red-600'
              : 'text-gray-400 hover:text-gray-600'
          }`}
          title="Volume"
        >
          <Scale className="w-4 h-4" />
        </button>
        <button
          onClick={() => onViewModeChange('percentage')}
          className={`p-1.5 rounded-md transition-colors ${
            viewMode === 'percentage'
              ? 'bg-red-50 text-red-600'
              : 'text-gray-400 hover:text-gray-600'
          }`}
          title="Pourcentage"
        >
          <Percent className="w-4 h-4" />
        </button>
      </div>

      <button
        onClick={() => onComparisonChange(!showComparison)}
        className={`p-2 rounded-lg border transition-colors ${
          showComparison
            ? 'bg-red-50 text-red-600 border-red-200'
            : 'text-gray-400 hover:text-gray-600 border-gray-200'
        }`}
        title="Comparer avec N-1"
      >
        <History className="w-4 h-4" />
      </button>
    </div>
  );
}