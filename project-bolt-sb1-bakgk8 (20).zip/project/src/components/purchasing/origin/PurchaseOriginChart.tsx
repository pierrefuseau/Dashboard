import React, { useState } from 'react';
import { Card } from '../../common/Card';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Maximize2, BarChart2 } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { ChartModal } from '../../common/ChartModal';
import { PurchaseOriginTooltip } from './components/PurchaseOriginTooltip';
import { PurchaseOriginLegend } from './components/PurchaseOriginLegend';
import { PurchaseOriginControls } from './components/PurchaseOriginControls';
import { formatCurrency } from '../../../utils/formatters/currency';
import { exportToCSV } from '../../../utils/export/csvExport';
import { getCountryFlag } from '../../../utils/countryFlags';

type ViewMode = 'amount' | 'volume' | 'percentage';

export function PurchaseOriginChart() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('amount');
  const [showComparison, setShowComparison] = useState(false);
  const [hiddenCountries, setHiddenCountries] = useState<string[]>([]);

  const { data: purchaseData, isLoading } = useSheetData('ACHATS', 'B10:D19', {
    transform: (data) => data.map(row => ({
      country: row[0] || '',
      amount: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0,
      volume: Number(row[2]?.replace(/[^0-9.-]/g, '')) || 0
    }))
    .filter(item => item.country && (item.amount > 0 || item.volume > 0))
  });

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
        </div>
      </Card>
    );
  }

  if (!purchaseData?.length) return null;

  const totalAmount = purchaseData.reduce((sum, item) => sum + item.amount, 0);
  const totalVolume = purchaseData.reduce((sum, item) => sum + item.volume, 0);

  const visibleData = purchaseData.filter(item => !hiddenCountries.includes(item.country));

  const getValue = (item: typeof purchaseData[0]) => {
    switch (viewMode) {
      case 'volume':
        return item.volume;
      case 'percentage':
        return (item.amount / totalAmount) * 100;
      default:
        return item.amount;
    }
  };

  const formatValue = (value: number) => {
    switch (viewMode) {
      case 'volume':
        return `${value.toLocaleString('fr-FR')} T`;
      case 'percentage':
        return `${value.toFixed(1)}%`;
      default:
        return formatCurrency(value);
    }
  };

  const COLORS = [
    ['#ef4444', '#b91c1c'], // Rouge vif
    ['#f87171', '#dc2626'], // Rouge clair
    ['#fca5a5', '#ef4444'], // Rouge pâle
    ['#dc2626', '#991b1b'], // Rouge foncé
    ['#fee2e2', '#fca5a5'], // Rouge très pâle
    ['#b91c1c', '#7f1d1d'], // Rouge profond
    ['#fecaca', '#f87171'], // Rouge rosé
    ['#991b1b', '#450a0a'], // Rouge très foncé
    ['#fef2f2', '#fee2e2'], // Rouge ultra pâle
    ['#ef4444', '#dc2626']  // Rouge moyen
  ];

  const handleExport = () => {
    const headers = ['Pays', 'Montant', 'Volume', '% du total'];
    const data = purchaseData.map(item => [
      item.country,
      formatCurrency(item.amount),
      `${item.volume.toLocaleString('fr-FR')} T`,
      `${((item.amount / totalAmount) * 100).toFixed(1)}%`
    ]);
    exportToCSV(data, headers, 'repartition-achats-pays');
  };

  const renderChart = (height: number = 400) => (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <defs>
          {COLORS.map(([start, end], index) => (
            <linearGradient
              key={`gradient-${index}`}
              id={`gradient-${index}`}
              x1="0"
              y1="0"
              x2="0"
              y2="1"
            >
              <stop offset="0%" stopColor={start} stopOpacity={0.8} />
              <stop offset="100%" stopColor={end} stopOpacity={0.9} />
            </linearGradient>
          ))}
        </defs>

        <Pie
          data={visibleData}
          cx="50%"
          cy="50%"
          innerRadius="60%"
          outerRadius="80%"
          paddingAngle={2}
          dataKey={getValue}
          onMouseEnter={(_, index) => setActiveIndex(index)}
          onMouseLeave={() => setActiveIndex(null)}
        >
          {visibleData.map((entry, index) => (
            <Cell
              key={entry.country}
              fill={`url(#gradient-${index})`}
              stroke="white"
              strokeWidth={2}
              style={{
                filter: activeIndex === index ? 'url(#glow)' : 'none',
                transform: activeIndex === index ? 'scale(1.05)' : 'scale(1)',
                transformOrigin: 'center',
                transition: 'all 0.3s ease-in-out'
              }}
            />
          ))}
        </Pie>
      </PieChart>
    </ResponsiveContainer>
  );

  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Répartition des Achats par Pays</h3>
          <p className="text-sm text-gray-500">
            Total achats : <span className="text-red-600">{formatCurrency(totalAmount)}</span>
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <PurchaseOriginControls
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            showComparison={showComparison}
            onComparisonChange={setShowComparison}
          />
          <button
            onClick={handleExport}
            className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
            title="Exporter les données"
          >
            <Download className="h-5 w-5" />
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
            title="Agrandir"
          >
            <Maximize2 className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="relative h-[500px]">
        {renderChart(500)}

        <AnimatePresence>
          {activeIndex !== null && (
            <PurchaseOriginTooltip
              country={visibleData[activeIndex].country}
              amount={visibleData[activeIndex].amount}
              volume={visibleData[activeIndex].volume}
              percentage={(visibleData[activeIndex].amount / totalAmount) * 100}
              flag={getCountryFlag(visibleData[activeIndex].country)}
            />
          )}
        </AnimatePresence>
      </div>

      <PurchaseOriginLegend
        data={purchaseData}
        activeIndex={activeIndex}
        onHover={setActiveIndex}
        hiddenCountries={hiddenCountries}
        onToggleCountry={(country) => {
          setHiddenCountries(prev => 
            prev.includes(country)
              ? prev.filter(c => c !== country)
              : [...prev, country]
          );
        }}
        viewMode={viewMode}
      />

      <ChartModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Répartition des Achats par Pays"
      >
        {renderChart(700)}
      </ChartModal>
    </Card>
  );
}