import React, { useState } from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { ChartModal } from '../../common/ChartModal';
import { Maximize2, Download } from 'lucide-react';
import { formatCurrency } from '../../../utils/formatters/currency';
import { motion } from 'framer-motion';

export function PurchaseVolumeChart() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [hoveredMonth, setHoveredMonth] = useState<string | null>(null);

  const { data: monthlyData, isLoading } = useSheetData('ACHATS', 'B22:C33', {
    transform: (data) => data.map((row) => ({
      month: row[0],
      amount: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
    }))
  });

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  const totalAmount = monthlyData?.reduce((sum, item) => sum + item.amount, 0) || 0;
  const averageAmount = totalAmount / (monthlyData?.length || 1);
  const maxAmount = Math.max(...(monthlyData?.map(item => item.amount) || []));

  const getBarColor = (amount: number) => {
    if (amount === maxAmount) return '#dc2626'; // Rouge vif pour le max
    if (amount > averageAmount) return '#ef4444'; // Rouge pour au-dessus de la moyenne
    return '#f87171'; // Rouge clair pour en-dessous de la moyenne
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;

    const amount = payload[0].value;
    const percentage = ((amount / totalAmount) * 100).toFixed(1);

    return (
      <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-100">
        <p className="font-medium text-gray-900">{label}</p>
        <p className="text-sm text-gray-600 mt-1">
          Montant : {formatCurrency(amount)}
        </p>
        <p className="text-sm text-gray-600">
          {percentage}% du total annuel
        </p>
      </div>
    );
  };

  const renderChart = (height: number = 400) => (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 60, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
        <XAxis 
          dataKey="month"
          tick={{ fontSize: 12, fill: '#4B5563' }}
        />
        <YAxis 
          tickFormatter={formatCurrency}
          tick={{ fontSize: 12, fill: '#4B5563' }}
          width={80}
        />
        <Tooltip content={<CustomTooltip />} />
        <ReferenceLine 
          y={averageAmount} 
          stroke="#9CA3AF" 
          strokeDasharray="3 3"
          label={{ 
            value: 'Moyenne', 
            position: 'right',
            fill: '#4B5563',
            fontSize: 12
          }}
        />
        <Bar 
          dataKey="amount"
          radius={[4, 4, 0, 0]}
          onMouseEnter={(data) => setHoveredMonth(data.month)}
          onMouseLeave={() => setHoveredMonth(null)}
        >
          {monthlyData?.map((entry, index) => (
            <motion.g key={`cell-${index}`}>
              <Cell
                fill={getBarColor(entry.amount)}
                fillOpacity={hoveredMonth === entry.month ? 1 : 0.8}
                cursor="pointer"
              />
            </motion.g>
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );

  return (
    <Card>
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Montant d'achats par mois</h3>
          <p className="text-sm text-gray-500">
            Total annuel : {formatCurrency(totalAmount)}
          </p>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => {
              // Export logic here
            }}
            className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
            title="Exporter les données"
          >
            <Download className="h-5 w-5" />
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
            title="Agrandir"
          >
            <Maximize2 className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="h-[400px]">
        {renderChart()}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Moyenne mensuelle</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">
            {formatCurrency(averageAmount)}
          </div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm font-medium text-gray-600">Pic d'achats</div>
          <div className="text-lg font-semibold text-gray-900 mt-1">
            {formatCurrency(maxAmount)}
          </div>
        </div>
      </div>

      <ChartModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Montant d'achats par mois"
      >
        {renderChart(600)}
      </ChartModal>
    </Card>
  );
}