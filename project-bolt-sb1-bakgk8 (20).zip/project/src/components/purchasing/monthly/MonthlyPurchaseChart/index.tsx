import React, { useState } from 'react';
import { Card } from '../../../common/Card';
import { ChartContainer } from './ChartContainer';
import { ChartControls } from './ChartControls';
import { ChartLegend } from './ChartLegend';
import { MonthlyComparison } from './MonthlyComparison';
import { useMonthlyPurchases } from '../../../../hooks/purchases/useMonthlyPurchases';
import { formatCurrency } from '../../../../utils/formatters/currency';

export function MonthlyPurchaseChart() {
  const [showComparison, setShowComparison] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);
  const { data: monthlyData, isLoading } = useMonthlyPurchases();

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
        </div>
      </Card>
    );
  }

  const totalAmount = monthlyData?.reduce((sum, month) => sum + month.amount, 0) || 0;
  const maxAmount = Math.max(...(monthlyData?.map(m => m.amount) || []));
  const averageAmount = totalAmount / (monthlyData?.length || 1);

  return (
    <Card>
      <div className="space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium text-gray-900">Montant d'achats par mois</h3>
            <p className="mt-1 text-sm text-gray-500">
              Total annuel : {formatCurrency(totalAmount)}
            </p>
          </div>
          <ChartControls 
            showComparison={showComparison}
            onToggleComparison={() => setShowComparison(!showComparison)}
          />
        </div>

        <ChartContainer
          data={monthlyData || []}
          maxAmount={maxAmount}
          averageAmount={averageAmount}
          selectedMonth={selectedMonth}
          onSelectMonth={setSelectedMonth}
          showComparison={showComparison}
        />

        <ChartLegend 
          averageAmount={averageAmount}
          maxAmount={maxAmount}
        />

        {selectedMonth && (
          <MonthlyComparison
            month={selectedMonth}
            data={monthlyData?.find(m => m.month === selectedMonth)}
            onClose={() => setSelectedMonth(null)}
          />
        )}
      </div>
    </Card>
  );
}