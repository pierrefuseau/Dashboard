import React from 'react';
import { Download, History, Maximize2 } from 'lucide-react';

interface ChartControlsProps {
  showComparison: boolean;
  onToggleComparison: () => void;
}

export function ChartControls({ showComparison, onToggleComparison }: ChartControlsProps) {
  return (
    <div className="flex items-center space-x-4">
      <button
        onClick={onToggleComparison}
        className={`p-2 rounded-lg border transition-colors ${
          showComparison
            ? 'bg-red-50 text-red-600 border-red-200'
            : 'text-gray-400 hover:text-gray-600 border-gray-200'
        }`}
        title="Comparer avec N-1"
      >
        <History className="w-5 h-5" />
      </button>
      <button
        onClick={() => {
          // Export logic here
        }}
        className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
        title="Exporter les données"
      >
        <Download className="w-5 h-5" />
      </button>
      <button
        onClick={() => {
          // Maximize logic here
        }}
        className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
        title="Agrandir"
      >
        <Maximize2 className="w-5 h-5" />
      </button>
    </div>
  );
}