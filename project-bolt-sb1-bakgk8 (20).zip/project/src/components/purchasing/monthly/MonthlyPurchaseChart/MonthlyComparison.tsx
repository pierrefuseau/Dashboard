import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { X } from 'lucide-react';

interface MonthlyComparisonProps {
  month: string;
  data?: {
    month: string;
    amount: number;
  };
  onClose: () => void;
}

export function MonthlyComparison({ month, data, onClose }: MonthlyComparisonProps) {
  if (!data) return null;

  // Simuler des données pour la démonstration
  const previousYear = data.amount * 0.95;
  const evolution = ((data.amount - previousYear) / previousYear) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="bg-gray-50 rounded-lg p-6 relative"
    >
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-gray-400 hover:text-gray-500"
      >
        <X className="w-5 h-5" />
      </button>

      <h4 className="text-lg font-medium text-gray-900 mb-4">
        Détails pour {month}
      </h4>

      <div className="grid grid-cols-3 gap-6">
        <div>
          <p className="text-sm text-gray-500">Montant N</p>
          <p className="text-lg font-semibold text-gray-900">
            {formatCurrency(data.amount)}
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Montant N-1</p>
          <p className="text-lg font-semibold text-gray-900">
            {formatCurrency(previousYear)}
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Évolution</p>
          <p className="text-lg font-semibold text-green-600">
            +{evolution.toFixed(1)}%
          </p>
        </div>
      </div>
    </motion.div>
  );
}