import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { CustomTooltip } from './CustomTooltip';

interface ChartContainerProps {
  data: Array<{ month: string; amount: number }>;
  maxAmount: number;
  averageAmount: number;
  selectedMonth: string | null;
  onSelectMonth: (month: string | null) => void;
  showComparison: boolean;
}

export function ChartContainer({
  data,
  maxAmount,
  averageAmount,
  selectedMonth,
  onSelectMonth,
  showComparison
}: ChartContainerProps) {
  const getBarColor = (amount: number) => {
    if (amount === maxAmount) return '#dc2626'; // Rouge vif pour le max
    if (amount > averageAmount) return '#ef4444'; // Rouge pour au-dessus de la moyenne
    return '#f87171'; // Rouge clair pour en-dessous de la moyenne
  };

  return (
    <div className="h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 20, right: 30, left: 40, bottom: 10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
          <XAxis 
            dataKey="month"
            tick={{ fill: '#6B7280', fontSize: 12 }}
          />
          <YAxis
            tickFormatter={formatCurrency}
            tick={{ fill: '#6B7280', fontSize: 12 }}
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine
            y={averageAmount}
            stroke="#9CA3AF"
            strokeDasharray="3 3"
            label={{ 
              value: 'Moyenne',
              position: 'right',
              fill: '#6B7280',
              fontSize: 12
            }}
          />
          <Bar
            dataKey="amount"
            radius={[4, 4, 0, 0]}
            onClick={(data) => onSelectMonth(data.month)}
          >
            {data.map((entry, index) => (
              <motion.g key={`cell-${index}`}>
                <Cell
                  fill={getBarColor(entry.amount)}
                  fillOpacity={selectedMonth === entry.month ? 1 : 0.8}
                  cursor="pointer"
                />
              </motion.g>
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}