import React from 'react';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface CustomTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
}

export function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload?.length) return null;

  const amount = payload[0].value;
  const previousYear = amount * 0.95; // Simulé pour l'exemple

  return (
    <div className="bg-white px-4 py-3 shadow-lg border border-gray-100 rounded-lg">
      <p className="font-medium text-gray-900">{label}</p>
      <div className="mt-2 space-y-1">
        <p className="text-sm">
          <span className="text-gray-500">Montant :</span>{' '}
          <span className="font-medium text-gray-900">{formatCurrency(amount)}</span>
        </p>
        <p className="text-sm">
          <span className="text-gray-500">N-1 :</span>{' '}
          <span className="font-medium text-gray-900">{formatCurrency(previousYear)}</span>
        </p>
        <p className="text-sm">
          <span className="text-gray-500">Évolution :</span>{' '}
          <span className="font-medium text-green-600">+5.0%</span>
        </p>
      </div>
    </div>
  );
}