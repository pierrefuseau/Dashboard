import React from 'react';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface ChartLegendProps {
  averageAmount: number;
  maxAmount: number;
}

export function ChartLegend({ averageAmount, maxAmount }: ChartLegendProps) {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="bg-gray-50 p-3 rounded-lg">
        <div className="text-sm font-medium text-gray-600">Moyenne mensuelle</div>
        <div className="text-lg font-semibold text-gray-900 mt-1">
          {formatCurrency(averageAmount)}
        </div>
      </div>
      <div className="bg-gray-50 p-3 rounded-lg">
        <div className="text-sm font-medium text-gray-600">Pic d'achats</div>
        <div className="text-lg font-semibold text-gray-900 mt-1">
          {formatCurrency(maxAmount)}
        </div>
      </div>
    </div>
  );
}