import React, { useState } from 'react';
import { Card } from '../../common/Card';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { useFamiliesData } from './hooks/useFamiliesData';
import { LoadingSpinner } from '../../common/LoadingSpinner';
import { formatCurrency } from '../../../utils/formatters/currency';
import { FamilyLegend } from './components/FamilyLegend';
import { CenterInfo } from './components/CenterInfo';

const COLORS = {
  CHOCOLAT: ['#8B4513', '#A0522D'],
  SUCRE: ['#87CEEB', '#B0E0E6'],
  BEURRE: ['#FFD700', '#F0E68C']
};

export function DonutChart() {
  const { data: families, isLoading } = useFamiliesData();
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-96">
          <LoadingSpinner />
        </div>
      </Card>
    );
  }

  if (!families?.length) {
    return null;
  }

  const totalValue = families.reduce((sum, item) => sum + item.value, 0);

  return (
    <Card>
      <div className="mb-6">
        <h3 className="text-xl font-semibold text-gray-900 text-center">
          Répartition par Famille de Produits
        </h3>
        <p className="mt-2 text-sm text-gray-500 text-center">
          Total des achats : {formatCurrency(totalValue)}
        </p>
      </div>

      <div className="relative h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <defs>
              {Object.entries(COLORS).map(([name, [color1, color2]], index) => (
                <linearGradient
                  key={name}
                  id={`gradient-${index}`}
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop offset="0%" stopColor={color1} stopOpacity={0.8} />
                  <stop offset="100%" stopColor={color2} stopOpacity={0.9} />
                </linearGradient>
              ))}
            </defs>

            <Pie
              data={families}
              cx="50%"
              cy="50%"
              innerRadius="60%"
              outerRadius="80%"
              paddingAngle={2}
              dataKey="value"
              onMouseEnter={(_, index) => setActiveIndex(index)}
              onMouseLeave={() => setActiveIndex(null)}
            >
              {families.map((entry, index) => (
                <Cell
                  key={entry.name}
                  fill={`url(#gradient-${index})`}
                  stroke="white"
                  strokeWidth={2}
                  style={{
                    filter: activeIndex === index ? 'url(#glow)' : 'none',
                    transform: activeIndex === index ? 'scale(1.05)' : 'scale(1)',
                    transformOrigin: 'center',
                    transition: 'all 0.3s ease-in-out'
                  }}
                />
              ))}
            </Pie>

            <defs>
              <filter id="glow">
                <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                <feMerge>
                  <feMergeNode in="coloredBlur"/>
                  <feMergeNode in="SourceGraphic"/>
                </feMerge>
              </filter>
            </defs>
          </PieChart>
        </ResponsiveContainer>

        <AnimatePresence>
          {activeIndex !== null && (
            <CenterInfo
              family={families[activeIndex]}
              totalValue={totalValue}
            />
          )}
        </AnimatePresence>
      </div>

      <FamilyLegend
        families={families}
        activeIndex={activeIndex}
        onHover={setActiveIndex}
      />
    </Card>
  );
}