import React, { useState } from 'react';
import { Card } from '../../common/Card';
import { ChartModal } from '../../common/ChartModal';
import { Maximize2 } from 'lucide-react';
import { useFamiliesData } from './hooks/useFamiliesData';
import { PodiumChart } from './components/PodiumChart';

export function ProductFamiliesBubbleChart() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [hoveredFamily, setHoveredFamily] = useState<string | null>(null);
  const { data: families, isLoading } = useFamiliesData();

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Répartition par Famille de Produits</h3>
          <p className="text-sm text-gray-500 mt-1">Top 3 des familles de produits par volume d'achats</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
        >
          <Maximize2 className="h-5 w-5" />
        </button>
      </div>

      <div className="h-[400px] bg-gradient-to-br from-gray-50 to-white rounded-lg">
        <PodiumChart
          families={families || []}
          hoveredFamily={hoveredFamily}
          onHover={setHoveredFamily}
        />
      </div>

      <div className="mt-4 text-sm text-gray-500">
        <p>Hauteur des marches proportionnelle au montant des achats</p>
      </div>

      <ChartModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Répartition par Famille de Produits"
      >
        <div className="h-[600px]">
          <PodiumChart
            families={families || []}
            hoveredFamily={hoveredFamily}
            onHover={setHoveredFamily}
          />
        </div>
      </ChartModal>
    </Card>
  );
}