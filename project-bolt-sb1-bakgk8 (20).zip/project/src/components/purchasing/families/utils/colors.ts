export function getGradientColors(index: number) {
  // Palette de dégradés rouges
  const gradients = [
    { start: '#ef4444', end: '#b91c1c' }, // Rouge vif
    { start: '#f87171', end: '#dc2626' }, // Rouge clair
    { start: '#fca5a5', end: '#ef4444' }, // Rouge pâle
    { start: '#dc2626', end: '#991b1b' }, // Rouge foncé
    { start: '#fee2e2', end: '#fca5a5' }, // Rouge très pâle
    { start: '#b91c1c', end: '#7f1d1d' }, // Rouge profond
    { start: '#fecaca', end: '#f87171' }, // Rouge rosé
    { start: '#991b1b', end: '#450a0a' }, // Rouge très foncé
    { start: '#fef2f2', end: '#fee2e2' }, // Rouge ultra pâle
    { start: '#ef4444', end: '#dc2626' }  // Rouge moyen
  ];

  return gradients[index % gradients.length];
}