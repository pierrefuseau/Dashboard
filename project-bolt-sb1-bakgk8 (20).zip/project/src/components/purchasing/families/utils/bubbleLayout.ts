import { Position } from '../types';

export function calculateBubbleRadius(percentage: number, maxRadius: number): number {
  return maxRadius * Math.sqrt(percentage / 100) * 0.8;
}

export function getBubblePosition(
  index: number, 
  total: number, 
  centerX: number, 
  centerY: number, 
  maxRadius: number
): Position {
  if (index === 0) {
    return { x: centerX, y: centerY };
  }

  const angle = (index / (total - 1)) * Math.PI * 1.5;
  const radius = maxRadius * (1 + index * 0.3);
  
  return {
    x: centerX + Math.cos(angle) * radius * 0.8,
    y: centerY + Math.sin(angle) * radius * 0.6
  };
}

export function getBubbleStyle(
  radius: number,
  position: Position,
  index: number,
  total: number,
  isHovered: boolean
) {
  return {
    width: `${radius * 2}px`,
    height: `${radius * 2}px`,
    left: `${position.x}px`,
    top: `${position.y}px`,
    transform: `translate(-50%, -50%) scale(${isHovered ? 1.1 : 1})`,
    zIndex: isHovered ? 10 : total - index,
    background: `radial-gradient(circle at 30% 30%, 
      ${index === 0 ? '#FFE082' : `hsl(${30 + index * 20}, 85%, 65%)`}, 
      ${index === 0 ? '#FFA000' : `hsl(${30 + index * 20}, 85%, 55%)`}
    )`
  };
}