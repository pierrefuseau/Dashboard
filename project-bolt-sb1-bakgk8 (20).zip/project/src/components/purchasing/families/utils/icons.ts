import { 
  Cookie, // Pour le chocolat
  CandyCane, // Pour le sucre
  Milk, // Pour le beurre
  Apple, // Pour les fruits secs
  Coffee, // Pour la crème
  Egg, // Pour les oeufs/fromage
  Wheat, // Pour la farine
  GlassWater, // Pour les boissons
  Grape, // Pour les fruits sirop
  TestTube // Pour la levure et ferments (remplace Flask)
} from 'lucide-react';

export function getFamilyIcon(familyName: string) {
  const icons: Record<string, any> = {
    'CHOCOLAT': Cookie,
    'SUCRE': CandyCane,
    'BEURRE': Milk,
    'FRUITS SECS': Apple,
    'CREME': Coffee,
    'OEUFS / FROMAGE': Egg,
    'FARINE ELABOR BOULAN': Wheat,
    'BOISSONS': GlassWater,
    'FRUITS SIROP': Grape,
    'LEVURE ET AUTRES FERMENTS': TestTube // Changé de Flask à TestTube
  };

  return icons[familyName] || Cookie;
}