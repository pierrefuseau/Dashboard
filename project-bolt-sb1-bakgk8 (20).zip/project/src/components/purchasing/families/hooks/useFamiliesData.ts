import { useSheetData } from '../../../../hooks/sheets/useSheetData';
import { ProductFamily } from '../types';

export function useFamiliesData() {
  return useSheetData<ProductFamily[]>('ACHATS', 'E3:F5', {
    transform: (data) => {
      // Transformer les données brutes en familles de produits
      const items = data.map(row => ({
        name: row[0] || '',
        value: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
      })).filter(item => item.name && item.value > 0);

      // Calculer le total pour les pourcentages
      const total = items.reduce((sum, item) => sum + item.value, 0);
      
      // Ajouter les pourcentages et trier par valeur décroissante
      return items.map(item => ({
        ...item,
        percentage: (item.value / total) * 100
      })).sort((a, b) => b.value - a.value);
    }
  });
}