import React, { useState } from 'react';
import { Card } from '../../common/Card';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Maximize2 } from 'lucide-react';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { ChartModal } from '../../common/ChartModal';
import { formatCurrency } from '../../../utils/formatters/currency';
import { exportToCSV } from '../../../utils/export/csvExport';
import { ViewMode, ProductFamily } from './types';
import { ProductFamilyLegend } from './components/ProductFamilyLegend';
import { CenterInfo } from './components/CenterInfo';
import { ChartControls } from './components/ChartControls';
import { getGradientColors } from './utils/colors';

export function ProductFamiliesChart() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('amount');
  const [showComparison, setShowComparison] = useState(false);

  const { data: families, isLoading } = useSheetData('ACHATS', 'E3:G12', {
    transform: (data) => {
      const items = data.map(row => ({
        name: row[0] || '',
        value: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0,
        volume: Number(row[2]?.replace(/[^0-9.-]/g, '')) || 0
      }))
      .filter(item => item.name && item.value > 0)
      .sort((a, b) => b.value - a.value);

      const total = items.reduce((sum, item) => sum + item.value, 0);
      
      return items.map(item => ({
        ...item,
        percentage: (item.value / total) * 100
      }));
    }
  });

  if (isLoading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
        </div>
      </Card>
    );
  }

  if (!families?.length) return null;

  const totalValue = families.reduce((sum, item) => sum + item.value, 0);
  const totalVolume = families.reduce((sum, item) => sum + (item.volume || 0), 0);

  const getValue = (item: ProductFamily) => {
    switch (viewMode) {
      case 'volume':
        return item.volume || 0;
      case 'percentage':
        return item.percentage;
      default:
        return item.value;
    }
  };

  const handleExport = () => {
    const headers = ['Famille', 'Montant', 'Volume', '% du total'];
    const data = families.map(item => [
      item.name,
      formatCurrency(item.value),
      `${item.volume?.toLocaleString('fr-FR')} T`,
      `${item.percentage.toFixed(1)}%`
    ]);
    exportToCSV(data, headers, 'repartition-familles-produits');
  };

  const renderChart = (height: number = 400) => (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <defs>
          {families.map((_, index) => {
            const colors = getGradientColors(index);
            return (
              <linearGradient
                key={`gradient-${index}`}
                id={`gradient-${index}`}
                x1="0"
                y1="0"
                x2="0"
                y2="1"
              >
                <stop offset="0%" stopColor={colors.start} stopOpacity={0.8} />
                <stop offset="100%" stopColor={colors.end} stopOpacity={0.9} />
              </linearGradient>
            );
          })}
        </defs>

        <Pie
          data={families}
          cx="50%"
          cy="50%"
          innerRadius="60%"
          outerRadius="80%"
          paddingAngle={2}
          dataKey={getValue}
          onMouseEnter={(_, index) => setActiveIndex(index)}
          onMouseLeave={() => setActiveIndex(null)}
        >
          {families.map((entry, index) => (
            <Cell
              key={entry.name}
              fill={`url(#gradient-${index})`}
              stroke="white"
              strokeWidth={2}
              style={{
                filter: activeIndex === index ? 'drop-shadow(0 0 8px rgba(0,0,0,0.2))' : 'none',
                transform: activeIndex === index ? 'scale(1.05)' : 'scale(1)',
                transformOrigin: 'center',
                transition: 'all 0.3s ease-in-out',
                cursor: 'pointer'
              }}
            />
          ))}
        </Pie>
      </PieChart>
    </ResponsiveContainer>
  );

  return (
    <Card>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Répartition par Famille de Produits</h3>
          <p className="text-sm text-gray-500">
            Total achats : <span className="text-red-600">{formatCurrency(totalValue)}</span>
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <ChartControls
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            showComparison={showComparison}
            onComparisonChange={setShowComparison}
          />
          <button
            onClick={handleExport}
            className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
            title="Exporter les données"
          >
            <Download className="h-5 w-5" />
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
            title="Agrandir"
          >
            <Maximize2 className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="relative h-[500px]">
        {renderChart(500)}

        <AnimatePresence>
          {activeIndex !== null && (
            <CenterInfo
              family={families[activeIndex]}
              totalValue={totalValue}
              totalVolume={totalVolume}
              viewMode={viewMode}
            />
          )}
        </AnimatePresence>
      </div>

      <ProductFamilyLegend
        families={families}
        activeIndex={activeIndex}
        onHover={setActiveIndex}
        viewMode={viewMode}
        showComparison={showComparison}
      />

      <ChartModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Répartition par Famille de Produits"
      >
        {renderChart(700)}
      </ChartModal>
    </Card>
  );
}