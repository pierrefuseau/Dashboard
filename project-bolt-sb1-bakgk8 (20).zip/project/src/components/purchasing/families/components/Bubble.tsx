import React from 'react';
import { ProductFamily, Position } from '../types';
import { getBubbleStyle } from '../utils/bubbleLayout';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface BubbleProps {
  family: ProductFamily;
  position: Position;
  radius: number;
  index: number;
  total: number;
  isHovered: boolean;
  onHover: (name: string | null) => void;
}

export function Bubble({
  family,
  position,
  radius,
  index,
  total,
  isHovered,
  onHover
}: BubbleProps) {
  const bubbleStyle = getBubbleStyle(radius, position, index, total, isHovered);
  const delay = index * 100;

  return (
    <div
      className="absolute transition-all duration-300 cursor-pointer rounded-full"
      style={{
        ...bubbleStyle,
        animation: `fadeInScale 0.6s ease-out ${delay}ms backwards`
      }}
      onMouseEnter={() => onHover(family.name)}
      onMouseLeave={() => onHover(null)}
    >
      <div className="absolute inset-0 flex items-center justify-center text-center p-2">
        <div>
          <div className="text-white font-medium text-sm">
            {formatCurrency(family.value)}
          </div>
          <div className="text-white/90 text-xs font-medium mt-1 line-clamp-2">
            {family.name}
          </div>
        </div>
      </div>

      {isHovered && (
        <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-white px-3 py-1.5 rounded-lg shadow-lg z-20">
          <div className="text-sm font-medium">{family.name}</div>
          <div className="text-sm text-gray-600">
            {formatCurrency(family.value)}
          </div>
          <div className="text-xs text-gray-500">
            {family.percentage.toFixed(1)}% du total
          </div>
        </div>
      )}
    </div>
  );
}