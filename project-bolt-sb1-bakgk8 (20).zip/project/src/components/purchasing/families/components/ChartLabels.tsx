import React from 'react';
import { motion } from 'framer-motion';
import { ProductFamily } from '../types';
import { formatCurrency } from '../../../../utils/formatters/currency';

interface ChartLabelsProps {
  families: ProductFamily[];
  activeIndex: number | null;
}

export function ChartLabels({ families, activeIndex }: ChartLabelsProps) {
  return (
    <>
      {families.map((family, index) => {
        // Calculate position around the circle
        const angle = (index / families.length) * 2 * Math.PI - Math.PI / 2;
        const radius = 170; // Adjust based on chart size
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;

        // Calculate line end points
        const lineLength = 30;
        const lineEndX = x * 0.8;
        const lineEndY = y * 0.8;

        return (
          <motion.g
            key={family.name}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            style={{
              transform: `translate(${200 + x}px, ${200 + y}px)`,
              transformOrigin: 'center'
            }}
            className={`${activeIndex === index ? 'z-10' : ''}`}
          >
            {/* Connecting line */}
            <line
              x1={0}
              y1={0}
              x2={lineEndX}
              y2={lineEndY}
              stroke="#94A3B8"
              strokeWidth={1}
              className="opacity-50"
            />

            {/* Label background */}
            <foreignObject
              x={x < 0 ? -120 : 20}
              y={-12}
              width={100}
              height={50}
              style={{ overflow: 'visible' }}
            >
              <div
                className={`text-sm transition-all duration-200 ${
                  activeIndex === index ? 'scale-110 font-medium' : ''
                }`}
              >
                <div className="whitespace-nowrap text-gray-900">
                  {family.name}
                </div>
                <div className="text-gray-500 text-xs">
                  {family.percentage.toFixed(1)}%
                </div>
                <div className="text-gray-600 text-xs">
                  {formatCurrency(family.value)}
                </div>
              </div>
            </foreignObject>
          </motion.g>
        );
      })}
    </>
  );
}