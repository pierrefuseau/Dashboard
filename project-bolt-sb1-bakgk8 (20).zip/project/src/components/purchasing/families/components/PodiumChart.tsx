import React from 'react';
import { ProductFamily } from '../types';
import { PodiumStep } from './PodiumStep';

interface PodiumChartProps {
  families: ProductFamily[];
  hoveredFamily: string | null;
  onHover: (name: string | null) => void;
}

export function PodiumChart({
  families,
  hoveredFamily,
  onHover
}: PodiumChartProps) {
  // Prendre les 3 premières familles
  const topFamilies = families.slice(0, 3);

  return (
    <div className="relative w-full h-full bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Effet de perspective */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_0%,_rgba(0,0,0,0.03)_100%)]" />

      {/* Base du podium avec ombre portée */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[90%] h-24 bg-gradient-to-b from-gray-200 to-gray-300 rounded-lg shadow-inner" />

      {/* Marches du podium */}
      {topFamilies.map((family, index) => (
        <PodiumStep
          key={family.name}
          family={family}
          position={(index + 1) as 1 | 2 | 3}
          isHovered={hoveredFamily === family.name}
          onHover={onHover}
        />
      ))}
    </div>
  );
}