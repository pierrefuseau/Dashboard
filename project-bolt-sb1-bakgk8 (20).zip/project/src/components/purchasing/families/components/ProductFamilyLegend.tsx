import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { ProductFamily } from '../types';
import { getFamilyIcon } from '../utils/icons';

interface ProductFamilyLegendProps {
  families: ProductFamily[];
  activeIndex: number | null;
  onHover: (index: number | null) => void;
  viewMode: 'amount' | 'volume' | 'percentage';
  showComparison: boolean;
}

export function ProductFamilyLegend({
  families,
  activeIndex,
  onHover,
  viewMode,
  showComparison
}: ProductFamilyLegendProps) {
  const getValue = (family: ProductFamily) => {
    switch (viewMode) {
      case 'volume':
        return family.volume 
          ? `${family.volume.toLocaleString('fr-FR')} T` 
          : 'N/A';
      case 'percentage':
        return `${family.percentage.toFixed(1)}%`;
      default:
        return formatCurrency(family.value);
    }
  };

  return (
    <div className="mt-8 grid grid-cols-2 lg:grid-cols-3 gap-4">
      {families.map((family, index) => {
        const Icon = getFamilyIcon(family.name);
        
        return (
          <motion.div
            key={family.name}
            className={`p-4 rounded-lg transition-colors cursor-pointer ${
              activeIndex === index ? 'bg-red-50' : 'hover:bg-red-50/50'
            }`}
            onMouseEnter={() => onHover(index)}
            onMouseLeave={() => onHover(null)}
            whileHover={{ scale: 1.02 }}
          >
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-full bg-red-50">
                <Icon className="w-5 h-5 text-red-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {family.name}
                </p>
                <p className="text-sm text-red-600">
                  {getValue(family)}
                </p>
                {showComparison && (
                  <div className="flex items-center mt-1">
                    <div className="text-xs text-gray-500">
                      vs N-1: +12.5%
                    </div>
                  </div>
                )}
                <div className="mt-2 w-full bg-red-100 rounded-full h-1.5">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-red-500 to-red-600"
                    style={{ width: `${family.percentage}%` }}
                  />
                </div>
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}