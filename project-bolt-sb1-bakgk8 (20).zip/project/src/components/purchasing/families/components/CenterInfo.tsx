import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { ProductFamily } from '../types';
import { getFamilyIcon } from '../utils/icons';

interface CenterInfoProps {
  family: ProductFamily;
  totalValue: number;
  totalVolume: number;
  viewMode: 'amount' | 'volume' | 'percentage';
}

export function CenterInfo({
  family,
  totalValue,
  totalVolume,
  viewMode
}: CenterInfoProps) {
  const Icon = getFamilyIcon(family.name);

  const getValue = () => {
    switch (viewMode) {
      case 'volume':
        return family.volume 
          ? `${family.volume.toLocaleString('fr-FR')} T` 
          : 'N/A';
      case 'percentage':
        return `${family.percentage.toFixed(1)}%`;
      default:
        return formatCurrency(family.value);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="absolute inset-0 flex items-center justify-center pointer-events-none"
    >
      <div className="text-center bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-red-100">
        <div className="flex items-center justify-center mb-3">
          <div className="p-3 rounded-full bg-red-50">
            <Icon className="w-6 h-6 text-red-600" />
          </div>
        </div>
        <h4 className="text-lg font-semibold text-gray-900">{family.name}</h4>
        <p className="text-2xl font-bold text-red-600 mt-2">
          {getValue()}
        </p>
        <div className="mt-2 space-y-1 text-sm text-gray-600">
          <p>Montant : {formatCurrency(family.value)}</p>
          {family.volume && (
            <p>Volume : {family.volume.toLocaleString('fr-FR')} T</p>
          )}
          <p>{family.percentage.toFixed(1)}% du total</p>
        </div>
      </div>
    </motion.div>
  );
}