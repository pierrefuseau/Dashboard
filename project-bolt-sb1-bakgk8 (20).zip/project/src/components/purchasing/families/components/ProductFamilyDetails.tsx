```typescript
import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { ProductFamily } from '../types';
import { getFamilyIcon } from '../utils/icons';

interface ProductFamilyDetailsProps {
  family: ProductFamily;
  totalValue: number;
  totalVolume: number;
  onClose: () => void;
}

export function ProductFamilyDetails({
  family,
  totalValue,
  totalVolume,
  onClose
}: ProductFamilyDetailsProps) {
  const Icon = getFamilyIcon(family.name);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-50 overflow-y-auto"
      onClick={onClose}
    >
      <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
        <div 
          className="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6"
          onClick={e => e.stopPropagation()}
        >
          <div className="absolute right-0 top-0 pr-4 pt-4">
            <button
              type="button"
              className="rounded-md bg-white text-gray-400 hover:text-gray-500"
              onClick={onClose}
            >
              <span className="sr-only">Fermer</span>
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="sm:flex sm:items-start">
            <div className="mx-auto flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
              <Icon className="h-6 w-6 text-red-600" />
            </div>
            <div className="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
              <h3 className="text-base font-semibold leading-6 text-gray-900">
                {family.name}
              </h3>
              <div className="mt-4 space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Montant</p>
                      <p className="text-lg font-semibold text-red-600">
                        {formatCurrency(family.value)}
                      </p>
                      <p className="text-sm text-gray-500">
                        {family.percentage.toFixed(1)}% du total
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Volume</p>
                      <p className="text-lg font-semibold text-gray-900">
                        {family.volume?.toLocaleString('fr-FR')} T
                      </p>
                      <p className="text-sm text-gray-500">
                        {((family.volume || 0) / totalVolume * 100).toFixed(1)}% du total
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">
                    Évolution sur 12 mois
                  </h4>
                  <div className="h-32">
                    {/* Ici, on pourrait ajouter un mini graphique d'évolution */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
```