import React from 'react';
import { ProductFamily } from '../types';
import { formatMillionsEuros } from '../../../../utils/formatters/currency';

interface PodiumStepProps {
  family: ProductFamily;
  position: 1 | 2 | 3;
  isHovered: boolean;
  onHover: (name: string | null) => void;
}

export function PodiumStep({ family, position, isHovered, onHover }: PodiumStepProps) {
  // Hauteurs relatives des marches du podium
  const heights = {
    1: 'h-48',
    2: 'h-40',
    3: 'h-32'
  };

  // Positions des marches
  const positions = {
    1: 'left-1/2 -translate-x-1/2 bottom-32',
    2: 'left-1/4 -translate-x-1/2 bottom-24',
    3: 'left-3/4 -translate-x-1/2 bottom-16'
  };

  // Largeurs des marches
  const widths = {
    1: 'w-48',
    2: 'w-40',
    3: 'w-40'
  };

  return (
    <div
      className={`absolute ${positions[position]} ${widths[position]} transition-all duration-300 transform hover:scale-105`}
      onMouseEnter={() => onHover(family.name)}
      onMouseLeave={() => onHover(null)}
    >
      {/* Nom de la famille au-dessus de la marche */}
      <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 w-full">
        <div className="text-center">
          <span className="inline-block bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full shadow-sm text-sm font-medium text-gray-900">
            {family.name}
          </span>
        </div>
      </div>

      {/* Marche du podium */}
      <div 
        className={`
          ${heights[position]} 
          bg-gradient-to-br from-red-500 to-red-600 
          rounded-t-lg 
          shadow-lg 
          relative 
          overflow-hidden
        `}
      >
        {/* Effet de brillance */}
        <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent h-1/3" />
        
        {/* Contenu */}
        <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-white">
          {/* Position */}
          <div className="text-4xl font-bold mb-3">
            {position}
          </div>

          {/* Valeur */}
          <div className="text-xl font-semibold text-center mb-2">
            {formatMillionsEuros(family.value)}
          </div>

          {/* Pourcentage */}
          <div className="text-sm mt-1 font-medium bg-black/20 px-2 py-0.5 rounded-full">
            {family.percentage.toFixed(1)}%
          </div>
        </div>
      </div>

      {/* Tooltip amélioré */}
      {isHovered && (
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-full mt-2 bg-white/95 backdrop-blur-sm px-4 py-3 rounded-lg shadow-xl z-50">
          <div className="text-sm font-semibold text-gray-900">{family.name}</div>
          <div className="text-sm font-medium text-gray-700 mt-1">{formatMillionsEuros(family.value)}</div>
          <div className="text-xs text-gray-500 mt-0.5">{family.percentage.toFixed(1)}% du total</div>
        </div>
      )}
    </div>
  );
}