import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '../../../../utils/formatters/currency';
import { ProductFamily } from '../types';

interface FamilyLegendProps {
  families: ProductFamily[];
  activeIndex: number | null;
  onHover: (index: number | null) => void;
}

export function FamilyLegend({ families, activeIndex, onHover }: FamilyLegendProps) {
  return (
    <div className="mt-8 grid grid-cols-3 gap-6">
      {families.map((family, index) => (
        <motion.div
          key={family.name}
          className={`p-4 rounded-lg transition-colors cursor-pointer ${
            activeIndex === index ? 'bg-gray-50' : ''
          }`}
          onMouseEnter={() => onHover(index)}
          onMouseLeave={() => onHover(null)}
          whileHover={{ scale: 1.02 }}
        >
          <div className="flex items-center space-x-3">
            <div className="flex-shrink-0">
              {index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {family.name}
              </p>
              <p className="text-sm text-gray-500">
                {formatCurrency(family.value)}
              </p>
              <div className="mt-2 w-full bg-gray-200 rounded-full h-1.5">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-red-500 to-red-600"
                  style={{ width: `${family.percentage}%` }}
                />
              </div>
              <p className="mt-1 text-xs text-gray-500 text-right">
                {family.percentage.toFixed(1)}%
              </p>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}