import React, { useRef } from 'react';
import { ProductFamily, Dimensions } from '../types';
import { useChartDimensions } from '../hooks/useChartDimensions';
import { calculateBubbleRadius, getBubblePosition } from '../utils/bubbleLayout';
import { Bubble } from './Bubble';

interface BubbleChartProps {
  families: ProductFamily[];
  height: number;
  hoveredFamily: string | null;
  onHover: (name: string | null) => void;
}

export function BubbleChart({
  families,
  height,
  hoveredFamily,
  onHover
}: BubbleChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const dimensions = useChartDimensions(containerRef);
  
  const maxRadius = Math.min(dimensions.width, height) * 0.15;
  const centerX = dimensions.width / 2;
  const centerY = height / 2;

  return (
    <div 
      ref={containerRef}
      className="relative w-full"
      style={{ height: `${height}px` }}
    >
      {families?.map((family, index) => {
        const radius = calculateBubbleRadius(family.percentage, maxRadius);
        const position = getBubblePosition(
          index,
          families.length,
          centerX,
          centerY,
          maxRadius
        );

        return (
          <Bubble
            key={family.name}
            family={family}
            position={position}
            radius={radius}
            index={index}
            total={families.length}
            isHovered={hoveredFamily === family.name}
            onHover={onHover}
          />
        );
      })}
    </div>
  );
}