export interface ProductFamily {
  name: string;
  value: number;
  volume?: number;
  percentage: number;
}

export interface ComparisonData {
  current: ProductFamily[];
  previous: ProductFamily[];
}

export type ViewMode = 'amount' | 'volume' | 'percentage';