import React, { useState } from 'react';
import { Card } from '../../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useSheetData } from '../../../hooks/sheets/useSheetData';
import { ChartModal } from '../../common/ChartModal';
import { Maximize2 } from 'lucide-react';

export function PurchaseVolumeChart() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { data: monthlyData, isLoading } = useSheetData('ACHATS', 'B22:C33', {
    transform: (data) => data.map((row) => ({
      month: row[0],
      amount: Number(row[1]?.replace(/[^0-9.-]/g, '')) || 0
    }))
  });

  if (isLoading) {
    return <div>Chargement des données...</div>;
  }

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0
    }).format(value);

  const renderChart = (height: number = 400) => (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={monthlyData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="month"
          tick={{ fontSize: 12 }}
        />
        <YAxis 
          tickFormatter={formatCurrency}
          tick={{ fontSize: 12 }}
        />
        <Tooltip 
          formatter={(value: number) => [
            formatCurrency(value),
            'Montant'
          ]}
          labelStyle={{ color: '#374151' }}
        />
        <Bar 
          dataKey="amount" 
          fill="#ef4444"
          radius={[4, 4, 0, 0]}
        />
      </BarChart>
    </ResponsiveContainer>
  );

  return (
    <Card>
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Montant d'achats par mois</h3>
          <p className="text-sm text-gray-500">Suivi mensuel des achats</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="p-2 text-gray-400 hover:text-gray-500 focus:outline-none"
        >
          <Maximize2 className="h-5 w-5" />
        </button>
      </div>
      <div className="h-[400px]">
        {renderChart()}
      </div>

      <ChartModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Montant d'achats par mois"
      >
        {renderChart(600)}
      </ChartModal>
    </Card>
  );
}