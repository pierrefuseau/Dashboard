import React from 'react';
import * as Icons from 'lucide-react';
import { Section } from './types';
import { motion, AnimatePresence } from 'framer-motion';

interface PresentationNavigationProps {
  sections: Section[];
  selectedSections: string[];
  selectedSubSections: string[];
  currentSubSection?: string;
  onSectionSelect: (sectionId: string) => void;
  onSubSectionSelect: (subSectionId: string) => void;
  onSlideSelect: (index: number) => void;
}

export function PresentationNavigation({
  sections,
  selectedSections,
  selectedSubSections,
  currentSubSection,
  onSectionSelect,
  onSubSectionSelect,
  onSlideSelect
}: PresentationNavigationProps) {
  return (
    <div className="w-64 bg-gray-800 p-4 overflow-y-auto">
      <div className="space-y-4">
        {sections.map(section => {
          const Icon = Icons[section.icon as keyof typeof Icons];
          const isSelected = selectedSections.includes(section.id);
          const hasSelectedSubSections = section.subsections.some(
            sub => selectedSubSections.includes(sub.id)
          );

          return (
            <div key={section.id} className="space-y-2">
              <button
                onClick={() => onSectionSelect(section.id)}
                className={`w-full flex items-center justify-between px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isSelected
                    ? 'bg-gray-700 text-white'
                    : 'text-gray-300 hover:bg-gray-700/50'
                }`}
              >
                <div className="flex items-center space-x-2">
                  {Icon && <Icon className="w-5 h-5" />}
                  <span>{section.title}</span>
                </div>
                <span className="text-xs bg-gray-600 px-2 py-1 rounded-full">
                  {section.subsections.filter(sub => selectedSubSections.includes(sub.id)).length}/
                  {section.subsections.length}
                </span>
              </button>

              <AnimatePresence>
                {(isSelected || hasSelectedSubSections) && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="ml-4 space-y-1 overflow-hidden"
                  >
                    {section.subsections.map(subSection => {
                      const isSubSelected = selectedSubSections.includes(subSection.id);
                      const isCurrent = currentSubSection === subSection.id;

                      return (
                        <button
                          key={subSection.id}
                          onClick={() => onSubSectionSelect(subSection.id)}
                          className={`w-full flex items-center px-4 py-2 rounded-lg text-sm transition-colors ${
                            isCurrent
                              ? 'bg-blue-600 text-white'
                              : isSubSelected
                              ? 'bg-gray-700 text-white'
                              : 'text-gray-400 hover:bg-gray-700/50'
                          }`}
                        >
                          {subSection.title}
                        </button>
                      );
                    })}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
}