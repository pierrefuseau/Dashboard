import React, { useState, useRef, useEffect } from 'react';
import { X, Maximize2, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { presentationSections } from './config/presentationSections';
import { PresentationNavigation } from './PresentationNavigation';
import { PresentationControls } from './PresentationControls';
import { PresentationProgress } from './PresentationProgress';
import { useFullscreen } from './hooks/useFullscreen';
import { useKeyboardNavigation } from './hooks/useKeyboardNavigation';
import { usePresentationState } from './hooks/usePresentationState';
import { PresentationSlide } from './PresentationSlide';

interface PresentationModeProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PresentationMode({ isOpen, onClose }: PresentationModeProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(false);
  const [slideDuration, setSlideDuration] = useState(10);
  const { isFullscreen, toggleFullscreen } = useFullscreen(containerRef);
  const { selectedSections, selectedSubSections, toggleSection, toggleSubSection } = usePresentationState();

  // Générer la liste des slides basée sur les sections sélectionnées
  const slides = selectedSubSections.map(id => {
    for (const section of presentationSections) {
      const subSection = section.subsections.find(sub => sub.id === id);
      if (subSection) {
        return {
          id: subSection.id,
          title: subSection.title,
          Component: subSection.component,
          sectionId: section.id
        };
      }
    }
    return null;
  }).filter(Boolean);

  // Navigation
  const goToNextSlide = () => {
    if (currentSlideIndex < slides.length - 1) {
      setCurrentSlideIndex(prev => prev + 1);
    }
  };

  const goToPreviousSlide = () => {
    if (currentSlideIndex > 0) {
      setCurrentSlideIndex(prev => prev - 1);
    }
  };

  // Autoplay
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAutoPlaying) {
      interval = setInterval(() => {
        if (currentSlideIndex < slides.length - 1) {
          goToNextSlide();
        } else {
          setIsAutoPlaying(false);
        }
      }, slideDuration * 1000);
    }
    return () => clearInterval(interval);
  }, [isAutoPlaying, currentSlideIndex, slides.length, slideDuration]);

  // Keyboard navigation
  useKeyboardNavigation({
    onNext: goToNextSlide,
    onPrevious: goToPreviousSlide,
    onEscape: onClose,
    isEnabled: isOpen
  });

  if (!isOpen) return null;

  const CurrentSlideComponent = slides[currentSlideIndex]?.Component;

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 bg-gray-900 z-50 flex"
    >
      {/* Navigation latérale */}
      <div className="w-64 bg-gray-800 overflow-y-auto">
        <PresentationNavigation
          sections={presentationSections}
          selectedSections={selectedSections}
          selectedSubSections={selectedSubSections}
          currentSubSection={slides[currentSlideIndex]?.id}
          onSectionSelect={toggleSection}
          onSubSectionSelect={toggleSubSection}
          onSlideSelect={setCurrentSlideIndex}
        />
      </div>

      {/* Zone principale */}
      <div className="flex-1 flex flex-col relative">
        {/* Barre d'outils */}
        <div className="absolute top-0 right-0 p-4 flex items-center space-x-4">
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-full text-white hover:bg-white/10"
          >
            <Maximize2 className="w-5 h-5" />
          </button>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contenu de la slide */}
        <div className="flex-1 p-8">
          <AnimatePresence mode="wait">
            {CurrentSlideComponent && (
              <PresentationSlide isVisible={true}>
                <CurrentSlideComponent />
              </PresentationSlide>
            )}
          </AnimatePresence>
        </div>

        {/* Contrôles */}
        <div className="p-4 bg-gray-800">
          <PresentationControls
            currentSlide={currentSlideIndex}
            totalSlides={slides.length}
            isAutoPlaying={isAutoPlaying}
            onPrevious={goToPreviousSlide}
            onNext={goToNextSlide}
            onToggleAutoPlay={() => setIsAutoPlaying(!isAutoPlaying)}
            duration={slideDuration}
            onUpdateDuration={setSlideDuration}
          />
          <PresentationProgress
            current={currentSlideIndex}
            total={slides.length}
          />
        </div>
      </div>
    </div>
  );
}