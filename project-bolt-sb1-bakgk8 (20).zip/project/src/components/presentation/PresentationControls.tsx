import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Settings } from 'lucide-react';

interface PresentationControlsProps {
  currentSlide: number;
  totalSlides: number;
  isAutoPlaying: boolean;
  onPrevious: () => void;
  onNext: () => void;
  onToggleAutoPlay: () => void;
  duration: number;
  onUpdateDuration: (duration: number) => void;
}

export function PresentationControls({
  currentSlide,
  totalSlides,
  isAutoPlaying,
  onPrevious,
  onNext,
  onToggleAutoPlay,
  duration,
  onUpdateDuration
}: PresentationControlsProps) {
  return (
    <div className="flex items-center justify-between p-4 bg-gray-800 border-t border-gray-700">
      <div className="flex items-center space-x-4">
        <button
          onClick={onPrevious}
          disabled={currentSlide === 0}
          className="p-2 rounded-full text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <SkipBack className="w-5 h-5" />
        </button>

        <button
          onClick={onToggleAutoPlay}
          className="p-2 rounded-full text-white hover:bg-white/10"
        >
          {isAutoPlaying ? (
            <Pause className="w-5 h-5" />
          ) : (
            <Play className="w-5 h-5" />
          )}
        </button>

        <button
          onClick={onNext}
          disabled={currentSlide === totalSlides - 1}
          className="p-2 rounded-full text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <SkipForward className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-2">
          <input
            type="number"
            min="1"
            max="60"
            value={duration}
            onChange={(e) => onUpdateDuration(Number(e.target.value))}
            className="w-16 px-2 py-1 bg-gray-700 text-white rounded border border-gray-600 focus:outline-none focus:border-blue-500"
          />
          <span className="text-sm text-gray-300">sec</span>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <span className="text-sm text-gray-300">
          {currentSlide + 1} / {totalSlides}
        </span>
      </div>
    </div>
  );
}