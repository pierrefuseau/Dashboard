import { Section } from '../types';
import {
  BarChart3,
  ShoppingCart,
  Users,
  Truck,
  ClipboardCheck,
  ShoppingBag
} from 'lucide-react';

// Import all components
import { SalesOverview } from '../../sales/metrics/SalesOverview';
import { TopClientsTable } from '../../sales/clients/TopClientsTable';
import { TopFamiliesTable } from '../../sales/families/TopFamiliesTable';
import { TopCategoriesTable } from '../../sales/categories/TopCategoriesTable';
import { TopSegmentsTable } from '../../sales/segments/TopSegmentsTable';
import { TopProductsCharts } from '../../sales/products/TopProductsCharts';
import { SalesMap } from '../../sales/map/SalesMap';

import { PurchaseOverview } from '../../purchasing/metrics/PurchaseOverview';
import { SupplierPerformanceTable } from '../../purchasing/suppliers/SupplierPerformanceTable';
import { PurchaseOriginChart } from '../../purchasing/origin/PurchaseOriginChart';
import { PurchaseVolumeChart } from '../../purchasing/volume/PurchaseVolumeChart';

import { HRPage } from '../../../pages/hr/HRPage';
import { EmployeeDistributionCharts } from '../../hr/distribution/EmployeeDistributionCharts';
import { HRCostsTable } from '../../hr/costs/HRCostsTable';
import { EmployeeMovementsTable } from '../../hr/movements/EmployeeMovementsTable';

import { LogisticsPage } from '../../../pages/logistics/LogisticsPage';
import { ServiceRateTable } from '../../logistics/service/ServiceRateTable';
import { StockIndicatorsTable } from '../../logistics/stock/StockIndicatorsTable';
import { TransportIndicatorsTable } from '../../logistics/transport/TransportIndicatorsTable';

import { QualityPage } from '../../../pages/quality/QualityPage';
import { QualityIndicatorsTable } from '../../quality/indicators/QualityIndicatorsTable';
import { NonConformityTable } from '../../quality/conformity/NonConformityTable';
import { QualityTrendsChart } from '../../quality/trends/QualityTrendsChart';

import { BoutiquePage } from '../../../pages/boutique/BoutiquePage';
import { TopProductsTable as BoutiqueProductsTable } from '../../boutique/products/TopProductsTable';
import { ProductMarginChart } from '../../boutique/margins/ProductMarginChart';
import { ProductVolumeChart } from '../../boutique/volume/ProductVolumeChart';

export const presentationSections: Section[] = [
  {
    id: 'sales',
    title: 'Ventes',
    icon: BarChart3,
    subsections: [
      { id: 'sales-overview', title: 'Vue d\'ensemble', component: SalesOverview },
      { id: 'sales-clients', title: 'Clients', component: TopClientsTable },
      { id: 'sales-families', title: 'Groupes Clients', component: TopFamiliesTable },
      { id: 'sales-categories', title: 'Commerciaux', component: TopCategoriesTable },
      { id: 'sales-segments', title: 'Professions', component: TopSegmentsTable },
      { id: 'sales-products', title: 'Produits', component: TopProductsCharts },
      { id: 'sales-map', title: 'Carte', component: SalesMap }
    ]
  },
  {
    id: 'purchasing',
    title: 'Achats',
    icon: ShoppingCart,
    subsections: [
      { id: 'purchasing-overview', title: 'Vue d\'ensemble', component: PurchaseOverview },
      { id: 'purchasing-suppliers', title: 'Fournisseurs', component: SupplierPerformanceTable },
      { id: 'purchasing-origin', title: 'Origine', component: PurchaseOriginChart },
      { id: 'purchasing-volume', title: 'Volume', component: PurchaseVolumeChart }
    ]
  },
  {
    id: 'hr',
    title: 'Ressources Humaines',
    icon: Users,
    subsections: [
      { id: 'hr-overview', title: 'Vue d\'ensemble', component: HRPage },
      { id: 'hr-distribution', title: 'Distribution', component: EmployeeDistributionCharts },
      { id: 'hr-costs', title: 'Coûts', component: HRCostsTable },
      { id: 'hr-movements', title: 'Mouvements', component: EmployeeMovementsTable }
    ]
  },
  {
    id: 'logistics',
    title: 'Logistique',
    icon: Truck,
    subsections: [
      { id: 'logistics-overview', title: 'Vue d\'ensemble', component: LogisticsPage },
      { id: 'logistics-service', title: 'Taux de Service', component: ServiceRateTable },
      { id: 'logistics-stock', title: 'Indicateurs Stock', component: StockIndicatorsTable },
      { id: 'logistics-transport', title: 'Transport', component: TransportIndicatorsTable }
    ]
  },
  {
    id: 'quality',
    title: 'Qualité',
    icon: ClipboardCheck,
    subsections: [
      { id: 'quality-overview', title: 'Vue d\'ensemble', component: QualityPage },
      { id: 'quality-indicators', title: 'Indicateurs', component: QualityIndicatorsTable },
      { id: 'quality-conformity', title: 'Non-conformités', component: NonConformityTable },
      { id: 'quality-trends', title: 'Tendances', component: QualityTrendsChart }
    ]
  },
  {
    id: 'boutique',
    title: 'La Boutique',
    icon: ShoppingBag,
    subsections: [
      { id: 'boutique-overview', title: 'Vue d\'ensemble', component: BoutiquePage },
      { id: 'boutique-products', title: 'Top Produits', component: BoutiqueProductsTable },
      { id: 'boutique-margins', title: 'Marges', component: ProductMarginChart },
      { id: 'boutique-volume', title: 'Volume', component: ProductVolumeChart }
    ]
  }
];