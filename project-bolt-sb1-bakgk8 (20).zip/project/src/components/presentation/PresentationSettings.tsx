import React from 'react';
import { X, GripVertical } from 'lucide-react';
import { Slide } from './types';

interface PresentationSettingsProps {
  slides: Slide[];
  selectedSlides: string[];
  onSelectedSlidesChange: (slides: string[]) => void;
  onClose: () => void;
}

export function PresentationSettings({
  slides,
  selectedSlides,
  onSelectedSlidesChange,
  onClose
}: PresentationSettingsProps) {
  const toggleSlide = (slideId: string) => {
    if (selectedSlides.includes(slideId)) {
      onSelectedSlidesChange(selectedSlides.filter(id => id !== slideId));
    } else {
      onSelectedSlidesChange([...selectedSlides, slideId]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="text-lg font-medium">Paramètres de présentation</h3>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-500 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-700">Slides à afficher</h4>
            {slides.map((slide) => (
              <div
                key={slide.id}
                className="flex items-center space-x-3 p-2 bg-gray-50 rounded-lg"
              >
                <GripVertical className="w-5 h-5 text-gray-400" />
                <input
                  type="checkbox"
                  checked={selectedSlides.includes(slide.id)}
                  onChange={() => toggleSlide(slide.id)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">{slide.title}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end p-4 border-t">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
}