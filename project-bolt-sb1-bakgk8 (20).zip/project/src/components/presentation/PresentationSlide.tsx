import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PresentationSlideProps {
  children: React.ReactNode;
  isVisible: boolean;
}

export function PresentationSlide({ children, isVisible }: PresentationSlideProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="h-full w-full"
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
}