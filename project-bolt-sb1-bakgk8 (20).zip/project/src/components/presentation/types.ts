import { ComponentType } from 'react';
import { LucideIcon } from 'lucide-react';

export interface SubSection {
  id: string;
  title: string;
  component: ComponentType;
  duration?: number;
}

export interface Section {
  id: string;
  title: string;
  icon: string;
  subsections: SubSection[];
}

export interface PresentationState {
  selectedSections: string[];
  selectedSubSections: string[];
  autoPlay: boolean;
  defaultDuration: number;
}