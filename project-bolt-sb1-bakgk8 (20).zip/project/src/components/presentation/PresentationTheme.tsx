import React from 'react';
import { useTheme } from '../../theme/ThemeProvider';
import { Theme } from '../../theme/types';

interface PresentationThemeProps {
  children: React.ReactNode;
}

export function PresentationTheme({ children }: PresentationThemeProps) {
  const { mode } = useTheme();

  const presentationTheme: Theme = {
    id: 'presentation',
    name: 'Mode Présentation',
    colors: {
      primary: mode === 'dark' ? '#1f2937' : '#ffffff',
      secondary: mode === 'dark' ? '#111827' : '#f3f4f6',
      background: mode === 'dark' ? '#000000' : '#ffffff',
      surface: mode === 'dark' ? '#111827' : '#f8fafc',
      text: mode === 'dark' ? '#f9fafb' : '#111827',
      textSecondary: mode === 'dark' ? '#9ca3af' : '#4b5563',
      border: mode === 'dark' ? '#374151' : '#e5e7eb',
      success: mode === 'dark' ? '#34d399' : '#22c55e',
      warning: mode === 'dark' ? '#fbbf24' : '#f59e0b',
      error: mode === 'dark' ? '#f87171' : '#ef4444',
      info: mode === 'dark' ? '#60a5fa' : '#3b82f6'
    },
    fonts: {
      primary: 'Inter, system-ui, sans-serif',
      secondary: 'system-ui, sans-serif'
    }
  };

  return (
    <div
      className="presentation-theme"
      style={{
        '--color-primary': presentationTheme.colors.primary,
        '--color-secondary': presentationTheme.colors.secondary,
        '--color-background': presentationTheme.colors.background,
        '--color-surface': presentationTheme.colors.surface,
        '--color-text': presentationTheme.colors.text,
        '--color-text-secondary': presentationTheme.colors.textSecondary,
        '--color-border': presentationTheme.colors.border,
        '--color-success': presentationTheme.colors.success,
        '--color-warning': presentationTheme.colors.warning,
        '--color-error': presentationTheme.colors.error,
        '--color-info': presentationTheme.colors.info,
        '--font-primary': presentationTheme.fonts.primary,
        '--font-secondary': presentationTheme.fonts.secondary,
      } as React.CSSProperties}
    >
      {children}
    </div>
  );
}