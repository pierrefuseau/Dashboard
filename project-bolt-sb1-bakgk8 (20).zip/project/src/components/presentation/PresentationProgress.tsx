import React from 'react';

interface PresentationProgressProps {
  current: number;
  total: number;
}

export function PresentationProgress({ current, total }: PresentationProgressProps) {
  const percentage = ((current + 1) / total) * 100;

  return (
    <div className="w-full bg-gray-200 h-1 rounded-full overflow-hidden">
      <div
        className="bg-blue-500 h-full transition-all duration-300 ease-in-out"
        style={{ width: `${percentage}%` }}
      />
    </div>
  );
}