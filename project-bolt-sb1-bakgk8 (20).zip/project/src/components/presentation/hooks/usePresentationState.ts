import { useState, useCallback, useEffect } from 'react';
import { presentationSections } from '../config/presentationSections';

export function usePresentationState() {
  // État initial : toutes les sections sont sélectionnées par défaut
  const [selectedSections, setSelectedSections] = useState<string[]>(
    presentationSections.map(section => section.id)
  );
  
  // État initial : toutes les sous-sections sont sélectionnées par défaut
  const [selectedSubSections, setSelectedSubSections] = useState<string[]>(
    presentationSections.flatMap(section => section.subsections.map(sub => sub.id))
  );

  const toggleSection = useCallback((sectionId: string) => {
    setSelectedSections(prev => {
      const isSelected = prev.includes(sectionId);
      const section = presentationSections.find(s => s.id === sectionId);
      const subSectionIds = section?.subsections.map(sub => sub.id) || [];

      if (isSelected) {
        // Désélectionner la section et ses sous-sections
        setSelectedSubSections(prev => prev.filter(id => !subSectionIds.includes(id)));
        return prev.filter(id => id !== sectionId);
      } else {
        // Sélectionner la section et ses sous-sections
        setSelectedSubSections(prev => [...new Set([...prev, ...subSectionIds])]);
        return [...prev, sectionId];
      }
    });
  }, []);

  const toggleSubSection = useCallback((subSectionId: string) => {
    setSelectedSubSections(prev => {
      const isSelected = prev.includes(subSectionId);
      
      // Trouver la section parente
      const parentSection = presentationSections.find(section =>
        section.subsections.some(sub => sub.id === subSectionId)
      );

      if (isSelected) {
        // Si c'est la dernière sous-section de la section, désélectionner aussi la section
        const remainingSubSections = prev.filter(id => id !== subSectionId);
        const hasOtherSubSectionsInSection = parentSection?.subsections.some(
          sub => sub.id !== subSectionId && remainingSubSections.includes(sub.id)
        );

        if (!hasOtherSubSectionsInSection && parentSection) {
          setSelectedSections(prev => prev.filter(id => id !== parentSection.id));
        }

        return remainingSubSections;
      } else {
        // Si on sélectionne une sous-section, sélectionner aussi sa section parente
        if (parentSection && !selectedSections.includes(parentSection.id)) {
          setSelectedSections(prev => [...prev, parentSection.id]);
        }
        return [...prev, subSectionId];
      }
    });
  }, [selectedSections]);

  // Maintenir la cohérence entre les sections et sous-sections
  useEffect(() => {
    const validSubSections = selectedSubSections.filter(subSectionId => {
      const parentSection = presentationSections.find(section =>
        section.subsections.some(sub => sub.id === subSectionId)
      );
      return parentSection && selectedSections.includes(parentSection.id);
    });

    if (validSubSections.length !== selectedSubSections.length) {
      setSelectedSubSections(validSubSections);
    }
  }, [selectedSections, selectedSubSections]);

  return {
    selectedSections,
    selectedSubSections,
    toggleSection,
    toggleSubSection,
    setSelectedSections,
    setSelectedSubSections
  };
}