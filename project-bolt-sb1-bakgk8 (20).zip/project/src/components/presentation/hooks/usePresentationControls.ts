import { useState, useCallback, useEffect } from 'react';
import { Slide } from '../types';

interface PresentationControlsOptions {
  slides: Slide[];
  autoPlayDuration?: number;
}

export function usePresentationControls({ slides, autoPlayDuration = 10000 }: PresentationControlsOptions) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isAutoPlaying, setIsAutoPlaying] = useState(false);
  const [customDuration, setCustomDuration] = useState(autoPlayDuration);

  const nextSlide = useCallback(() => {
    if (currentSlide < slides.length - 1) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentSlide(prev => prev + 1);
        setIsTransitioning(false);
      }, 300);
    }
  }, [currentSlide, slides.length]);

  const previousSlide = useCallback(() => {
    if (currentSlide > 0) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentSlide(prev => prev - 1);
        setIsTransitioning(false);
      }, 300);
    }
  }, [currentSlide]);

  const goToSlide = useCallback((index: number) => {
    if (index >= 0 && index < slides.length) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentSlide(index);
        setIsTransitioning(false);
      }, 300);
    }
  }, [slides.length]);

  const toggleAutoPlay = useCallback(() => {
    setIsAutoPlaying(prev => !prev);
  }, []);

  const updateDuration = useCallback((duration: number) => {
    setCustomDuration(duration * 1000); // Convert seconds to milliseconds
  }, []);

  useEffect(() => {
    let autoPlayInterval: NodeJS.Timeout;

    if (isAutoPlaying) {
      autoPlayInterval = setInterval(() => {
        if (currentSlide < slides.length - 1) {
          nextSlide();
        } else {
          setIsAutoPlaying(false);
        }
      }, customDuration);
    }

    return () => {
      if (autoPlayInterval) {
        clearInterval(autoPlayInterval);
      }
    };
  }, [isAutoPlaying, currentSlide, slides.length, customDuration, nextSlide]);

  return {
    currentSlide,
    isTransitioning,
    isAutoPlaying,
    customDuration,
    nextSlide,
    previousSlide,
    goToSlide,
    toggleAutoPlay,
    updateDuration
  };
}