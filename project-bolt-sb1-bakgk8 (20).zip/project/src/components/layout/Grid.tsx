import React from 'react';
import { cn } from '../../utils/cn';

interface GridProps {
  children: React.ReactNode;
  className?: string;
  cols?: 1 | 2 | 3 | 4 | 6;
  gap?: 'sm' | 'md' | 'lg';
  fluid?: boolean;
  minWidth?: string;
}

export function Grid({ 
  children, 
  className,
  cols = 1,
  gap = 'md',
  fluid = false,
  minWidth = '300px'
}: GridProps) {
  const gapClasses = {
    sm: 'gap-4',
    md: 'gap-6',
    lg: 'gap-8'
  };

  const colClasses = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 sm:grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4',
    6: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6'
  };

  return (
    <div className={cn(
      "grid",
      fluid 
        ? `grid-cols-[repeat(auto-fit,minmax(min(100%,${minWidth}),1fr))]`
        : colClasses[cols],
      gapClasses[gap],
      className
    )}>
      {children}
    </div>
  );
}