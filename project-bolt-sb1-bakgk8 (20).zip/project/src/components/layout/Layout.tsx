import React, { useState } from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { UserProfileButton } from '../user/UserProfileButton';
import { Logo } from './header/Logo';
import { CompanySelector } from '../dashboard/CompanySelector';
import { AIAssistant } from '../ai/AIAssistant';
import { cn } from '../../utils/cn';
import { Menu, X } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

export function Layout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user } = useAuthStore();

  // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
  if (!user) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] flex">
      {/* Overlay pour mobile */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar avec gestion mobile */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-40 w-64 bg-white transform transition-transform duration-300 ease-in-out lg:translate-x-0",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          {/* Contenu principal de la sidebar */}
          <div className="flex-1 overflow-y-auto">
            <Sidebar onClose={() => setIsSidebarOpen(false)} />
          </div>
          
          {/* Boutons en bas de la sidebar */}
          <div className="p-4 space-y-2">
            <AIAssistant />
            <CompanySelector />
            <UserProfileButton />
          </div>
        </div>
      </div>
      
      {/* Contenu principal */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Header fixe */}
        <header className="fixed top-0 right-0 left-0 lg:left-64 bg-white border-b border-gray-200 h-16 z-50">
          <div className="h-full max-w-[2000px] mx-auto px-4 lg:px-8">
            <div className="h-full flex items-center justify-between">
              <div className="flex items-center">
                {/* Bouton menu mobile */}
                <button
                  onClick={() => setIsSidebarOpen(true)}
                  className="p-2 -ml-2 mr-2 text-gray-600 rounded-lg lg:hidden hover:bg-gray-100"
                >
                  <Menu className="w-6 h-6" />
                </button>
                <Logo />
              </div>
            </div>
          </div>
        </header>

        {/* Contenu principal scrollable */}
        <main className={cn(
          "flex-1 w-full transition-all duration-300",
          "p-4 sm:p-6 lg:p-8",
          "mt-16", // Espace pour le header
          "lg:ml-64" // Espace pour la sidebar sur desktop
        )}>
          <div className="max-w-[2000px] mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}