import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Logo } from './header/Logo';
import { UserMenu } from './header/UserMenu';
import { NavigationMenu } from './header/NavigationMenu';
import { cn } from '../../utils/cn';

interface HeaderProps {
  onMenuClick?: () => void;
}

export function Header({ onMenuClick }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleMenuClick = () => {
    setIsMenuOpen(!isMenuOpen);
    onMenuClick?.();
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-50">
      <div className="max-w-[2000px] mx-auto">
        {/* Barre principale */}
        <div className="relative flex items-center justify-between px-4 sm:px-6 lg:px-8 h-16 sm:h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <Logo />
          </div>

          {/* Navigation desktop */}
          <div className="hidden lg:flex lg:flex-1 lg:items-center lg:justify-end">
            <NavigationMenu />
            <div className="ml-8">
              <UserMenu />
            </div>
          </div>

          {/* Bouton menu mobile */}
          <div className="flex items-center lg:hidden">
            <button
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
              onClick={handleMenuClick}
            >
              <span className="sr-only">
                {isMenuOpen ? 'Fermer le menu' : 'Ouvrir le menu'}
              </span>
              {isMenuOpen ? (
                <X className="block h-6 w-6" />
              ) : (
                <Menu className="block h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Menu mobile */}
        <div
          className={cn(
            "lg:hidden",
            "fixed inset-0 top-16 sm:top-20 z-40 transform transition-transform duration-300 ease-in-out bg-white overflow-y-auto",
            isMenuOpen ? "translate-x-0" : "translate-x-full"
          )}
        >
          <div className="px-4 pt-4 pb-6 space-y-6">
            <NavigationMenu mobile />
            <div className="mt-6 pt-6 border-t border-gray-200">
              <UserMenu mobile />
            </div>
          </div>
        </div>

        {/* Overlay mobile */}
        {isMenuOpen && (
          <div 
            className="lg:hidden fixed inset-0 bg-black bg-opacity-25 z-30"
            aria-hidden="true"
            onClick={() => setIsMenuOpen(false)}
          />
        )}
      </div>
    </header>
  );
}