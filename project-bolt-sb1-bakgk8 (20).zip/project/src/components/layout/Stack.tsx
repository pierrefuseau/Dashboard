import React from 'react';
import { cn } from '../../utils/cn';

interface StackProps {
  children: React.ReactNode;
  className?: string;
  spacing?: 'sm' | 'md' | 'lg';
  direction?: 'row' | 'col';
  align?: 'start' | 'center' | 'end' | 'stretch';
  justify?: 'start' | 'center' | 'end' | 'between' | 'around';
}

export function Stack({
  children,
  className,
  spacing = 'md',
  direction = 'col',
  align = 'stretch',
  justify = 'start'
}: StackProps) {
  const spacingClasses = {
    sm: direction === 'col' ? 'space-y-4' : 'space-x-4',
    md: direction === 'col' ? 'space-y-6' : 'space-x-6',
    lg: direction === 'col' ? 'space-y-8' : 'space-x-8'
  };

  const alignClasses = {
    start: 'items-start',
    center: 'items-center',
    end: 'items-end',
    stretch: 'items-stretch'
  };

  const justifyClasses = {
    start: 'justify-start',
    center: 'justify-center',
    end: 'justify-end',
    between: 'justify-between',
    around: 'justify-around'
  };

  return (
    <div className={cn(
      "flex",
      direction === 'col' ? 'flex-col' : 'flex-row',
      spacingClasses[spacing],
      alignClasses[align],
      justifyClasses[justify],
      className
    )}>
      {children}
    </div>
  );
}