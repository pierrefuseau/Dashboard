import React from 'react';
import { Link } from 'react-router-dom';

export function Logo() {
  return (
    <Link to="/" className="flex items-center">
      <img
        src="https://www.fuseau-sas.com/media/952906/1/0/1/Logo-nouvelle-couleur+%281%29.png"
        alt="FUSEAU"
        className="h-16 sm:h-20 md:h-24 w-auto object-contain transition-transform hover:scale-105"
        style={{
          minWidth: '180px',
          maxWidth: '300px'
        }}
        onError={(e) => {
          e.currentTarget.onerror = null;
          e.currentTarget.src = 'https://www.fuseau-sas.com/frontend/images/logo-fuseau.png';
        }}
      />
    </Link>
  );
}