import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../../../utils/cn';
import { NavigationMenu } from './NavigationMenu';
import { SearchForm } from './SearchForm';
import { UserMenu } from './UserMenu';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={onClose}
            aria-hidden="true"
          />

          {/* Menu Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.3 }}
            className={cn(
              "fixed inset-y-0 right-0 w-full max-w-sm bg-white shadow-xl z-50",
              "flex flex-col lg:hidden",
              "transition-transform duration-300 ease-in-out"
            )}
          >
            {/* En-tête du menu */}
            <div className="px-4 py-6 border-b border-gray-200">
              <SearchForm />
            </div>

            {/* Navigation */}
            <div className="flex-1 px-4 py-6 overflow-y-auto">
              <NavigationMenu mobile onItemClick={onClose} />
            </div>

            {/* Pied avec menu utilisateur */}
            <div className="px-4 py-6 border-t border-gray-200">
              <UserMenu mobile />
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}