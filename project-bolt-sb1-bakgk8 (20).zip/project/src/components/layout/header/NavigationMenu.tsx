import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home,
  BarChart3, 
  ShoppingCart, 
  Calculator,
  Users, 
  Truck, 
  ClipboardCheck, 
  ShoppingBag,
  Leaf
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../../../utils/cn';

interface NavigationMenuProps {
  mobile?: boolean;
  onItemClick?: () => void;
}

const navigation = [
  { name: 'Accueil', href: '/', icon: Home },
  { name: 'Ventes', href: '/sales', icon: BarChart3 },
  { name: 'Achats', href: '/purchasing', icon: ShoppingCart },
  { name: 'Comptabilité', href: '/accounting', icon: Calculator },
  { name: 'RH', href: '/hr', icon: Users },
  { name: 'Logistique', href: '/logistics', icon: Truck },
  { name: 'Qualité', href: '/quality', icon: ClipboardCheck },
  { name: 'La Boutique', href: '/boutique', icon: ShoppingBag },
  { name: 'RSE', href: '/rse', icon: Leaf }
];

export function NavigationMenu({ mobile = false, onItemClick }: NavigationMenuProps) {
  return (
    <nav 
      className={cn(
        mobile ? "flex flex-col space-y-1" : "hidden lg:flex items-center space-x-4",
        "w-full"
      )}
      role="navigation"
      aria-label="Navigation principale"
    >
      <AnimatePresence>
        {navigation.map((item, index) => {
          const Icon = item.icon;
          
          return (
            <motion.div
              key={item.name}
              initial={mobile ? { opacity: 0, x: -20 } : false}
              animate={{ opacity: 1, x: 0 }}
              exit={mobile ? { opacity: 0, x: -20 } : undefined}
              transition={{ duration: 0.2, delay: mobile ? index * 0.05 : 0 }}
              className="w-full"
            >
              <NavLink
                to={item.href}
                onClick={onItemClick}
                className={({ isActive }) => cn(
                  "group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-200",
                  mobile ? "w-full text-base" : "text-sm",
                  isActive
                    ? "bg-gray-100 text-gray-900"
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
                  "focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                )}
              >
                <Icon 
                  className={cn(
                    "flex-shrink-0 mr-3",
                    mobile ? "h-6 w-6" : "h-5 w-5",
                    "text-gray-400 group-hover:text-gray-500 transition-colors"
                  )}
                  aria-hidden="true"
                />
                <span>{item.name}</span>
              </NavLink>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </nav>
  );
}