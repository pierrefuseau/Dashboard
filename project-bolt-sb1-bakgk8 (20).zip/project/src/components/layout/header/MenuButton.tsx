import React from 'react';
import { Menu, X } from 'lucide-react';
import { cn } from '../../../utils/cn';

interface MenuButtonProps {
  isOpen: boolean;
  onClick: () => void;
  className?: string;
}

export function MenuButton({ isOpen, onClick, className }: MenuButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex items-center justify-center p-2",
        "rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100",
        "focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500",
        "transition-colors duration-200",
        className
      )}
      aria-expanded={isOpen}
      aria-controls="mobile-menu"
      aria-label={isOpen ? "Fermer le menu" : "Ouvrir le menu"}
    >
      <span className="sr-only">
        {isOpen ? 'Fermer le menu' : 'Ouvrir le menu'}
      </span>
      {isOpen ? (
        <X className="block h-6 w-6" aria-hidden="true" />
      ) : (
        <Menu className="block h-6 w-6" aria-hidden="true" />
      )}
    </button>
  );
}