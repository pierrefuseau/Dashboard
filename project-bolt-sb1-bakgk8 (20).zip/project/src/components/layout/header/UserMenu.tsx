import React, { useState, useRef, useEffect } from 'react';
import { LogOut } from 'lucide-react';
import { useAuth } from '../../../hooks/auth/useAuth';
import { cn } from '../../../utils/cn';

interface UserMenuProps {
  mobile?: boolean;
}

export function UserMenu({ mobile = false }: UserMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const { user, logout } = useAuth();

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!user) return null;

  if (mobile) {
    return (
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <img
            src={user.picture}
            alt=""
            className="h-10 w-10 rounded-full"
          />
          <div className="ml-3">
            <div className="text-base font-medium text-gray-800">{user.name}</div>
            <div className="text-sm font-medium text-gray-500">{user.email}</div>
          </div>
        </div>
        <button
          onClick={logout}
          className="ml-auto flex-shrink-0 bg-white p-2 rounded-md text-gray-400 hover:text-gray-500"
        >
          <span className="sr-only">Se déconnecter</span>
          <LogOut className="h-6 w-6" aria-hidden="true" />
        </button>
      </div>
    );
  }

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-50"
      >
        <img
          src={user.picture}
          alt=""
          className="h-8 w-8 rounded-full"
        />
        <span className="text-sm font-medium text-gray-700">{user.name}</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-50">
          <button
            onClick={logout}
            className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
          >
            <LogOut className="mr-3 h-4 w-4" />
            Déconnexion
          </button>
        </div>
      )}
    </div>
  );
}