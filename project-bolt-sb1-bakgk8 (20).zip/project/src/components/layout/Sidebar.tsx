import React from 'react';
import { 
  Home,
  BarChart3, 
  ShoppingCart, 
  Calculator,
  Users, 
  Truck, 
  ClipboardCheck, 
  ShoppingBag,
  Leaf
} from 'lucide-react';
import { NavigationLink } from "../../components/navigation/NavigationLink";
import { useAuthStore } from "../../store/authStore";

const navigation = [
  { name: 'Accueil', href: '/', icon: Home, permission: null },
  { name: 'Ventes', href: '/sales', icon: BarChart3, permission: 'VENTES' },
  { name: 'Achats', href: '/purchasing', icon: ShoppingCart, permission: 'ACHATS' },
  { name: 'Comptabilité', href: '/accounting', icon: Calculator, permission: 'COMPTA' },
  { name: 'RH', href: '/hr', icon: Users, permission: 'RH' },
  { name: 'Logistique', href: '/logistics', icon: Truck, permission: 'LOGISTIQUE' },
  { name: 'Qualité', href: '/quality', icon: ClipboardCheck, permission: 'QUALITE' },
  { name: 'La Boutique', href: '/boutique', icon: ShoppingBag, permission: 'BOUTIQUE' },
  { name: 'RSE', href: '/rse', icon: Leaf, permission: 'RSE' }
];

export function Sidebar() {
  const { user } = useAuthStore();
  
  // Filtrer les liens de navigation en fonction des permissions de l'utilisateur
  const filteredNavigation = navigation.filter(item => {
    // Si aucune permission n'est requise, afficher le lien
    if (!item.permission) return true;
    
    // Si l'utilisateur n'a pas de permissions, ne pas afficher le lien
    if (!user?.permissions) return false;
    
    // Si l'utilisateur est ADMIN, afficher tous les liens
    if (user.permissions.includes('ADMIN')) return true;
    
    // Afficher le lien si l'utilisateur a la permission requise
    return user.permissions.includes(item.permission);
  });

  return (
    <div className="w-64 bg-white border-r border-gray-200 min-h-screen">
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {filteredNavigation.map((item) => (
            <NavigationLink
              key={item.name}
              name={item.name}
              href={item.href}
              icon={item.icon}
            />
          ))}
        </div>
      </nav>
    </div>
  );
}