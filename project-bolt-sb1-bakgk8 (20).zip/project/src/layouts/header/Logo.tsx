import React from 'react';
import { Link } from 'react-router-dom';

export function Logo() {
  return (
    <Link to="/" className="flex items-center">
      <img
        src="https://www.fuseau-sas.com/frontend/images/logo-fuseau.png"
        alt="FUSEAU"
        className="h-16 sm:h-20 md:h-24 w-auto object-contain transition-transform hover:scale-105"
        style={{
          minWidth: '180px', // Assure une largeur minimale
          maxWidth: '300px', // Limite la largeur maximale
          objectFit: 'contain', // Maintient les proportions
          height: 'auto' // Permet à la hauteur de s'ajuster
        }}
        onError={(e) => {
          // Fallback en cas d'erreur de chargement
          e.currentTarget.onerror = null;
          e.currentTarget.src = '/logo-fuseau-fallback.png';
        }}
      />
    </Link>
  );
}