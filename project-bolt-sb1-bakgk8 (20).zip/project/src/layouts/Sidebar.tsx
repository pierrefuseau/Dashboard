import React from 'react';
import { 
  Home,
  BarChart3, 
  ShoppingCart, 
  Calculator,
  Users, 
  Truck, 
  ClipboardCheck, 
  ShoppingBag,
  Leaf
} from 'lucide-react';
import { NavigationLink } from '../components/navigation/NavigationLink';

const navigation = [
  { name: 'Accueil', href: '/', icon: Home },
  { name: 'Ventes', href: '/sales', icon: BarChart3 },
  { name: 'Achats', href: '/purchasing', icon: ShoppingCart },
  { name: 'Comptabilité', href: '/accounting', icon: Calculator },
  { name: 'RH', href: '/hr', icon: Users },
  { name: 'Logistique', href: '/logistics', icon: Truck },
  { name: 'Qualité', href: '/quality', icon: ClipboardCheck },
  { name: 'La Boutique', href: '/boutique', icon: ShoppingBag },
  { name: 'RSE', href: '/rse', icon: Leaf }
];

export function Sidebar() {
  return (
    <div className="w-64 bg-white border-r border-gray-200 min-h-screen">
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {navigation.map((item) => (
            <NavigationLink
              key={item.name}
              name={item.name}
              href={item.href}
              icon={item.icon}
            />
          ))}
        </div>
      </nav>
    </div>
  );
}