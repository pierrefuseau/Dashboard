import React from 'react';
import { Link } from 'react-router-dom';

export function Logo() {
  return (
    <Link to="/" className="flex items-center">
      <img
        src="https://www.fuseau-sas.com/frontend/images/logo-fuseau.png"
        alt="FUSEAU"
        className="h-24 w-auto object-contain transition-transform hover:scale-105"
        style={{
          maxWidth: '300px'
        }}
      />
    </Link>
  );
}