export const PROCESS_THEMES = {
  direction: {
    primary: '#3B82F6', // blue-500
    secondary: '#60A5FA', // blue-400
    light: '#EFF6FF', // blue-50
    border: '#BFDBFE', // blue-200
    text: '#1E40AF', // blue-800
    gradient: 'from-blue-500/80 to-blue-600/80',
    hover: 'hover:bg-blue-50/80'
  },
  produire: {
    primary: '#F59E0B', // amber-500
    secondary: '#FBBF24', // amber-400
    light: '#FFFBEB', // amber-50
    border: '#FDE68A', // amber-200
    text: '#92400E', // amber-800
    gradient: 'from-amber-500/80 to-amber-600/80',
    hover: 'hover:bg-amber-50/80'
  },
  logistique: {
    primary: '#F97316', // orange-500
    secondary: '#FB923C', // orange-400
    light: '#FFF7ED', // orange-50
    border: '#FDBA74', // orange-200
    text: '#9A3412', // orange-800
    gradient: 'from-orange-500/80 to-orange-600/80',
    hover: 'hover:bg-orange-50/80'
  },
  vendre: {
    primary: '#22C55E', // green-500
    secondary: '#4ADE80', // green-400
    light: '#F0FDF4', // green-50
    border: '#86EFAC', // green-200
    text: '#166534', // green-800
    gradient: 'from-green-500/80 to-green-600/80',
    hover: 'hover:bg-green-50/80'
  },
  qualite: {
    primary: '#EAB308', // yellow-500
    secondary: '#FACC15', // yellow-400
    light: '#FEFCE8', // yellow-50
    border: '#FDE047', // yellow-200
    text: '#854D0E', // yellow-800
    gradient: 'from-yellow-500/80 to-yellow-600/80',
    hover: 'hover:bg-yellow-50/80'
  },
  achat: {
    primary: '#EF4444', // red-500
    secondary: '#F87171', // red-400
    light: '#FEF2F2', // red-50
    border: '#FECACA', // red-200
    text: '#991B1B', // red-800
    gradient: 'from-red-500/80 to-red-600/80',
    hover: 'hover:bg-red-50/80'
  },
  rh: {
    primary: '#8B5CF6', // violet-500
    secondary: '#A78BFA', // violet-400
    light: '#F5F3FF', // violet-50
    border: '#C4B5FD', // violet-200
    text: '#5B21B6', // violet-800
    gradient: 'from-violet-500/80 to-violet-600/80',
    hover: 'hover:bg-violet-50/80'
  },
  financer: {
    primary: '#6366F1', // indigo-500
    secondary: '#818CF8', // indigo-400
    light: '#EEF2FF', // indigo-50
    border: '#C7D2FE', // indigo-200
    text: '#3730A3', // indigo-800
    gradient: 'from-indigo-500/80 to-indigo-600/80',
    hover: 'hover:bg-indigo-50/80'
  }
} as const;

export type ProcessId = keyof typeof PROCESS_THEMES;

export function getProcessTheme(processId: string) {
  return PROCESS_THEMES[processId.toLowerCase() as ProcessId] || PROCESS_THEMES.direction;
}