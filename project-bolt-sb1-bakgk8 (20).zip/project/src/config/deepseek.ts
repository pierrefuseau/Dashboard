export const DEEPSEEK_CONFIG = {
  apiKey: import.meta.env.VITE_DEEPSEEK_API_KEY || '',
  model: 'deepseek-chat',
  maxTokens: 500,
  temperature: 0.7,
  systemPrompt: `Tu es un assistant spécialisé dans l'analyse de données pour FUSEAU SAS et DELICES AGRO.
  Tu as accès aux données des ventes, achats, logistique, RH, qualité et comptabilité.
  Ton rôle est d'aider à interpréter les KPIs et indicateurs de performance.
  Réponds de manière concise et professionnelle en français.
  Base tes réponses uniquement sur les données disponibles.`
};

// Vérification de la clé API
if (!DEEPSEEK_CONFIG.apiKey) {
  console.warn('Aucune clé API DeepSeek n\'a été fournie. L\'assistant IA ne sera pas disponible.');
}