/**
 * Couleurs principales de l'application
 */
export const COLORS = {
  // Couleurs des modules
  modules: {
    sales: {
      primary: '#3B82F6',
      secondary: '#60A5FA',
      light: '#DBEAFE'
    },
    purchasing: {
      primary: '#EF4444',
      secondary: '#F87171',
      light: '#FEE2E2'
    },
    hr: {
      primary: '#8B5CF6',
      secondary: '#A78BFA',
      light: '#EDE9FE'
    },
    logistics: {
      primary: '#F97316',
      secondary: '#FB923C',
      light: '#FFEDD5'
    },
    quality: {
      primary: '#EAB308',
      secondary: '#FACC15',
      light: '#FEF9C3'
    },
    boutique: {
      primary: '#EC4899',
      secondary: '#F472B6',
      light: '#FCE7F3'
    },
    rse: {
      primary: '#22C55E',
      secondary: '#34D399',
      light: '#DCFCE7'
    }
  },

  // États et feedback
  status: {
    success: '#22C55E',
    warning: '#F59E0B',
    error: '#EF4444',
    info: '#3B82F6'
  },

  // Interface utilisateur
  ui: {
    background: '#F9FAFB',
    surface: '#FFFFFF',
    border: '#E5E7EB',
    text: {
      primary: '#111827',
      secondary: '#4B5563',
      disabled: '#9CA3AF'
    }
  }
} as const;