/**
 * Configuration des routes de l'application
 */
export const ROUTES = {
  // Routes publiques
  public: {
    login: '/login',
    accessDenied: '/403'
  },

  // Routes protégées
  protected: {
    dashboard: '/',
    sales: '/sales',
    purchasing: '/purchasing',
    accounting: '/accounting',
    hr: '/hr',
    logistics: '/logistics',
    quality: '/quality',
    boutique: '/boutique',
    rse: '/rse'
  }
} as const;

/**
 * Association des routes avec les permissions requises
 */
export const ROUTE_PERMISSIONS = {
  [ROUTES.protected.sales]: 'VENTES',
  [ROUTES.protected.purchasing]: 'ACHATS',
  [ROUTES.protected.accounting]: 'COMPTA',
  [ROUTES.protected.hr]: 'RH',
  [ROUTES.protected.logistics]: 'LOGISTIQUE',
  [ROUTES.protected.quality]: 'QUALITE',
  [ROUTES.protected.boutique]: 'BOUTIQUE',
  [ROUTES.protected.rse]: 'RSE'
} as const;