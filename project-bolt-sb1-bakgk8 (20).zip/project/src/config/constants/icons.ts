import { 
  BarChart3, 
  ShoppingCart, 
  Calculator,
  Users, 
  Truck, 
  ClipboardCheck, 
  ShoppingBag,
  Leaf,
  Package,
  TrendingUp,
  AlertTriangle,
  Clock
} from 'lucide-react';

/**
 * Configuration des icônes par module
 */
export const ICONS = {
  modules: {
    dashboard: BarChart3,
    sales: BarChart3,
    purchasing: ShoppingCart,
    accounting: Calculator,
    hr: Users,
    logistics: Truck,
    quality: ClipboardCheck,
    boutique: ShoppingBag,
    rse: Leaf
  },

  metrics: {
    revenue: BarChart3,
    volume: Package,
    margin: TrendingUp,
    alert: AlertTriangle,
    time: Clock
  }
} as const;