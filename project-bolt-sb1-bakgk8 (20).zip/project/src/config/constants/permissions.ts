/**
 * Liste des permissions disponibles dans l'application
 */
export const PERMISSIONS = {
  VENTES: 'VENTES',
  ACHATS: 'ACHATS',
  COMPTA: 'COMPTA',
  RH: 'RH',
  LOGISTIQUE: 'LOGISTIQUE',
  QUALITE: 'QUALITE',
  BOUTIQUE: 'BOUTIQUE',
  RSE: 'RSE',
  ADMIN: 'ADMIN'
} as const;

export type Permission = keyof typeof PERMISSIONS;

/**
 * Groupes de permissions par rôle
 */
export const PERMISSION_GROUPS = {
  ADMIN: Object.values(PERMISSIONS),
  DIRECTION: [
    PERMISSIONS.VENTES,
    PERMISSIONS.ACHATS,
    PERMISSIONS.COMPTA,
    PERMISSIONS.RH
  ],
  COMMERCIAL: [
    PERMISSIONS.VENTES,
    PERMISSIONS.BOUTIQUE
  ],
  PRODUCTION: [
    PERMISSIONS.LOGISTIQUE,
    PERMISSIONS.QUALITE
  ]
} as const;