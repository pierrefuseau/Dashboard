import React from 'react';
import { Calculator, TrendingUp, Receipt } from 'lucide-react';
import { AccountingMetricCard } from '../../components/accounting/metrics/AccountingMetricCard';
import { ReceivablesTable } from '../../components/accounting/receivables/ReceivablesTable';
import { LoansOverview } from '../../components/accounting/loans/LoansOverview';
import { NavigationTabs } from '../../components/common/NavigationTabs';
import { useAccountingMetrics } from '../../hooks/accounting/useAccountingMetrics';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';

export function AccountingPage() {
  const [activeTab, setActiveTab] = React.useState('overview');
  const { revenue, grossMargin, treasury, treasuryDate, isLoading } = useAccountingMetrics();

  const tabs = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: Calculator },
    { id: 'receivables', label: 'Encours Clients', icon: Receipt },
    { id: 'loans', label: 'Emprunts', icon: TrendingUp }
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'receivables':
        return <ReceivablesTable />;
      case 'loans':
        return <LoansOverview />;
      default:
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            <AccountingMetricCard
              title="Chiffre d'affaires Bilan"
              value={revenue}
              icon={Calculator}
              format="currency"
              color="indigo"
            />
            <AccountingMetricCard
              title="Marge Brute Bilan"
              value={grossMargin}
              icon={TrendingUp}
              format="currency"
              color="indigo"
            />
            <AccountingMetricCard
              title={`Trésorerie (au ${treasuryDate})`}
              value={treasury}
              icon={Receipt}
              format="currency"
              color="indigo"
            />
          </div>
        );
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 p-4 sm:p-6">
      <div>
        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-indigo-600 tracking-tight">
          Comptabilité
        </h1>
        <p className="mt-2 text-base sm:text-lg text-indigo-500">
          Suivi des indicateurs financiers et comptables
        </p>
      </div>

      <div className="overflow-x-auto">
        <NavigationTabs
          tabs={tabs}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          variant="accounting"
        />
      </div>

      <div className="mt-6">
        {renderContent()}
      </div>
    </div>
  );
}

export default AccountingPage;