import React from 'react';
import { BarChart3, TrendingUp, Package } from 'lucide-react';
import { Card } from '../../components/common/Card';

export function VentesPage() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-green-600">FUSEAU VENTES</h2>
        <p className="mt-2 text-lg text-green-500">
          Tableau de bord des ventes du groupe
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <Card>
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Chiffre d'affaires</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0 €</p>
            </div>
            <div className="p-3 bg-green-50 rounded-full">
              <BarChart3 className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Marge</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0 €</p>
            </div>
            <div className="p-3 bg-green-50 rounded-full">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Volume</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0 T</p>
            </div>
            <div className="p-3 bg-green-50 rounded-full">
              <Package className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}