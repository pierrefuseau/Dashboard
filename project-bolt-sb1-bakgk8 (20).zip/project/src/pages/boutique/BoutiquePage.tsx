import React from 'react';
import { ShoppingBag, TrendingUp, Package, Users, BarChart2 } from 'lucide-react';
import { BoutiqueMetricCard } from '../../components/boutique/metrics/BoutiqueMetricCard';
import { TopRevenueTable } from '../../components/boutique/tables/TopRevenueTable';
import { TopMarginTable } from '../../components/boutique/tables/TopMarginTable';
import { TopVolumeTable } from '../../components/boutique/tables/TopVolumeTable';
import { NavigationTabs } from '../../components/common/NavigationTabs';
import { useBoutiqueMetrics } from '../../hooks/boutique/useBoutiqueMetrics';

export function BoutiquePage() {
  const { dailyRevenue, monthlyRevenue, monthlyMargin, customerCount } = useBoutiqueMetrics();
  const [activeTab, setActiveTab] = React.useState('revenue');

  const tabs = [
    { id: 'revenue', label: 'CA', icon: BarChart2 },
    { id: 'margin', label: 'Marge', icon: TrendingUp },
    { id: 'volume', label: 'Volume', icon: Package }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'revenue':
        return <TopRevenueTable />;
      case 'margin':
        return <TopMarginTable />;
      case 'volume':
        return <TopVolumeTable />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-pink-600">La Boutique</h2>
        <p className="mt-2 text-lg text-pink-500">
          Suivi des ventes et performances de la boutique
        </p>
      </div>

      {/* Métriques principales */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <BoutiqueMetricCard
          title="CA du jour"
          value={dailyRevenue}
          icon={ShoppingBag}
          format="currency"
          color="pink"
        />
        <BoutiqueMetricCard
          title="Nombre de clients du jour"
          value={customerCount}
          icon={Users}
          format="number"
          color="pink"
        />
        <BoutiqueMetricCard
          title="CA début de mois"
          value={monthlyRevenue}
          icon={TrendingUp}
          format="currency"
          color="pink"
        />
        <BoutiqueMetricCard
          title="Marge Mensuelle"
          value={monthlyMargin}
          icon={Package}
          format="percentage"
          color="pink"
        />
      </div>

      <NavigationTabs
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        variant="boutique"
      />

      <div className="mt-8">
        {renderContent()}
      </div>
    </div>
  );
}