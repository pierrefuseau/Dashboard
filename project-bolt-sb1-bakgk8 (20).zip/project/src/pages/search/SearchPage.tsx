import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search as SearchIcon, Filter, SlidersHorizontal } from 'lucide-react';
import { Card } from '../../components/common/Card';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { useSearch } from './hooks/useSearch';
import { SearchFilters } from './components/SearchFilters';
import { SearchResults } from './components/SearchResults';
import { SearchStats } from './components/SearchStats';

export function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const { results, isLoading, filters, setFilters } = useSearch(query);
  const [showFilters, setShowFilters] = React.useState(false);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Résultats de recherche</h1>
            <p className="mt-1 text-sm text-gray-500">
              {query ? `Résultats pour "${query}"` : 'Veuillez saisir un terme de recherche'}
            </p>
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center px-3 py-2 text-sm font-medium text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            Filtres
          </button>
        </div>

        {showFilters && (
          <div className="mt-4">
            <SearchFilters filters={filters} onChange={setFilters} />
          </div>
        )}

        {query && !isLoading && (
          <div className="mt-4">
            <SearchStats results={results} query={query} />
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner />
        </div>
      ) : results.length > 0 ? (
        <SearchResults results={results} />
      ) : query ? (
        <Card className="text-center py-12">
          <SearchIcon className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">Aucun résultat</h3>
          <p className="mt-1 text-sm text-gray-500">
            Aucun résultat trouvé pour "{query}". Essayez avec d'autres termes ou modifiez vos filtres.
          </p>
        </Card>
      ) : null}
    </div>
  );
}