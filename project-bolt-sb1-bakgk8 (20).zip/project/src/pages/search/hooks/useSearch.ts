import { useQuery } from '@tanstack/react-query';
import { searchData } from '../../../services/searchService';
import { SearchResult } from '../types';

export function useSearch(query: string) {
  return useQuery<SearchResult[]>({
    queryKey: ['search', query],
    queryFn: () => searchData(query),
    enabled: !!query,
    staleTime: 5 * 60 * 1000, // 5 minutes
    cacheTime: 30 * 60 * 1000, // 30 minutes
    initialData: []
  });
}