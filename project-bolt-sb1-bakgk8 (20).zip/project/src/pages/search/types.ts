export interface SearchResult {
  id: string;
  title: string;
  description: string;
  type: 'sales' | 'purchase' | 'other';
  category: string;
  section: string;
  date: string;
}

export interface SearchFilters {
  section?: string;
  type?: string;
  period?: string;
}