import React from 'react';
import { SearchResult } from '../types';

interface SearchStatsProps {
  results: SearchResult[];
  query: string;
}

export function SearchStats({ results, query }: SearchStatsProps) {
  const stats = React.useMemo(() => {
    const byType = results.reduce((acc, result) => {
      acc[result.type] = (acc[result.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total: results.length,
      byType
    };
  }, [results]);

  return (
    <div className="flex items-center space-x-4 text-sm text-gray-500">
      <span>{stats.total} résultat{stats.total > 1 ? 's' : ''}</span>
      {Object.entries(stats.byType).map(([type, count]) => (
        <span key={type} className={`px-2 py-1 rounded-full ${
          type === 'sales' ? 'bg-blue-50 text-blue-700' :
          type === 'purchase' ? 'bg-red-50 text-red-700' :
          'bg-gray-50 text-gray-700'
        }`}>
          {count} {type === 'sales' ? 'ventes' : 
                   type === 'purchase' ? 'achats' : 
                   'autres'}
        </span>
      ))}
    </div>
  );
}