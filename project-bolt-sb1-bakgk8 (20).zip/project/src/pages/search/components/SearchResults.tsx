import React from 'react';
import { useNavigate } from 'react-router-dom';
import { SearchResult } from '../types';
import { Card } from '../../../components/common/Card';
import { getResultIcon } from '../utils/resultIcons';

interface SearchResultsProps {
  results: SearchResult[];
}

export function SearchResults({ results }: SearchResultsProps) {
  const navigate = useNavigate();

  return (
    <div className="space-y-4">
      {results.map((result) => {
        const Icon = getResultIcon(result.type);
        
        return (
          <Card 
            key={result.id}
            className="hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => navigate(`/${result.section.toLowerCase()}`)}
          >
            <div className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className={`p-2 rounded-lg ${
                    result.type === 'sales' ? 'bg-blue-100' :
                    result.type === 'purchase' ? 'bg-red-100' :
                    'bg-gray-100'
                  }`}>
                    <Icon className={`w-5 h-5 ${
                      result.type === 'sales' ? 'text-blue-600' :
                      result.type === 'purchase' ? 'text-red-600' :
                      'text-gray-600'
                    }`} />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">
                      {result.title}
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                      {result.description}
                    </p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  result.type === 'sales' ? 'bg-blue-100 text-blue-800' :
                  result.type === 'purchase' ? 'bg-red-100 text-red-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {result.category}
                </span>
              </div>
              <div className="mt-4 flex items-center text-sm text-gray-500">
                <span>{result.date}</span>
                <span className="mx-2">•</span>
                <span>{result.section}</span>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}