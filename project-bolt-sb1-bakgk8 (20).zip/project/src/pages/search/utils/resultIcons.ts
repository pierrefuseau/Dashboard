import { BarChart3, ShoppingCart, Package } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export function getResultIcon(type: string): LucideIcon {
  switch (type) {
    case 'sales':
      return BarChart3;
    case 'purchase':
      return ShoppingCart;
    default:
      return Package;
  }
}