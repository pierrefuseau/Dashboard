import React from 'react';
import { StrategySection } from '../../components/dashboard/StrategySection';

export function DashboardPage() {
  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-[2000px] mx-auto">
      {/* Stratégie 2025 */}
      <StrategySection />
    </div>
  );
}

export default DashboardPage;