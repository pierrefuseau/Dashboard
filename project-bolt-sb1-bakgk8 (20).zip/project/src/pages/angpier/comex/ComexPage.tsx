import React, { useState, useCallback } from 'react';
import { ComexProcessContent } from '../../../components/angpier/comex/ComexProcessContent';
import { ComexGraphModal } from '../../../components/angpier/comex/ComexGraphModal';
import { ComexNavigation } from '../../../components/angpier/comex/ComexNavigation';
import { ComexErrorBoundary } from '../../../components/angpier/comex/ComexErrorBoundary';
import { ComexErrorHandler } from '../../../components/angpier/comex/ComexErrorHandler';
import { useComexData } from '../../../hooks/angpier/useComexData';
import { LoadingSpinner } from '../../../components/common/LoadingSpinner';
import { useQueryClient } from '@tanstack/react-query';

interface SelectedIndicator {
  processId: string;
  indicator: any;
}

export function ComexPage() {
  const [activeProcess, setActiveProcess] = useState('direction');
  const [selectedIndicator, setSelectedIndicator] = useState<SelectedIndicator | null>(null);
  const queryClient = useQueryClient();
  const { data: comexData, isLoading, error } = useComexData();

  const handleRetry = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: ['comex'] });
  }, [queryClient]);

  const handleNextIndicator = () => {
    if (!selectedIndicator || !comexData) return;
    
    const currentProcess = comexData.processes.find(p => p.id === selectedIndicator.processId);
    if (!currentProcess) return;

    const currentIndex = currentProcess.indicators.findIndex(i => i.id === selectedIndicator.indicator.id);
    if (currentIndex === -1) return;

    const nextIndex = (currentIndex + 1) % currentProcess.indicators.length;
    setSelectedIndicator({
      processId: selectedIndicator.processId,
      indicator: currentProcess.indicators[nextIndex]
    });
  };

  const handlePreviousIndicator = () => {
    if (!selectedIndicator || !comexData) return;
    
    const currentProcess = comexData.processes.find(p => p.id === selectedIndicator.processId);
    if (!currentProcess) return;

    const currentIndex = currentProcess.indicators.findIndex(i => i.id === selectedIndicator.indicator.id);
    if (currentIndex === -1) return;

    const previousIndex = currentIndex === 0 ? currentProcess.indicators.length - 1 : currentIndex - 1;
    setSelectedIndicator({
      processId: selectedIndicator.processId,
      indicator: currentProcess.indicators[previousIndex]
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  // Créer des données par défaut si aucune donnée n'est disponible
  const defaultData = {
    processes: [
      {
        id: 'direction',
        name: 'Direction',
        indicators: []
      }
    ]
  };

  // Utiliser les données réelles ou les données par défaut
  const displayData = comexData || defaultData;

  return (
    <ComexErrorBoundary>
      <ComexErrorHandler error={error instanceof Error ? error : null} onRetry={handleRetry}>
        <div className="space-y-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">COMEX</h2>
            <p className="mt-2 text-lg text-gray-600">
              Indicateurs de performance du groupe
            </p>
          </div>

          <ComexNavigation
            activeProcess={activeProcess}
            onProcessSelect={setActiveProcess}
          />

          <div className="mt-8">
            {displayData.processes.find(p => p.id === activeProcess) && (
              <ComexProcessContent
                process={displayData.processes.find(p => p.id === activeProcess)!}
                onShowGraph={(indicator) => setSelectedIndicator({
                  processId: activeProcess,
                  indicator
                })}
              />
            )}

            {selectedIndicator && displayData.processes.find(p => p.id === selectedIndicator.processId) && (
              <ComexGraphModal
                isOpen={!!selectedIndicator}
                onClose={() => setSelectedIndicator(null)}
                indicator={selectedIndicator.indicator}
                process={displayData.processes.find(p => p.id === selectedIndicator.processId)!}
                onNextIndicator={handleNextIndicator}
                onPreviousIndicator={handlePreviousIndicator}
              />
            )}
          </div>
        </div>
      </ComexErrorHandler>
    </ComexErrorBoundary>
  );
}

export default ComexPage;