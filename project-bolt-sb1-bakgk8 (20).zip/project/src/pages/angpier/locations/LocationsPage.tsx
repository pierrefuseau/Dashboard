import React from 'react';
import { Building2, Euro, Calendar, TrendingDown, MapPin, User, Percent } from 'lucide-react';
import { Card } from '../../../components/common/Card';
import { motion } from 'framer-motion';
import { useLocationsData } from '../../../hooks/angpier/useLocationsData';
import { LoadingSpinner } from '../../../components/common/LoadingSpinner';
import { formatCurrency } from '../../../utils/formatters/currency';

export function LocationsPage() {
  const { 
    properties, 
    totalProperties, 
    totalSurface, 
    totalRent, 
    totalLoanRemaining, 
    isLoading 
  } = useLocationsData();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Gestion Locative</h2>
        <p className="mt-2 text-lg text-gray-600">
          Vue d'ensemble du patrimoine immobilier
        </p>
      </div>

      {/* Métriques */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <div className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-purple-600">Loyers mensuels</p>
                <p className="mt-1 text-xl font-semibold text-gray-900">
                  {formatCurrency(totalRent)}
                </p>
              </div>
              <div className="p-2 bg-white rounded-full shadow-sm">
                <Euro className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <div className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-purple-600">Surface totale</p>
                <p className="mt-1 text-xl font-semibold text-gray-900">
                  {totalSurface.toLocaleString('fr-FR')} m²
                </p>
              </div>
              <div className="p-2 bg-white rounded-full shadow-sm">
                <Building2 className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <div className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-purple-600">Emprunts restants</p>
                <p className="mt-1 text-xl font-semibold text-gray-900">
                  {formatCurrency(totalLoanRemaining)}
                </p>
              </div>
              <div className="p-2 bg-white rounded-full shadow-sm">
                <TrendingDown className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <div className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-purple-600">Nombre de biens</p>
                <p className="mt-1 text-xl font-semibold text-gray-900">{totalProperties}</p>
              </div>
              <div className="p-2 bg-white rounded-full shadow-sm">
                <Calendar className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Liste des propriétés */}
      <div>
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Propriétés</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {properties.map((property, index) => (
            <motion.div
              key={property.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Card className="h-full overflow-hidden hover:shadow-lg transition-shadow duration-200 border-l-4 border-purple-400">
                <div className="p-4">
                  <div className="flex items-start mb-3">
                    <div className="p-2 bg-purple-100 rounded-lg mr-3">
                      <Building2 className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900">
                        {property.name}
                      </h4>
                      <div className="flex items-center text-sm text-gray-500 mt-1">
                        <MapPin className="w-3.5 h-3.5 mr-1 flex-shrink-0" />
                        <span className="truncate">{property.address}</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-4">
                    <div className="bg-gray-50 p-2 rounded-lg">
                      <p className="text-xs text-gray-500">Surface</p>
                      <p className="text-sm font-medium text-gray-900">
                        {property.surface.toLocaleString('fr-FR')} m²
                      </p>
                    </div>
                    
                    {property.rent !== null && (
                      <div className="bg-gray-50 p-2 rounded-lg">
                        <p className="text-xs text-gray-500">Loyer</p>
                        <p className="text-sm font-medium text-gray-900">
                          {formatCurrency(property.rent)}
                        </p>
                      </div>
                    )}
                    
                    {property.loanRemaining !== null && (
                      <div className="bg-gray-50 p-2 rounded-lg">
                        <p className="text-xs text-gray-500">Emprunt restant</p>
                        <p className="text-sm font-medium text-gray-900">
                          {formatCurrency(property.loanRemaining)}
                        </p>
                      </div>
                    )}
                    
                    <div className="bg-gray-50 p-2 rounded-lg">
                      <p className="text-xs text-gray-500">Locataire</p>
                      <div className="flex items-center">
                        <User className="w-3.5 h-3.5 mr-1 text-gray-400" />
                        <p className="text-sm font-medium text-gray-900">FUSEAU SAS</p>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 p-2 rounded-lg">
                      <p className="text-xs text-gray-500">Occupation</p>
                      <div className="flex items-center">
                        <Percent className="w-3.5 h-3.5 mr-1 text-green-500" />
                        <p className="text-sm font-medium text-green-600">100%</p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}