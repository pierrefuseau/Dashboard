import React from 'react';
import { Card } from '../../components/common/Card';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { BarChart2, Building2, Newspaper } from 'lucide-react';

export function AngpierPage() {
  const navigate = useNavigate();

  const navigationCards = [
    {
      title: 'COMEX',
      description: 'Indicateurs de performance du groupe',
      icon: BarChart2,
      path: '/angpier/comex',
      color: 'blue'
    },
    {
      title: 'Locations',
      description: 'Gestion du patrimoine immobilier',
      icon: Building2,
      path: '/angpier/locations',
      color: 'purple'
    },
    {
      title: 'Actualités',
      description: 'Actualités et événements du groupe',
      icon: Newspaper,
      path: '/angpier/news',
      color: 'green'
    }
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">ANGPIER</h2>
        <p className="mt-2 text-lg text-gray-600">
          Tableau de bord de gestion du groupe
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {navigationCards.map((card) => (
          <motion.div
            key={card.title}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`
              bg-white rounded-xl shadow-sm border-l-4 border-${card.color}-500
              p-6 cursor-pointer transition-all duration-200 hover:shadow-md
            `}
            onClick={() => navigate(card.path)}
          >
            <div className="flex items-center space-x-4 mb-4">
              <div className={`p-3 rounded-lg bg-${card.color}-100`}>
                <card.icon className={`w-6 h-6 text-${card.color}-600`} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">{card.title}</h3>
            </div>
            <p className="text-gray-600">{card.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}