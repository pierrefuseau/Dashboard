import React from 'react';
import { NewsList } from '../../../components/angpier/news/NewsList';

export function NewsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Actualités</h2>
        <p className="mt-2 text-lg text-gray-600">
          Actualités et événements du groupe
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Actualités */}
        <div className="lg:col-span-3 space-y-6">
          <NewsList />
        </div>
      </div>
    </div>
  );
}