import React from 'react';
import { Users, TrendingDown, Clock, BookOpen } from 'lucide-react';
import { Card } from '../../../components/common/Card';

export function HRPage() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-sky-600">Ressources Humaines</h2>
        <p className="mt-2 text-lg text-sky-500">
          Gestion des ressources humaines
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-sky-500 hover:bg-sky-50/50 transition-colors duration-200">
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Effectif Total</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0</p>
            </div>
            <div className="p-3 bg-sky-50 rounded-full">
              <Users className="w-6 h-6 text-sky-600" />
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-sky-500 hover:bg-sky-50/50 transition-colors duration-200">
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Turn-over</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0%</p>
            </div>
            <div className="p-3 bg-sky-50 rounded-full">
              <TrendingDown className="w-6 h-6 text-sky-600" />
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-sky-500 hover:bg-sky-50/50 transition-colors duration-200">
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Absentéisme</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0%</p>
            </div>
            <div className="p-3 bg-sky-50 rounded-full">
              <Clock className="w-6 h-6 text-sky-600" />
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-sky-500 hover:bg-sky-50/50 transition-colors duration-200">
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Formation</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0h</p>
            </div>
            <div className="p-3 bg-sky-50 rounded-full">
              <BookOpen className="w-6 h-6 text-sky-600" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}