import React from 'react';
import { ClipboardCheck, AlertTriangle, FileCheck } from 'lucide-react';
import { Card } from '../../../components/common/Card';

export function QualityPage() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-yellow-600">Qualité</h2>
        <p className="mt-2 text-lg text-yellow-500">
          Suivi des indicateurs qualité et conformité
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <Card className="border-l-4 border-yellow-500 hover:bg-yellow-50/50 transition-colors duration-200">
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Score IFS</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0/100</p>
            </div>
            <div className="p-3 bg-yellow-50 rounded-full">
              <ClipboardCheck className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-yellow-500 hover:bg-yellow-50/50 transition-colors duration-200">
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Non-conformités</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0</p>
            </div>
            <div className="p-3 bg-yellow-50 rounded-full">
              <AlertTriangle className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-yellow-500 hover:bg-yellow-50/50 transition-colors duration-200">
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Taux de clôture</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0%</p>
            </div>
            <div className="p-3 bg-yellow-50 rounded-full">
              <FileCheck className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}