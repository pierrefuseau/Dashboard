import React from 'react';
import { 
  BarChart3, 
  Factory,
  Microscope, 
  Users, 
  Calculator,
  TrendingUp,
  Truck
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Card } from '../../components/common/Card';

export function DelicesAgroPage() {
  const navigate = useNavigate();

  const strategyCards = [
    {
      title: "Croissance & Performance",
      description: "Renforcer notre activité tout en optimisant nos performances globales.",
      icon: TrendingUp,
      color: "emerald",
      delay: 0
    },
    {
      title: "Ventes",
      description: "Attirer de nouveaux clients et fidéliser nos partenaires en offrant une expérience client de haute qualité.",
      icon: BarChart3,
      color: "blue",
      delay: 0.1
    },
    {
      title: "Production",
      description: "Améliorer l'efficacité des lignes de conditionnement et maximiser leur temps d'ouverture pour augmenter la productivité.",
      icon: Factory,
      color: "amber",
      delay: 0.2
    },
    {
      title: "Logistique",
      description: "Fluidifier les flux d'approvisionnement et de livraison tout en identifiant des leviers de réduction des coûts sans compromettre la qualité.",
      icon: Truck,
      color: "orange",
      delay: 0.3
    },
    {
      title: "Ressources Humaines",
      description: "Encourager un esprit d'équipe positif et investir dans la formation interne pour permettre à chacun de progresser.",
      icon: Users,
      color: "sky",
      delay: 0.4
    }
  ];

  const navigationCards = [
    {
      title: 'Ventes',
      description: 'Suivi et analyse des ventes',
      icon: BarChart3,
      path: '/delices-agro/ventes',
      color: 'emerald'
    },
    {
      title: 'Production',
      description: 'Gestion des opérations de production',
      icon: Factory,
      path: '/delices-agro/production',
      color: 'amber'
    },
    {
      title: 'R&D',
      description: 'Innovation et développement produit',
      icon: Microscope,
      path: '/delices-agro/rd',
      color: 'purple'
    },
    {
      title: 'RH',
      description: 'Gestion des ressources humaines',
      icon: Users,
      path: '/delices-agro/rh',
      color: 'sky'
    },
    {
      title: 'Comptabilité',
      description: 'Suivi financier et comptable',
      icon: Calculator,
      path: '/delices-agro/comptabilite',
      color: 'rose'
    }
  ];

  return (
    <div className="space-y-6">
      {/* En-tête compact */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <h1 className="text-xl font-semibold text-gray-900">Vue d'ensemble</h1>
        <p className="mt-1 text-sm text-gray-500">
          Tableau de bord DELICES AGRO
        </p>
      </div>

      {/* Stratégie 2025 */}
      <div className="mb-12">
        <div className="bg-gradient-to-br from-white to-gray-50 rounded-xl p-8 shadow-sm border border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Stratégie 2025</h2>
          <p className="text-gray-600 font-medium mb-8">
            En quelques mots
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {strategyCards.map((card) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: card.delay }}
                className={`bg-${card.color}-50 rounded-lg p-6 shadow-sm border border-${card.color}-100 hover:shadow-md transition-all duration-200`}
              >
                <div className={`p-2 rounded-lg bg-${card.color}-100/50 w-12 h-12 flex items-center justify-center mb-4`}>
                  <card.icon className={`w-6 h-6 text-${card.color}-600`} />
                </div>
                <h3 className={`text-lg font-medium text-${card.color}-900 mb-2`}>
                  {card.title}
                </h3>
                <p className={`text-${card.color}-700 text-sm leading-relaxed`}>
                  {card.description}
                </p>
              </motion.div>
            ))}
          </div>

          <p className="text-center text-gray-600 mt-8 font-medium">
            Ensemble, faisons de 2025 une année de croissance durable et d'efficacité opérationnelle.
          </p>
        </div>
      </div>

      {/* Grille des tuiles */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {navigationCards.map((card) => (
          <motion.div
            key={card.title}
            className={`
              relative p-6 bg-white rounded-xl shadow-sm border-l-4 
              border-${card.color}-500 overflow-hidden cursor-pointer
              transition-all duration-200 hover:shadow-lg hover:scale-102
              group
            `}
            onClick={() => navigate(card.path)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {/* Fond avec effet de gradient au hover */}
            <div className={`
              absolute inset-0 bg-gradient-to-r from-${card.color}-50 via-${card.color}-50/50 to-transparent
              opacity-0 group-hover:opacity-100 transition-opacity duration-300
            `} />

            {/* Contenu */}
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-2 rounded-lg bg-${card.color}-100/80`}>
                  <card.icon className={`w-5 h-5 text-${card.color}-600`} />
                </div>
                <span className={`text-xs font-medium text-${card.color}-600 bg-${card.color}-50 px-2 py-1 rounded-full`}>
                  {card.title}
                </span>
              </div>
              <h3 className="text-base font-semibold text-gray-900 mb-2">{card.title}</h3>
              <p className="text-sm text-gray-500">{card.description}</p>
            </div>

            {/* Effet de brillance au hover */}
            <div className={`
              absolute inset-0 opacity-0 group-hover:opacity-20
              bg-gradient-to-r from-transparent via-white to-transparent
              translate-x-[-100%] group-hover:translate-x-[100%]
              transition-transform duration-1000
            `} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}