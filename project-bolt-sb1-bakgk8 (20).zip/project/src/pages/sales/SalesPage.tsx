import React from 'react';
import { BarChart3, TrendingUp, Package, LineChart } from 'lucide-react';
import { SalesMetricCard } from '../../components/sales/metrics/SalesMetricCard';
import { TopClientsTable } from '../../components/sales/clients/TopClientsTable';
import { TopFamiliesTable } from '../../components/sales/families/TopFamiliesTable';
import { TopCategoriesTable } from '../../components/sales/categories/TopCategoriesTable';
import { TopSegmentsTable } from '../../components/sales/segments/TopSegmentsTable';
import { TopProductsCharts } from '../../components/sales/products/TopProductsCharts';
import { SalesMap } from '../../components/sales/map/SalesMap';
import { ExportOverview } from '../../components/sales/exports/ExportOverview';
import { MonthlySummary } from '../../components/sales/monthly/MonthlySummary';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../../components/ui/Tabs';
import { useSalesMetrics } from '../../hooks/sales/useSalesMetrics';
import { Card } from '../../components/common/Card';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';

export function SalesPage() {
  const { revenue, margin, volume, isLoading, error } = useSalesMetrics();

  if (error) {
    return (
      <Card className="p-6">
        <div className="text-center">
          <BarChart3 className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Erreur de chargement des ventes
          </h3>
          <p className="text-gray-500 mb-4">
            {error}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Réessayer
          </button>
        </div>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-blue-600">Ventes</h2>
        <p className="mt-2 text-lg text-blue-500">
          Aperçu des performances commerciales et des indicateurs clés
        </p>
      </div>

      {/* Métriques principales */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <SalesMetricCard
          title="Chiffre d'affaires annuel"
          value={revenue}
          icon={BarChart3}
          format="currency"
          color="blue"
        />
        <SalesMetricCard
          title="Marge Annuelle"
          value={margin}
          icon={TrendingUp}
          format="currency"
          color="blue"
        />
        <SalesMetricCard
          title="Volume en Tonnes année en cours"
          value={volume}
          icon={Package}
          format="number"
          color="blue"
        />
      </div>

      {/* Navigation par onglets */}
      <Tabs defaultValue="monthly" variant="sales">
        <TabsList>
          <TabsTrigger value="monthly" className="flex items-center space-x-2">
            <LineChart className="w-4 h-4" />
            <span>Synthèse Mensuelle</span>
          </TabsTrigger>
          <TabsTrigger value="clients">Clients</TabsTrigger>
          <TabsTrigger value="groups">Groupes Clients</TabsTrigger>
          <TabsTrigger value="sales">Commerciaux</TabsTrigger>
          <TabsTrigger value="professions">Professions</TabsTrigger>
          <TabsTrigger value="products">Produits</TabsTrigger>
          <TabsTrigger value="map">La carte</TabsTrigger>
          <TabsTrigger value="export">Export</TabsTrigger>
        </TabsList>

        <TabsContent value="monthly">
          <MonthlySummary />
        </TabsContent>

        <TabsContent value="clients">
          <TopClientsTable />
        </TabsContent>

        <TabsContent value="groups">
          <TopFamiliesTable />
        </TabsContent>

        <TabsContent value="sales">
          <TopCategoriesTable />
        </TabsContent>

        <TabsContent value="professions">
          <TopSegmentsTable />
        </TabsContent>

        <TabsContent value="products">
          <TopProductsCharts />
        </TabsContent>

        <TabsContent value="map">
          <SalesMap />
        </TabsContent>

        <TabsContent value="export">
          <ExportOverview />
        </TabsContent>
      </Tabs>
    </div>
  );
}