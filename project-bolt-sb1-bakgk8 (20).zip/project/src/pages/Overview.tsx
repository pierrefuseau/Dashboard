import React from 'react';
import { SalesOverview } from '../components/sales/metrics/SalesOverview';
import { PurchaseOverview } from '../components/purchasing/metrics/PurchaseOverview';
import { HROverview } from '../components/hr/metrics/HROverview';
import { LogisticsOverview } from '../components/logistics/metrics/LogisticsOverview';
import { BoutiqueMetricCard } from '../components/boutique/metrics/BoutiqueMetricCard';
import { ShoppingBag, TrendingUp, Users, Package } from 'lucide-react';
import { useBoutiqueMetrics } from '../hooks/boutique/useBoutiqueMetrics';

export function Overview() {
  const { dailyRevenue, monthlyRevenue, monthlyMargin, customerCount } = useBoutiqueMetrics();

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-900">Tableau de bord</h1>
        <p className="mt-1 text-sm text-gray-500">
          Vue d'ensemble des indicateurs clés
        </p>
      </header>

      {/* Boutique Metrics */}
      <section aria-labelledby="boutique-heading" className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <BoutiqueMetricCard
          title="CA du jour"
          value={dailyRevenue}
          icon={ShoppingBag}
          format="currency"
          color="boutique"
        />
        <BoutiqueMetricCard
          title="Nombre de clients du jour"
          value={customerCount}
          icon={Users}
          format="number"
          color="boutique"
        />
        <BoutiqueMetricCard
          title="CA début de mois"
          value={monthlyRevenue}
          icon={TrendingUp}
          format="currency"
          color="boutique"
        />
        <BoutiqueMetricCard
          title="Marge Mensuelle"
          value={monthlyMargin}
          icon={Package}
          format="percentage"
          color="boutique"
        />
      </section>

      <section aria-labelledby="sales-heading">
        <h2 id="sales-heading" className="sr-only">Ventes</h2>
        <SalesOverview />
      </section>

      <section aria-labelledby="purchases-heading">
        <h2 id="purchases-heading" className="sr-only">Achats</h2>
        <PurchaseOverview />
      </section>

      <section aria-labelledby="hr-heading">
        <h2 id="hr-heading" className="sr-only">Ressources Humaines</h2>
        <HROverview />
      </section>

      <section aria-labelledby="logistics-heading">
        <h2 id="logistics-heading" className="sr-only">Logistique</h2>
        <LogisticsOverview />
      </section>
    </div>
  );
}