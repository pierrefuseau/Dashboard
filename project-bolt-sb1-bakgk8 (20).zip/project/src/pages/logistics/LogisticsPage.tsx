import React from 'react';
import { Package, Truck, AlertCircle, Clock, TrendingUp } from 'lucide-react';
import { LogisticsMetricCard } from '../../components/logistics/metrics/LogisticsMetricCard';
import { useLogisticsMetrics } from '../../hooks/logistics/useLogisticsMetrics';
import { NavigationTabs } from '../../components/common/NavigationTabs';
import { WarehouseStockChart } from '../../components/logistics/stock/WarehouseStockChart';
import { TopProductsStockTable } from '../../components/logistics/stock/TopProductsStockTable';
import { SlowMovingProductsTable } from '../../components/logistics/stock/SlowMovingProductsTable';
import { DDMProductsSection } from '../../components/logistics/ddm/DDMProductsSection';

export function LogisticsPage() {
  const [activeTab, setActiveTab] = React.useState('stocks');
  const metrics = useLogisticsMetrics();

  const tabs = [
    { id: 'stocks', label: 'Stocks Entrepôts', icon: Package },
    { id: 'products', label: 'Stock Produits', icon: Package },
    { id: 'slow', label: 'Non tournant', icon: AlertCircle },
    { id: 'ddm', label: 'DDM Courtes', icon: Clock }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'stocks':
        return <WarehouseStockChart />;
      case 'products':
        return <TopProductsStockTable />;
      case 'slow':
        return <SlowMovingProductsTable />;
      case 'ddm':
        return <DDMProductsSection />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-orange-600">Logistique</h2>
        <p className="mt-2 text-lg text-orange-500">
          Suivi des opérations logistiques et stocks
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <LogisticsMetricCard
          title="Taux de Service Global"
          value={metrics.serviceRate}
          icon={TrendingUp}
          format="percentage"
          target={97}
          color="orange"
        />
        <LogisticsMetricCard
          title="Valeur Stock Total"
          value={metrics.stockValue}
          icon={Package}
          format="millions"
          color="orange"
        />
        <LogisticsMetricCard
          title="Anomalies Traçabilité"
          value={metrics.anomalies}
          icon={AlertCircle}
          format="percentage"
          target={5}
          color="orange"
        />
        <LogisticsMetricCard
          title="Taux Service Transport"
          value={metrics.transportRate}
          icon={Truck}
          format="percentage"
          target={98}
          color="orange"
        />
      </div>

      <NavigationTabs
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        variant="logistics"
      />

      <div className="mt-6">
        {renderContent()}
      </div>
    </div>
  );
}