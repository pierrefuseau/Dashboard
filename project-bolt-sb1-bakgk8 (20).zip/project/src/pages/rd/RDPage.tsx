import React from 'react';
import { Microscope, Lightbulb, FlaskRound as Flask } from 'lucide-react';
import { Card } from '../../components/common/Card';

export function RDPage() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-purple-600">FUSEAU R&D</h2>
        <p className="mt-2 text-lg text-purple-500">
          Tableau de bord Recherche et Développement
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <Card>
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Projets en cours</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-full">
              <Microscope className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Innovations</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-full">
              <Lightbulb className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Tests</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-full">
              <Flask className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}