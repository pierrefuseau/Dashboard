import React from 'react';
import { Users, TrendingDown, Clock, BookOpen, BarChart2, Heart, Building2, FileText } from 'lucide-react';
import { HRMetricCard } from '../../components/hr/metrics/HRMetricCard';
import { NavigationTabs } from '../../components/common/NavigationTabs';
import { EmployeeDistributionCharts } from '../../components/hr/distribution/EmployeeDistributionCharts';
import { HRCostsTable } from '../../components/hr/costs/HRCostsTable';
import { EmployeeMovementsTable } from '../../components/hr/movements/EmployeeMovementsTable';
import { AbsenteeismChart } from '../../components/hr/absenteeism/AbsenteeismChart';
import { TrainingOverview } from '../../components/hr/training/TrainingOverview';
import { SatisfactionChart } from '../../components/hr/satisfaction/SatisfactionChart';
import { useHRMetrics } from '../../hooks/hr/useHRMetrics';

export function HRPage() {
  const [activeTab, setActiveTab] = React.useState('overview');
  const { totalEmployees, turnoverRate, isLoading } = useHRMetrics();

  const tabs = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: BarChart2 },
    { id: 'distribution', label: 'Distribution', icon: Building2 },
    { id: 'movements', label: 'Mouvements', icon: Users },
    { id: 'training', label: 'Formation', icon: BookOpen },
    { id: 'satisfaction', label: 'Satisfaction', icon: Heart },
    { id: 'costs', label: 'Coûts', icon: FileText }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <HRMetricCard
                title="Effectif Total"
                value={totalEmployees}
                icon={Users}
                format="number"
                color="violet"
              />
              <HRMetricCard
                title="Turn-over"
                value={turnoverRate}
                icon={TrendingDown}
                format="percentage"
                color="violet"
              />
              <HRMetricCard
                title="Taux d'Absentéisme"
                value={3.8}
                icon={Clock}
                format="percentage"
                color="violet"
              />
              <HRMetricCard
                title="Heures Formation"
                value={1250}
                icon={BookOpen}
                format="number"
                color="violet"
              />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
              <EmployeeDistributionCharts />
              <AbsenteeismChart />
            </div>
          </>
        );
      case 'distribution':
        return <EmployeeDistributionCharts />;
      case 'movements':
        return <EmployeeMovementsTable />;
      case 'training':
        return <TrainingOverview />;
      case 'satisfaction':
        return <SatisfactionChart />;
      case 'costs':
        return <HRCostsTable />;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-violet-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-violet-600">Ressources Humaines</h2>
        <p className="mt-2 text-lg text-violet-500">
          Gestion du personnel et indicateurs RH
        </p>
      </div>

      <NavigationTabs
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        variant="hr"
      />

      <div className="mt-6">
        {renderContent()}
      </div>
    </div>
  );
}