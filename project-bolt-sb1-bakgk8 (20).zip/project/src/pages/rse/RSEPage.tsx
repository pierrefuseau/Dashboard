import React, { useState } from 'react';
import { Leaf, Users, Building2, LineChart, AlertTriangle } from 'lucide-react';
import { NavigationTabs } from '../../components/common/NavigationTabs';
import { RSEOverview } from '../../components/rse/overview/RSEOverview';
import { CarbonFootprint } from '../../components/rse/carbon/CarbonFootprint';
import { SocialMetrics } from '../../components/rse/social/SocialMetrics';
import { GovernanceMetrics } from '../../components/rse/governance/GovernanceMetrics';
import { RiskManagementSection } from '../../components/rse/risks/RiskManagementSection';

export function RSEPage() {
  const [activeTab, setActiveTab] = React.useState('overview');

  const tabs = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: LineChart },
    { id: 'carbon', label: 'Bilan Carbone', icon: Leaf },
    { id: 'social', label: 'Social', icon: Users },
    { id: 'governance', label: 'Gouvernance', icon: Building2 },
    { id: 'risks', label: 'Risques', icon: AlertTriangle }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'carbon':
        return <CarbonFootprint />;
      case 'social':
        return <SocialMetrics />;
      case 'governance':
        return <GovernanceMetrics />;
      case 'risks':
        return <RiskManagementSection />;
      default:
        return <RSEOverview />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">RSE & Développement Durable</h2>
        <p className="mt-1 text-sm text-gray-500">
          Suivi des indicateurs de Responsabilité Sociétale et Environnementale
        </p>
      </div>

      <NavigationTabs
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        variant="green"
      />

      <div className="mt-6">
        {renderContent()}
      </div>
    </div>
  );
}