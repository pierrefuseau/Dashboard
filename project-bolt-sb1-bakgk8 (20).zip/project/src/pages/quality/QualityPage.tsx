import React from 'react';
import { ClipboardCheck, AlertTriangle, FileCheck, TestTube, TrendingUp, CheckCircle, AlertOctagon, LineChart } from 'lucide-react';
import { QualityMetricCard } from '../../components/quality/metrics/QualityMetricCard';
import { NavigationTabs } from '../../components/common/NavigationTabs';
import { IFSComplianceChart } from '../../components/quality/compliance/IFSComplianceChart';
import { NonConformityOverview } from '../../components/quality/conformity/NonConformityOverview';
import { AuditTable } from '../../components/quality/audits/AuditTable';
import { QualityControlChart } from '../../components/quality/controls/QualityControlChart';
import { ImprovementProgress } from '../../components/quality/improvement/ImprovementProgress';
import { TimeFilter } from '../../components/common/TimeFilter';
import { useTimeFilter } from '../../hooks/useTimeFilter';

export function QualityPage() {
  const { timeRange, setTimeRange } = useTimeFilter('month');
  const [activeTab, setActiveTab] = React.useState('overview');

  const tabs = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: LineChart },
    { id: 'compliance', label: 'Conformité IFS', icon: CheckCircle },
    { id: 'nonconformity', label: 'Non-conformités', icon: AlertOctagon },
    { id: 'controls', label: 'Contrôles', icon: TestTube },
    { id: 'audits', label: 'Audits', icon: ClipboardCheck },
    { id: 'improvement', label: 'Amélioration', icon: TrendingUp }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <>
            <IFSComplianceChart timeRange={timeRange} />
            <NonConformityOverview />
          </>
        );
      case 'compliance':
        return <IFSComplianceChart timeRange={timeRange} />;
      case 'nonconformity':
        return <NonConformityOverview />;
      case 'controls':
        return <QualityControlChart />;
      case 'audits':
        return <AuditTable />;
      case 'improvement':
        return <ImprovementProgress />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-yellow-600">Qualité (IFS FOOD)</h2>
          <p className="mt-2 text-lg text-yellow-500">
            Suivi des indicateurs qualité et conformité IFS
          </p>
        </div>
        <TimeFilter value={timeRange} onChange={setTimeRange} />
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <QualityMetricCard
          title="Score IFS"
          value={95}
          icon={ClipboardCheck}
          format="score"
          target={98}
          color="yellow"
        />
        <QualityMetricCard
          title="Non-Conformités"
          value={12}
          icon={AlertTriangle}
          format="number"
          target={8}
          color="yellow"
        />
        <QualityMetricCard
          title="Taux de Clôture"
          value={87.5}
          icon={FileCheck}
          format="percentage"
          target={95}
          color="yellow"
        />
        <QualityMetricCard
          title="Temps Résolution"
          value={4.2}
          icon={TrendingUp}
          format="days"
          target={3}
          color="yellow"
        />
      </div>

      <NavigationTabs
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        variant="quality"
      />

      <div className="mt-6 space-y-6">
        {renderContent()}
      </div>
    </div>
  );
}