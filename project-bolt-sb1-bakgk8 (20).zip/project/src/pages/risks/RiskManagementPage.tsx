import React, { useState } from 'react';
import { RiskManagementOverview } from '../../components/risks/RiskManagementOverview';
import { RiskList } from '../../components/risks/RiskList';

export function RiskManagementPage() {
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Gestion des Risques</h1>
        <p className="mt-1 text-sm text-gray-500">
          Suivi et gestion des risques RSE et gouvernance
        </p>
      </div>

      <RiskManagementOverview 
        selectedStatus={selectedStatus}
        onStatusSelect={setSelectedStatus}
      />
      <RiskList selectedStatus={selectedStatus} />
    </div>
  );
}