import React from 'react';
import { Factory, Clock, AlertCircle } from 'lucide-react';
import { Card } from '../../components/common/Card';

export function ProductionPage() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-orange-600">FUSEAU PRODUCTION</h2>
        <p className="mt-2 text-lg text-orange-500">
          Tableau de bord de la production
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <Card>
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Productivité</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0%</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-full">
              <Factory className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Temps de cycle</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0 min</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-full">
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Incidents</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">0</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-full">
              <AlertCircle className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}