import React from 'react';
import { Package, ShoppingCart, Users, Users2, Globe, LineChart, CreditCard } from 'lucide-react';
import { PurchaseMetricCard } from '../../components/purchasing/metrics/PurchaseMetricCard';
import { NavigationTabs } from '../../components/common/NavigationTabs';
import { SupplierPerformanceTable } from '../../components/purchasing/suppliers/SupplierPerformanceTable';
import { PurchaseOriginChart } from '../../components/purchasing/origin/PurchaseOriginChart';
import { PurchaseVolumeChart } from '../../components/purchasing/volume/PurchaseVolumeChart';
import { RFAOverview } from '../../components/purchasing/rfa/RFAOverview';
import { ProductFamiliesChart } from '../../components/purchasing/families/ProductFamiliesChart';
import { usePurchaseMetrics } from '../../hooks/purchases/usePurchaseMetrics';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';

export function PurchasingPage() {
  const { volume, amount, activeSuppliers, isLoading } = usePurchaseMetrics();
  const [activeTab, setActiveTab] = React.useState('suppliers');

  const tabs = [
    { id: 'suppliers', label: 'Fournisseurs', icon: Users2 },
    { id: 'families', label: 'Familles Produits', icon: Package },
    { id: 'countries', label: 'Pays', icon: Globe },
    { id: 'monthly', label: 'Achats mensuels', icon: LineChart },
    { id: 'rfa', label: 'RFA', icon: CreditCard }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'suppliers':
        return <SupplierPerformanceTable />;
      case 'families':
        return <ProductFamiliesChart />;
      case 'countries':
        return <PurchaseOriginChart />;
      case 'monthly':
        return <PurchaseVolumeChart />;
      case 'rfa':
        return <RFAOverview />;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-red-600">Achats</h2>
        <p className="mt-2 text-lg text-red-500">
          Suivi des commandes et relations fournisseurs
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
        <PurchaseMetricCard
          title="Volume Acheté"
          value={volume}
          icon={Package}
          format="volume"
          color="red"
        />
        <PurchaseMetricCard
          title="Montant Achats"
          value={amount}
          icon={ShoppingCart}
          format="millions"
          color="red"
        />
        <PurchaseMetricCard
          title="Fournisseurs Actifs"
          value={activeSuppliers}
          icon={Users}
          format="number"
          color="red"
        />
      </div>

      <NavigationTabs
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        variant="purchasing"
      />

      <div className="mt-6">
        {renderContent()}
      </div>
    </div>
  );
}