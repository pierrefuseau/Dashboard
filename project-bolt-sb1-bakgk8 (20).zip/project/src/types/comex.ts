export interface MonthlyData {
  month: string;
  value: number;
  target: number;
}

export interface Indicator {
  id: string;
  name: string;
  value: number;
  target: number;
  unit: string;
  trend: number;
  frequency: string;
  monthlyData: MonthlyData[];
}

export interface Process {
  id: string;
  name: string;
  indicators: Indicator[];
}

export const getIndicatorStatus = (value: number, target: number) => {
  const variance = ((value - target) / target) * 100;
  if (Math.abs(variance) >= 10) return 'critical';
  if (Math.abs(variance) >= 5) return 'warning';
  return 'success';
};

export const getStatusColors = (status: 'success' | 'warning' | 'critical') => {
  switch (status) {
    case 'critical':
      return {
        bg: 'bg-red-50',
        border: 'border-red-200',
        text: 'text-red-600'
      };
    case 'warning':
      return {
        bg: 'bg-yellow-50',
        border: 'border-yellow-200',
        text: 'text-yellow-600'
      };
    default:
      return {
        bg: 'bg-green-50',
        border: 'border-green-200',
        text: 'text-green-600'
      };
  }
};