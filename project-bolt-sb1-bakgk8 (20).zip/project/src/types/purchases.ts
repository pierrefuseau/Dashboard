export interface RFAPartner {
  name: string;
  currentRFA: number;
  previousRFA: number;
}