export type DDMProductType = 'FRESH' | 'AMBIENT';
export type DDMStatus = 'EXPIRED' | 'CRITICAL' | 'WARNING' | 'OK';

export interface DDMProduct {
  name: string;
  lot: string;
  ddm: Date;
  quantity: number;
  stockAmount: string;
  daysUntilDdm: number;
  type: DDMProductType;
  status: DDMStatus;
}