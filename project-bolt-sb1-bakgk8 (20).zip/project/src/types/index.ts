export interface SalesMetrics {
  revenue: number;
  growth: number;
  topProducts: Array<{
    name: string;
    revenue: number;
    units: number;
  }>;
  regionalSales: Array<{
    region: string;
    revenue: number;
  }>;
}

export interface PurchaseMetrics {
  totalOrders: number;
  pendingOrders: number;
  supplierPerformance: Array<{
    supplier: string;
    score: number;
    deliveryRate: number;
  }>;
}

export interface HRMetrics {
  totalEmployees: number;
  turnoverRate: number;
  departmentHeadcount: Array<{
    department: string;
    count: number;
  }>;
  trainingCompletion: number;
}

export interface LogisticsMetrics {
  inventoryLevel: number;
  deliveryPerformance: number;
  warehouseUtilization: Array<{
    warehouse: string;
    utilization: number;
  }>;
  activeShipments: number;
}