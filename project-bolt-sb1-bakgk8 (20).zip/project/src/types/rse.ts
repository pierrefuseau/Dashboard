export interface RSEMetrics {
  carbonEmissions: number;
  carbonTarget: number;
  genderEquality: number;
  genderTarget: number;
  recyclingRate: number;
  recyclingTarget: number;
  globalScore: number;
  globalTarget: number;
}

export interface CarbonScope {
  name: string;
  value: number;
}

export interface SocialIndicator {
  name: string;
  value: number;
}

export interface EnvironmentalTimeline {
  period: string;
  recycling: number;
  energy: number;
  water: number;
}

export interface GovernanceIndicator {
  name: string;
  value: number;
}