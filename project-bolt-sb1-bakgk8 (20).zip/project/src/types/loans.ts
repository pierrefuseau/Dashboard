export interface Loan {
  id: string;
}

export interface YearlyLoanAmount {
  year: number;
  amounts: Record<string, number>;
  total: number;
}