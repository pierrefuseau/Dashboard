export interface SalesMetrics {
  revenue: number;
  previousRevenue: number;
  margin: number;
  previousMargin: number;
  volume: number;
  previousVolume: number;
}

export interface TopClient {
  name: string;
  revenue: number;
  marginPercent: number;
  marginValue: number;
  volume: number;
}

export interface MarketSegment {
  name: string;
  revenue: number;
  margin: number;
  volume: number;
}

export interface TopProduct {
  code: string;
  name: string;
  revenue: number;
  volume: number;
}