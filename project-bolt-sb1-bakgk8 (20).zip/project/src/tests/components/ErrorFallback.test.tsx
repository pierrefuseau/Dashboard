import { describe, it, expect } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { ErrorFallback } from '../../components/common/ErrorFallback';

describe('ErrorFallback', () => {
  const mockError = new Error('Test error message');
  const mockResetErrorBoundary = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders error message correctly', () => {
    render(<ErrorFallback error={mockError} />);
    expect(screen.getByText('Test error message')).toBeInTheDocument();
  });

  it('shows retry button when resetErrorBoundary is provided', () => {
    render(
      <ErrorFallback 
        error={mockError} 
        resetErrorBoundary={mockResetErrorBoundary} 
      />
    );
    
    const retryButton = screen.getByText('Réessayer');
    expect(retryButton).toBeInTheDocument();
    
    fireEvent.click(retryButton);
    expect(mockResetErrorBoundary).toHaveBeenCalledTimes(1);
  });

  it('does not show retry button when resetErrorBoundary is not provided', () => {
    render(<ErrorFallback error={mockError} />);
    expect(screen.queryByText('Réessayer')).not.toBeInTheDocument();
  });
});