import { describe, it, expect, vi } from 'vitest';
import { renderHook } from '@testing-library/react';
import { useErrorHandler } from '../../hooks/useErrorHandler';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

describe('useErrorHandler', () => {
  const queryClient = new QueryClient();
  const wrapper = ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  );

  beforeEach(() => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
    vi.spyOn(console, 'warn').mockImplementation(() => {});
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('handles Error instances correctly', () => {
    const { result } = renderHook(() => useErrorHandler(), { wrapper });
    const error = new Error('Test error');
    
    const message = result.current.handleError(error);
    expect(message).toBe('Test error');
  });

  it('handles string errors correctly', () => {
    const { result } = renderHook(() => useErrorHandler(), { wrapper });
    const message = result.current.handleError('String error');
    expect(message).toBe('String error');
  });

  it('handles unknown errors correctly', () => {
    const { result } = renderHook(() => useErrorHandler(), { wrapper });
    const message = result.current.handleError({});
    expect(message).toBe('Une erreur est survenue');
  });

  it('respects retry option', () => {
    const { result } = renderHook(() => useErrorHandler(), { wrapper });
    const invalidateQueriesSpy = vi.spyOn(queryClient, 'invalidateQueries');
    
    result.current.handleError(new Error(), { retry: false });
    expect(invalidateQueriesSpy).not.toHaveBeenCalled();
    
    result.current.handleError(new Error(), { retry: true });
    expect(invalidateQueriesSpy).toHaveBeenCalled();
  });
});