import { describe, it, expect } from 'vitest';
import { formatError } from '../../utils/errors/errorUtils';
import { ERROR_MESSAGES } from '../../utils/errors/errorMessages';

describe('errorUtils', () => {
  describe('formatError', () => {
    it('handles standard Error objects', () => {
      const error = new Error('Test error');
      const formatted = formatError(error);
      
      expect(formatted).toEqual({
        type: 'UNKNOWN_ERROR',
        message: 'Test error',
        originalError: error
      });
    });

    it('handles network errors', () => {
      const error = new TypeError('Failed to fetch');
      const formatted = formatError(error);
      
      expect(formatted).toEqual({
        type: 'NETWORK_ERROR',
        message: ERROR_MESSAGES.network.OFFLINE,
        originalError: error
      });
    });

    it('handles unknown error types', () => {
      const formatted = formatError({});
      
      expect(formatted).toEqual({
        type: 'UNKNOWN_ERROR',
        message: ERROR_MESSAGES.data.LOAD_FAILED,
        originalError: {}
      });
    });

    it('preserves already formatted errors', () => {
      const formattedError = {
        type: 'AUTH_ERROR' as const,
        message: 'Already formatted',
      };
      
      const result = formatError(formattedError);
      expect(result).toBe(formattedError);
    });
  });
});